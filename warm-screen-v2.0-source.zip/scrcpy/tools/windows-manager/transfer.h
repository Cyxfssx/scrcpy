#ifndef WARM_TRANSFER_H
#define WARM_TRANSFER_H
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <stdbool.h>
#include <stdint.h>
#define WT_CAPACITY 128
#define WT_PATH 2048
#define WT_SERIAL 128
#define WT_REMOTE 2048

enum wt_state {WT_EMPTY,WT_QUEUED,WT_ACTIVE,WT_INDEXING,WT_DONE,WT_SAVED,WT_FAILED,WT_CANCELLED,WT_PAUSED};
struct wt_task {
    unsigned id;
    enum wt_state state;
    wchar_t local[WT_PATH],remote[WT_REMOTE],serial[WT_SERIAL],alias[64],detail[256];
    uint64_t size,sent;
    bool gallery,cancel,paused;enum wt_state resume_state;
};
struct wt_context;
struct wt_context *wt_create(const wchar_t *adb,const wchar_t *helper,unsigned port);
void wt_destroy(struct wt_context *context);
bool wt_enqueue(struct wt_context *context,const wchar_t *local,const wchar_t *serial,const wchar_t *alias,
                const wchar_t *remote_dir,uint64_t batch,bool gallery,wchar_t *error,size_t error_cap);
size_t wt_snapshot(struct wt_context *context,struct wt_task *tasks,size_t capacity);
bool wt_pause(struct wt_context *context,unsigned id);
bool wt_resume(struct wt_context *context,unsigned id);
void wt_cancel(struct wt_context *context,unsigned id);
void wt_cancel_all(struct wt_context *context);
void wt_clear_completed(struct wt_context *context);
void wt_clear_device_completed(struct wt_context *context,const wchar_t *serial);
bool wt_busy(struct wt_context *context);
unsigned wt_generation(struct wt_context *context);
#ifdef MANAGER_SMOKE_TEST
void wt_test_preview(struct wt_context *context,const wchar_t *serial,const wchar_t *alias);
#endif
bool wt_remote_valid(const wchar_t *path);
bool wt_is_image(const wchar_t *path);
#endif
