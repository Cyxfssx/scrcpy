#ifndef SCRCPY_MANAGER_THEME_H
#define SCRCPY_MANAGER_THEME_H
#include <windows.h>
#include <stdbool.h>
#include <stdint.h>

#define WM_THEME_FOCUS_MESSAGE (WM_APP + 60)

enum wm_theme_role { WM_THEME_LABEL, WM_THEME_TOGGLE, WM_THEME_BUTTON, WM_THEME_INPUT, WM_THEME_COMBO };
bool wm_theme_init(HWND parent, const wchar_t *directory, const wchar_t *ini);
void wm_theme_destroy(void);
void wm_theme_set_transfer(bool active);
void wm_theme_set_panels(const RECT *panels,unsigned count,RECT body_clip);
void wm_theme_preview_resize(int width,int height);
void wm_theme_resize(int width, int height, unsigned dpi);
void wm_theme_paint(HDC dc, const RECT *rect);
void wm_theme_child_background(HWND control,HDC dc);
void wm_theme_round(HDC dc,int x,int y,int w,int h,int radius,uint32_t fill,uint32_t outline);
void wm_theme_symbol(HDC dc,int kind,int x,int y,int size,COLORREF color);
void wm_theme_attach(HWND control, enum wm_theme_role role);
void wm_theme_draw_button(const DRAWITEMSTRUCT *draw, bool primary, bool danger);
bool wm_theme_choose_wallpaper(void);
HBRUSH wm_theme_input_brush(bool disabled);
COLORREF wm_theme_text_color(void);
unsigned wm_theme_generation(void);
#ifdef MANAGER_SMOKE_TEST
bool wm_theme_test_wallpaper(const wchar_t *path);
#endif
#endif
