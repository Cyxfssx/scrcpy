#include "model.h"
#include <stdio.h>
#include <string.h>
#include <wctype.h>

struct wm_profile
wm_default_profile(void) {
    return (struct wm_profile) {.max_size = 1280, .max_fps = 30, .bitrate = 2000000, .text_input = true, .clipboard_images = true};
}

bool
wm_profile_valid(const struct wm_profile *p) {
    return p && (!p->max_size || (p->max_size >= 64 && p->max_size <= 8192))
        && p->max_fps <= 240 && p->bitrate >= 100000 && p->bitrate <= 100000000
        && p->buffer_ms <= 2000 && p->hwdec <= 2;
}

size_t
wm_parse_devices(const char *output, struct wm_discovered_device *devices,
                  size_t capacity, bool *truncated) {
    size_t count = 0;
    *truncated = false;
    for (const char *line = output; *line;) {
        const char *end = strchr(line, '\n');
        if (!end) end = line + strlen(line);
        size_t len = (size_t) (end - line);
        char text[1024];
        if (len >= sizeof(text)) {
            *truncated = true;
            line = *end ? end + 1 : end;
            continue;
        }
        memcpy(text, line, len);
        text[len] = 0;
        char serial[WM_SERIAL_SIZE], state[32];
        if (sscanf(text, "%127s %31s", serial, state) == 2) {
            enum wm_device_state parsed;
            bool known = true;
            if (!strcmp(state, "device")) parsed = WM_DEVICE_READY;
            else if (!strcmp(state, "offline")) parsed = WM_DEVICE_OFFLINE;
            else if (!strcmp(state, "unauthorized")) parsed = WM_DEVICE_UNAUTHORIZED;
            else known = false;
            if (known) {
                bool duplicate = false;
                for (size_t i = 0; i < count; ++i)
                    if (!strcmp(serial, devices[i].serial)) duplicate = true;
                if (!duplicate) {
                    if (count == capacity) *truncated = true;
                    else {
                        struct wm_discovered_device *d = &devices[count++];
                        memset(d, 0, sizeof(*d));
                        strcpy(d->serial, serial);
                        d->state = parsed;
                        d->usb_reported = strstr(text, " usb:") != NULL || strstr(text, "\tusb:") != NULL;
                        const char *model = strstr(text, "model:");
                        if (model) sscanf(model + 6, "%95s", d->model);
                        if (!d->model[0]) strcpy(d->model, "Android");
                    }
                }
            }
        }
        line = *end ? end + 1 : end;
    }
    return count;
}

struct command_writer { wchar_t *out; size_t capacity, used; bool ok; };
static void
append(struct command_writer *w, wchar_t c) {
    if (w->used + 1 >= w->capacity) { w->ok = false; return; }
    w->out[w->used++] = c;
    w->out[w->used] = 0;
}

// Windows CommandLineToArgvW/CRT quoting, including trailing backslashes.
static void
argument(struct command_writer *w, const wchar_t *value) {
    if (w->used) append(w, L' ');
    append(w, L'"');
    for (const wchar_t *p = value; *p;) {
        size_t slashes = 0;
        while (*p == L'\\') { ++slashes; ++p; }
        size_t count = (*p == L'"' || !*p) ? 2 * slashes : slashes;
        for (size_t i = 0; i < count; ++i) append(w, L'\\');
        if (*p == L'"') append(w, L'\\');
        if (*p) append(w, *p++);
    }
    append(w, L'"');
}
static void
number(struct command_writer *w, const wchar_t *option, unsigned value) {
    wchar_t text[80];
    swprintf(text, 80, L"%ls=%u", option, value);
    argument(w, text);
}

bool
wm_build_command(wchar_t *out, size_t capacity, const wchar_t *exe,
                   const wchar_t *serial, const wchar_t *title,
                   const wchar_t *record_path, const struct wm_profile *p) {
    if (!out || !capacity) return false;
    *out = 0;
    if (!exe || !*exe || !serial || !*serial || !title
            || !wm_profile_valid(p) || (p->record && (!record_path || !*record_path))) return false;
    struct command_writer w = {out, capacity, 0, true};
    argument(&w, exe);
    argument(&w, L"-s"); argument(&w, serial);
    argument(&w, L"--window-title"); argument(&w, title);
    argument(&w, L"--keyboard=sdk");
    if (p->text_input) argument(&w, L"--text-via-clipboard");
    argument(&w, L"--no-clipboard-images");
    argument(&w, L"--print-fps");
    argument(&w, L"--video-codec=h264");
    argument(&w, L"--window-width=360");
    argument(&w, L"--pause-on-exit=false");
    argument(&w, p->hwdec == 1 ? L"--hwdec=d3d11va"
                  : p->hwdec == 2 ? L"--hwdec=disabled" : L"--hwdec=auto");
    number(&w, L"--max-size", p->max_size);
    if (p->max_fps) number(&w, L"--max-fps", p->max_fps);
    number(&w, L"--video-bit-rate", p->bitrate);
    number(&w, L"--video-buffer", p->buffer_ms);
    if (!p->audio) argument(&w, L"--no-audio");
    if (p->topmost) argument(&w, L"--always-on-top");
    if (p->borderless) argument(&w, L"--window-borderless");
    if (p->record) { argument(&w, L"--record"); argument(&w, record_path); }
    if (!w.ok) *out = 0;
    return w.ok;
}
