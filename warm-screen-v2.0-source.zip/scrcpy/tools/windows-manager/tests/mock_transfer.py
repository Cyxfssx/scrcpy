import socket,struct,threading,subprocess,os,time,shlex,json,hashlib,sys
from pathlib import Path
base=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path.cwd()
runner=sys.argv[2:] or ['wine']
store={}; removed=set(); commands=[]; sync_counts={}; lock=threading.Lock(); shutdown=threading.Event()

def read(s,n):
    b=bytearray()
    while len(b)<n:
        part=s.recv(n-len(b))
        if not part:raise EOFError
        b.extend(part)
    return bytes(b)
def text(s):return read(s,int(read(s,4),16)).decode()
def client(s):
    serial=''
    try:
        request=text(s);assert request.startswith('host:transport:');serial=request.split(':',2)[2]
        if serial=='bad-device':s.sendall(b'FAIL0004nope');return
        s.sendall(b'OKAY');request=text(s);s.sendall(b'OKAY')
        if request=='sync:':
            kind,length=struct.unpack('<4sI',read(s,8));assert kind==b'SEND';name=read(s,length).decode().rsplit(',',1)[0]
            with lock:
                removed.discard((serial,name));sync_counts[serial,name]=sync_counts.get((serial,name),0)+1
            data=bytearray()
            while True:
                kind,length=struct.unpack('<4sI',read(s,8))
                if kind==b'DONE':break
                assert kind==b'DATA' and length<=65536
                data.extend(read(s,length))
                with lock:
                    if (serial,name) not in removed:store[serial,name]=bytes(data)
                if serial=='disconnect':return
                if serial=='slow':time.sleep(.03)
            with lock:
                if (serial,name) not in removed:store[serial,name]=bytes(data)
            s.sendall(struct.pack('<4sI',b'OKAY',0))
        elif request=='test:count':
            with lock:count=sum(len(v) for (s0,p0),v in store.items() if s0==serial)
            s.sendall(struct.pack('<Q',count))
        elif request.startswith('shell:'):
            args=shlex.split(request[6:]);code=0
            with lock:
                commands.append([serial,args])
                if args[0]=='[':
                    assert args[:3]==['[','!','-e'] and args[4:7]==[']','&&','mv']
                    target,temp,final=args[3],args[7],args[8];assert target==final
                    if (serial,final) in store or (serial,temp) not in store:code=1
                    else:store[serial,final]=store.pop((serial,temp))
                elif args[:2]==['rm','-f']:
                    assert '.warm-part-' in args[2];store.pop((serial,args[2]),None);removed.add((serial,args[2]))
                elif args[0].startswith('CLASSPATH='):
                    assert args[1:4]==['app_process','/','com.genymobile.scrcpy.TransferScanner'];assert (serial,args[4]) in store
                    code=int(serial=='media-fail')
                else:raise AssertionError(args)
            s.sendall(str(code).encode())
        else:raise AssertionError(request)
    except (EOFError,ConnectionError,OSError):pass
    except Exception as e:
        with lock:commands.append(['ERROR',repr(e)])
    finally:s.close()
listener=socket.socket();listener.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);listener.bind(('127.0.0.1',55107));listener.listen()
def accept():
    while not shutdown.is_set():
        try:s,_=listener.accept()
        except OSError:break
        threading.Thread(target=client,args=(s,),daemon=True).start()
threading.Thread(target=accept,daemon=True).start()
result=subprocess.run(runner+[str(base/'Transfer-test.exe')],env=os.environ.copy(),timeout=100)
shutdown.set();listener.close();time.sleep(.1)
assert result.returncode==0,result.returncode
assert not any(x[0]=='ERROR' for x in commands),commands
final={key:value for key,value in store.items() if '.warm-part-' not in key[1] and '/data/local/tmp/' not in key[1]}
assert len(final)==8,[(s,p,len(v)) for (s,p),v in final.items()]
assert any(s=='phone-B' and p.endswith('资料.pdf') and len(v)==1000000 for (s,p),v in final.items())
assert sum(s=='phone-A' and p.endswith("中文 `x$(no)'name.png") for s,p in final)==4
for (serial,path),data in final.items():
    seed=29 if path.endswith('large.bin') else 19 if path.endswith('资料.pdf') else 11 if path.endswith("2-中文 `x$(no)'name.png") else 7
    assert data==bytes((i+seed)%256 for i in range(len(data))), (serial,path,'byte mismatch')
assert not any(s in ['slow','disconnect','bad-device','pause-cancel'] for s,p in final)
assert all(n==1 for (s,p),n in sync_counts.items() if s=='pause-phone'),'Resume restarted the transfer'
assert any(s=='pause-phone' and len(v)==8000000 for (s,p),v in final.items())
assert not any('.warm-part-' in p for s,p in store),list(store)
report={'files':[{'serial':s,'path':p,'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()} for (s,p),v in final.items()],'commands':commands}
Path(os.environ.get('WARM_TRANSFER_REPORT','transfer-integration-report.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('Receiver bytes froze during pause, resume used the same stream and final bytes matched. Native ADB sync byte transfer, isolated targets, duplicate names, cancellation, disconnect cleanup, media warning and shell quoting verified.')
