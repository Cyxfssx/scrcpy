import socket,struct,threading,subprocess,os,time,shlex,json,hashlib,io,sys
from pathlib import Path
from PIL import Image
base=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path.cwd()
runner=sys.argv[2:] or ['wine']
image=Image.new('RGB',(3,2),(50,140,200));image.putpixel((0,0),(255,0,0));image.save(base/'fixture.png');image.save(base/'fixture.jpg')
store={};commands=[];lock=threading.Lock();stop=threading.Event()
def read(s,n):
 b=b''
 while len(b)<n:
  part=s.recv(n-len(b))
  if not part:raise EOFError
  b+=part
 return b
def request(s):return read(s,int(read(s,4),16)).decode()
def client(s):
 try:
  initial=request(s);assert initial.startswith('host:transport:');serial=initial.split(':',2)[2];s.sendall(b'OKAY');kind=request(s);s.sendall(b'OKAY')
  if kind=='sync:':
   cmd,n=struct.unpack('<4sI',read(s,8));assert cmd==b'SEND';path=read(s,n).decode().rsplit(',',1)[0];data=b''
   while True:
    cmd,n=struct.unpack('<4sI',read(s,8))
    if cmd==b'DONE':break
    assert cmd==b'DATA' and n<=65536;data+=read(s,n)
   with lock:store[serial,path]=data
   s.sendall(struct.pack('<4sI',b'OKAY',0))
  else:
   assert kind.startswith('shell:');args=shlex.split(kind[6:]);code=0
   with lock:
    commands.append([serial,args])
    if args[0]=='[':
     assert args[:3]==['[','!','-e'] and args[4:7]==[']','&&','mv'];assert args[3]==args[8]
     if (serial,args[8]) in store:code=1
     else:store[serial,args[8]]=store.pop((serial,args[7]))
    elif args[:2]==['rm','-f']:store.pop((serial,args[2]),None)
    elif args[0].startswith('CLASSPATH='):assert args[1:4]==['app_process','/','com.genymobile.scrcpy.TransferScanner'];assert (serial,args[4]) in store
    else:raise AssertionError(args)
   s.sendall(str(code).encode())
 except (EOFError,ConnectionError,OSError):pass
 except Exception as e:
  with lock:commands.append(['ERROR',repr(e)])
 finally:s.close()
listener=socket.socket();listener.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);listener.bind(('127.0.0.1',55107));listener.listen()
def accept():
 while not stop.is_set():
  try:s,_=listener.accept()
  except OSError:break
  threading.Thread(target=client,args=(s,),daemon=True).start()
threading.Thread(target=accept,daemon=True).start()
result=subprocess.run(runner+[str(base/'Bridge-test.exe')],env=os.environ.copy(),timeout=75)
stop.set();listener.close();assert result.returncode==0,result.returncode
child_pid=(base/'detached-pid.txt').read_text().strip()
ended=subprocess.run(runner+[str(base/'Bridge-test.exe'),'--wait-pid',child_pid],env=os.environ.copy(),timeout=10)
assert ended.returncode==0, 'Detached bridge did not exit when the final mirror process ended'
assert not any(row[0]=='ERROR' for row in commands),commands
files={(serial,path):data for (serial,path),data in store.items() if path.startswith('/sdcard/')}
assert len(files)==8,[(serial,path,len(data)) for (serial,path),data in files.items()]
assert sum(serial=='phone-A' for serial,path in files)==3
assert sum(serial=='phone-B' for serial,path in files)==5
png=(base/'fixture.png').read_bytes();jpg=(base/'fixture.jpg').read_bytes()
assert sum(data==png for data in files.values())==5
assert sum(data==jpg for data in files.values())==1
converted=[Image.open(io.BytesIO(data)).convert('RGBA') for data in files.values() if data not in (png,jpg)]
assert len(converted)==2
for image in converted:
 assert image.size==(3,2)
 assert image.getpixel((0,0))==(255,0,0,255),image.getpixel((0,0))
 assert image.getpixel((0,1))==(0,0,255,255),image.getpixel((0,1))
Path(os.environ.get('WARM_BRIDGE_REPORT','bridge-integration-report.json')).write_text(json.dumps({'files':[{'serial':s,'path':p,'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()} for (s,p),v in files.items()],'commands':commands},ensure_ascii=False,indent=2))
print('Eight image uploads verified, including detached-panel mode: original PNG/JPEG bytes, screenshot pixels/orientation, serial isolation, no repeat duplication and no ordinary paste interception.')
