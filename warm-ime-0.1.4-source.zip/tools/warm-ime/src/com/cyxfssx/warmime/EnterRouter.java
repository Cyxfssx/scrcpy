package com.cyxfssx.warmime;

/** One physical press -> at most one action; never retry a rejected send as Enter. */
public final class EnterRouter {
    public enum Mode { PASS, SEND, NEWLINE, EMPTY }
    public interface Actions { void send(); void newline(); void empty(); }
    private final java.util.HashSet<Integer> held = new java.util.HashSet<>();
    public boolean down(int code, int repeat, Mode mode, Actions actions) {
        if (held.contains(code)) return true;
        if (repeat != 0 || mode == Mode.PASS) return false;
        held.add(code);
        if (mode == Mode.SEND) actions.send();
        else if (mode == Mode.NEWLINE) actions.newline();
        else actions.empty();
        return true;
    }
    public boolean up(int code) {
        return held.remove(code);
    }
    public static String reason(String pkg, int inputType, int imeOptions, boolean enabled,
            boolean otherModifiers, boolean composing, boolean imageGuard, boolean confirmedChat) {
        if (!enabled) return "disabled_or_no_connection";
        if (!"com.kakao.talk".equals(pkg)) return "other_package";
        if ((inputType & 15) != 1) return "not_text_input";
        if (otherModifiers) return "modified_key";
        if (composing) return "android_composing";
        if (imageGuard) return "image_preview_guard";
        int variation = inputType & 0xff0;
        if (variation != 0 && variation != 0x40 && variation != 0x50 && !(confirmedChat && variation == 0xa0)) return "input_variation_0x" + Integer.toHexString(variation);
        int action = imeOptions & 255;
        if (action != 0 && action != 1 && action != 4 && !(confirmedChat && action == 6)) return "ime_action_" + action;
        return "eligible";
    }
    /** Compatibility fingerprint explicitly verified on the user's KakaoTalk chat editor.
     * Field IDs are build-specific: unknown versions deliberately retain manual confirmation.
     */
    public static boolean knownKakaoChat(String pkg,int field,int type,int options) {
        return "com.kakao.talk".equals(pkg) && field==0x7f0a0da2 && type==0x2c001 && options==0x52000006;
    }
    public static boolean sameConfirmedEditor(int field,int type,int options,int savedField,int savedType,int savedOptions) {
        return field>0 && field==savedField && type==savedType && options==savedOptions;
    }
    public static boolean mayConfirm(int type, int options) {
        return "eligible".equals(reason("com.kakao.talk",type,options,true,false,false,false,true));
    }
    public static Mode mode(String pkg, int inputType, int imeOptions, boolean enabled,
            boolean shift, boolean otherModifiers, boolean composing, boolean imageGuard, boolean text) {
        return mode(pkg,inputType,imeOptions,enabled,shift,otherModifiers,composing,imageGuard,text,false);
    }
    public static Mode mode(String pkg, int inputType, int imeOptions, boolean enabled,
            boolean shift, boolean otherModifiers, boolean composing, boolean imageGuard, boolean text, boolean confirmedChat) {
        if (!"eligible".equals(reason(pkg,inputType,imeOptions,enabled,otherModifiers,composing,imageGuard,confirmedChat))) return Mode.PASS;
        if (shift) return Mode.NEWLINE;
        return text ? Mode.SEND : Mode.EMPTY;
    }
}
