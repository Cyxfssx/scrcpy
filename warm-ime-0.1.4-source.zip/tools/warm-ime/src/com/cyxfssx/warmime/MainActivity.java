package com.cyxfssx.warmime;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.WindowInsets;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public final class MainActivity extends Activity {
    private TextView status;
    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    private TextView text(LinearLayout root, String value, int size) { TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(0xff29313d); t.setPadding(0, dp(10), 0, dp(10)); root.addView(t); return t; }
    private void button(LinearLayout root, String label, View.OnClickListener click) { Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setOnClickListener(click); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(56)); p.topMargin = dp(8); root.addView(b, p); }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state); ScrollView scroll = new ScrollView(this); LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(24), dp(20), dp(24), dp(28)); scroll.setBackgroundColor(0xfffff8f0); scroll.addView(root); setContentView(scroll);
        scroll.setOnApplyWindowInsetsListener((v, insets) -> { int top = insets.getSystemWindowInsetTop(), bottom = insets.getSystemWindowInsetBottom(); v.setPadding(0, top, 0, bottom); return insets; }); scroll.requestApplyInsets();
        text(root, "温暖输入法", 28);
        text(root, "无键盘面板 · 自动识别兼容版 0.1.4", 17);
        text(root, "电脑搜狗继续负责选词。本输入法不显示字母键盘。KakaoTalk 中粘贴文字后按 Enter 请求发送，Shift+Enter 换行；粘贴本身不发送。图片仍通过原通道进入预览。", 16);
        button(root, "1．打开系统设置，启用温暖输入法", v -> startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        button(root, "2．切换到温暖输入法", v -> ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showInputMethodPicker());
        button(root, "3．选择一张图片做本机测试", v -> { Intent pick = new Intent(this, PickImageActivity.class); pick.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(pick); });
        text(root, "本机测试：选图后，在 60 秒内返回 KakaoTalk，点当前聊天输入框。只尝试插入一次。请先用测试图片观察应用是否出现预览。\n\n电脑 Ctrl+V：需要配套的独立图片桥接更新；仅安装 APK 不会自动接收到旧模块的图片。", 15);
        android.widget.Switch enter = new android.widget.Switch(this); enter.setText("KakaoTalk：回车发送文字"); enter.setTextSize(16); enter.setPadding(0, dp(12), 0, dp(12)); enter.setChecked(ImageStore.prefs(this).getBoolean("enter_send", true));
        enter.setOnCheckedChangeListener((b, checked) -> ImageStore.prefs(this).edit().putBoolean("enter_send", checked).apply()); root.addView(enter);
        text(root, "测试：回聊天点文字输入框，Ctrl+V 粘贴一句文字，再按 Enter。仅主动按回车才请求发送。声明为搜索、密码的输入框及其他应用保留原操作。请先在测试聊天验证；你已实测手动模式可发送；新增自动识别请先在一台手机上验证。", 15);
        android.widget.Switch automatic = new android.widget.Switch(this); automatic.setText("自动识别已验证的 KakaoTalk 聊天框");automatic.setTextSize(16);automatic.setPadding(0,dp(12),0,dp(12));automatic.setChecked(ImageStore.prefs(this).getBoolean("auto_chat",true));
        automatic.setOnCheckedChangeListener((b,checked)->ImageStore.prefs(this).edit().putBoolean("auto_chat",checked).apply());root.addView(automatic);
        text(root, "匹配已验证版本时，进入聊天点输入框即可自动识别，无需每台手机手动校准。粘贴后主动按 Enter 才请求发送，Shift+Enter 换行。其他版本未匹配时，可用下方手动识别。",15);
        button(root, "手动识别（自动未匹配时使用）", v -> confirmChat());
        button(root, "清除手动识别记录", v -> { ImageStore.prefs(this).edit().remove("chat_confirmed").remove("chat_pending_until").apply(); android.widget.Toast.makeText(this,"已清除手动记录，自动识别开关不受影响",0).show(); refresh(); });
        status = text(root, "", 15);
        button(root, "刷新测试结果", v -> refresh());
        button(root, "复制测试信息", v -> { ((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("温暖输入法测试", report())); android.widget.Toast.makeText(this, "已复制测试信息，不包含聊天文字或图片", 0).show(); });
        button(root, "切回三星／其他输入法", v -> ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showInputMethodPicker());
        button(root, "清理本机图片缓存", v -> new AlertDialog.Builder(this).setMessage("请先完成当前待发送图片。清理后，尚未读取图片的预览可能失效。是否清理？").setPositiveButton("清理", (d, w) -> { try { ImageStore.clear(this); refresh(); } catch (Exception e) { status.setText(e.getMessage()); } }).setNegativeButton("取消", null).show());
        text(root, "本应用没有联网权限。不记录聊天文字。图片只缓存在本机，按你的操作提供给当前应用。\n若应用不接受标准图片接口，需要根据测试结果继续适配，当前不保证出现预览。", 14);
    }
    private void confirmChat() {
        android.content.SharedPreferences p=ImageStore.prefs(this);
        if (System.currentTimeMillis()-p.getLong("kakao_editor_seen",0)>300000) { android.widget.Toast.makeText(this,"请先回 KakaoTalk 点聊天输入框，再返回识别",1).show();return; }
        int type=p.getInt("kakao_type",0),options=p.getInt("kakao_options",0),field=p.getInt("kakao_field",0);
        if (!EnterRouter.mayConfirm(type,options)) { android.widget.Toast.makeText(this,"该字段不符合文字聊天条件，请复制测试信息反馈",1).show();return; }
        new AlertDialog.Builder(this).setMessage("确认刚才点的是 KakaoTalk 聊天文字输入框？识别后，该字段普通回车将请求发送，Shift+Enter 换行；不会立即发送。").setNegativeButton("取消",null).setPositiveButton("确认聊天框",(d,w)->{
            p.edit().putBoolean("chat_confirmed",true).putInt("chat_field",field).putInt("chat_type",type).putInt("chat_options",options).putLong("chat_pending_until",System.currentTimeMillis()+60000).apply();
            android.widget.Toast.makeText(this,field<=0?"请在60秒内回刚才聊天；本次焦点有效":"已识别，请返回刚才的聊天测试回车",1).show();refresh();
        }).show();
    }
    private static String hex(int value) { return "0x"+Integer.toHexString(value); }
    private String report() {
        android.content.SharedPreferences p=ImageStore.prefs(this);
        return "温暖输入法 0.1.4-preview\nAndroid API: "+android.os.Build.VERSION.SDK_INT
            +"\n已选中: "+WarmInputMethodService.selected(this)
            +"\n当前/最近输入应用（非回车快照）: "+p.getString("editor_package","尚未检测")
            +"\n回车时应用: "+p.getString("enter_package","尚未捕获")
            +"\n回车时连接: "+p.getBoolean("enter_connection",false)+" / 输入法选中="+p.getBoolean("enter_selected_at_key",false)+" / 开关="+p.getBoolean("enter_switch_at_key",false)
            +"\n回车时类型: "+hex(p.getInt("enter_input_type",0))+" / variation="+hex(p.getInt("enter_input_type",0)&0xff0)
            +"\n回车时imeOptions: "+hex(p.getInt("enter_ime_options",0))+" / action="+(p.getInt("enter_ime_options",0)&255)
            +"\n回车时fieldId: "+hex(p.getInt("enter_field",0))
            +"\n回车修饰键: "+hex(p.getInt("enter_meta",0))+" / repeat="+p.getInt("enter_repeat",0)
            +"\n已检查选词: "+p.getBoolean("enter_composition_checked",false)+" / composing="+p.getBoolean("enter_composing",false)
            +"\n回车时聊天框已识别: "+p.getBoolean("enter_confirmed",false)+" / 识别方式="+p.getString("enter_recognition","尚未测试")
            +"\n自动识别开关: "+p.getBoolean("auto_chat",true)
            +"\n最近路由: "+p.getString("enter_mode","无")+" / 原因: "+p.getString("enter_reason","未测试")
            +"\n图片预览保护: "+p.getBoolean("enter_image_guard",false)
            +"\n回车发送开关: "+p.getBoolean("enter_send",true)
            +"\n回车结果: "+p.getString("enter_result","尚未捕获")+"\n回车说明: "+p.getString("enter_detail","请测试")
            +"\n最近Kakao字段: "+hex(p.getInt("kakao_field",0))+" / type="+hex(p.getInt("kakao_type",0))+" / action="+(p.getInt("kakao_options",0)&255)
            +"\n聊天框校准保存: "+p.getBoolean("chat_confirmed",false)
            +"\n图片结果: "+p.getString("last_result","尚未测试")+"\n图片说明: "+p.getString("last_detail","无");
    }
    private void refresh() { status.setText(report()); }
    @Override protected void onResume() { super.onResume(); if (status != null) refresh(); }
}
