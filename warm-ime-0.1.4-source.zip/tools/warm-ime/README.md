# 温暖输入法 0.1.4 自动识别兼容版

新增内置离线规则，使用用户已经验证可以回车发送的 KakaoTalk 聊天字段：
package=com.kakao.talk，fieldId=0x7f0a0da2，inputType=0x2c001，imeOptions=0x52000006。
四项完全匹配且自动识别开关打开时，无需手动校准就可进入既有回车发送路径。
这些资源 ID 与应用构建相关，不保证所有 KakaoTalk 版本都相同，不按相似 ID 或仅 DONE 动作泛匹配。

## 多台手机使用

每台手机覆盖安装 APK（同签名，versionCode 5），启用并选中温暖输入法。
默认开启“KakaoTalk：回车发送文字”和“自动识别已验证的 KakaoTalk 聊天框”。
回到聊天点输入框，粘贴文字，松开 Ctrl 后按 Enter。识别匹配时不需要逐台手动校准；
Shift+Enter 换行。只识别、不自动发送，粘贴本身仍不发送。

不同版本或参数不匹配时，保留 0.1.3 的手动识别作为后备。
诊断“识别方式=auto_verified”说明使用内置规则，manual_saved/manual_session 表示旧手动记录。
回车发送总开关关闭后保留原行为；只关闭自动识别开关不会删除手动校准记录。
一像素透明输入视图、图片桥接/预览、其他应用、密码/搜索/修饰键/选词/图片保护规则不变。

## 验证边界

新增自动匹配、其他包/字段/类型/动作/选项不误匹配、发送总开关和图片/选词保护测试通过。
沿用用户已实测可发送的标准 SEND 请求；本次新增“无需手动识别”仍需在手机上复测，
不能仅凭编译/策略测试就声称所有手机版本兼容。不新增权限，不连接规则服务器。
电脑端、scrcpy、ADB 和独立图片桥接均不修改。签名私钥不在源码包内。

此前说明如下，以本节为当前版本。

# 温暖输入法 0.1.3：聊天框兼容与按键现场诊断

0.1.2 的 PASS 只能确认回车曾到达 IME，不能确认是输入类型、IME 动作、修饰键或选词保护哪一项拦截。
当前输入应用（如三星桌面）也可能是后来覆盖的记录，不代表按回车时的应用。本版把两者分开记录。

## 使用

1. 同签名覆盖安装，不卸载旧版；启用并选中温暖输入法，回车发送开关保持开启。
2. 到 KakaoTalk 的聊天页面，点文字输入框。
3. 返回温暖输入法，点击“识别刚才的 KakaoTalk 聊天框”，确认刚才选的是聊天框。
4. 回到同一聊天，粘贴文字，松开 Ctrl，再按一次普通 Enter；Shift+Enter 换行。

识别本身不会发送消息。最近 Kakao 字段需在 5 分钟内被聚焦；识别后请在 60 秒内回聊天。
正字段 ID 与 inputType/imeOptions 完全匹配时持续有效。字段无有效 ID（0/-1）时，只对
用户确认后返回的这个输入会话有效；同一会话的 restart 保留，离开输入会话后失效。
可点“清除聊天框识别”恢复默认规则，重新获得聊天焦点后生效。

## 兼容处理边界

只有被用户识别的字段额外允许 WEB_EDIT_TEXT 类型和 IME_ACTION_DONE，并仍调用
标准 IME_ACTION_SEND 一次，不是发送 DONE，不模拟点击按钮、不增加无障碍权限。
未识别字段沿用原规则；密码、搜索、Next、数字输入等仍不匹配。
Android composing、修饰键与图片预览保护仍然保留，不因识别而关闭。
因此本版不保证解决所有 PASS 情况；需要看按键现场原因，不从截图猜测具体根因。

## 诊断

测试一次后复制信息：包含按回车时的 package、字段 ID、inputType、imeOptions/action、
metaState、repeat、是否实际检查 composing、聊天框是否已识别，以及具体 PASS 原因。
不保存聊天文字、联系人名称或图片。当前/最近输入应用与回车快照分开显示。

- ime_action_6：未识别字段的 DONE 动作限制；先按步骤识别。
- input_variation_0xa0：未识别的网页文字类型；先按步骤识别。
- modified_key：回车时 Ctrl/Alt/Meta 等仍按住；松开后再试。
- android_composing：Android 仍在选词；先确认选词。
- no_input_connection：该事件没有有效输入连接。
- send_rejected：已走发送请求，但应用不接受标准接口。
- send_requested：接口返回接受，是否真正发送仍以实际聊天记录为准。

电脑端、scrcpy、ADB、独立图片桥接和原有图片传输协议不修改。输入视图仍为透明 1 像素。
Android SDK 编译、签名和路由单元测试不替代真实 KakaoTalk 验证。签名私钥不在源码包内。

旧版实现说明如下；以本节为当前行为。

# 温暖输入法 0.1.2 回车发送验证版

仅更新手机 APK，不更新 Windows 面板、scrcpy、ADB、图片桥接或独立 shell helper。
保持 1 像素透明输入视图，不增加字母键盘。与 0.1.0/0.1.1 同签名，versionCode 3 可直接覆盖安装。

## 新增行为

默认开启“KakaoTalk：回车发送文字”，可在设置中关闭恢复原行为。
在 KakaoTalk 文字聊天输入框 Ctrl+V 粘贴文本，检查内容后主动按一次 Enter：
调用一次标准 InputConnection.performEditorAction(IME_ACTION_SEND)。粘贴本身不触发发送。
Shift+Enter 通过 commitText 插入换行。普通 Enter 不退回到注入回车或自动点按钮。
长按/重复 DOWN 不重复发送，消费配对 UP，兼容 scrcpy 上下事件 downTime 不同的情况。
也支持数字小键盘 Enter。其他应用、密码/声明搜索/Next/Done 等输入框及 Ctrl/Alt/Meta
组合保持原路由。Android 已标记的 composing 文本不触发发送映射；Windows 搜狗的候选状态
不能单靠 APK 可靠读取，仍需在实际电脑上验证选词与回车顺序。

空白或不能读取文本时不发送、不插入换行。只判断是否含可见文字，不保存文字内容。
发送接口返回接受不等于消息实际发送成功；应用拒绝时只提示失败，不重试、不自动换行。
用户应在自己的测试聊天中先验证，不要把编译/单元测试通过当作 KakaoTalk 实机成功。

图片提交不触发发送，本次只增加最近图片请求对应的输入框保护：图片被接受后不映射发送，
离开后回到原文字字段时才恢复。既有图片传输、私有缓存和预览逻辑保留，不调用辅助功能或
坐标点击，也没有新增网络、存储、无障碍权限。

## 操作

手机覆盖安装 warm-ime-0.1.2-preview.apk；不用卸载旧版。
打开温暖输入法，启用并选中它，确认回车发送开关开启。
回到 KakaoTalk 测试聊天点文字输入框，电脑 Ctrl+V 粘贴一句测试文字，再按 Enter。
试 Shift+Enter 换行、长按不重复发送。图片仍保留预览后手动点击发送。

如果仍换行或没有发送，返回设置点击“刷新测试结果”“复制测试信息”。
“捕获回车=false”说明 Android IME 未收到此键，需要继续排查电脑/Android 按键通道；
“send_rejected”表示应用未接受标准动作；“send_requested”只表示接口接受请求，
请同时反馈聊天中实际是否出现消息。诊断不含聊天文字或图片。

没有真机/真实 KakaoTalk 运行结果。本次是适配验证版。

## 校验

```
javac -d /tmp/ime-tests tools/warm-ime/src/com/cyxfssx/warmime/EnterRouter.java tools/warm-ime/tests/EnterRouterTest.java
java -cp /tmp/ime-tests com.cyxfssx.warmime.EnterRouterTest
```

包含 Enter 一次动作、重复抑制、配对 UP、数字键盘、Shift 换行、空输入、应用/字段/修饰键/
选词/图片保护/关闭开关的策略测试。Android APK 通过 SDK 36 编译和 v2/v3 签名校验。
签名私钥与密码不在源码包内。旧版说明如下，涉及版本或“不调用发送”的文字以本节为准。

# 温暖输入法 0.1.1 验证版

修复：输入视图在测量阶段限制为 1 像素，避免空白键盘区域撑满屏幕。旧版已实测可进入 KakaoTalk 图片预览，本次未更改图片接口。可用同签名 APK 直接覆盖安装，无需卸载或更新电脑端模块。

独立 Android 输入法，不带字母键盘面板。输入视图只有透明的 1 像素占位，保留 Android 自己的导航／输入法切换区域；系统外观由手机决定。电脑搜狗仍负责选词，scrcpy 原有文字通道保持原样。

## 测试

1. 在手机安装 warm-ime.apk，打开“温暖输入法”，点击启用，再切换到温暖输入法。Android 会显示输入法的系统提示。
2. 可先在 KakaoTalk 点一次聊天输入框，再回到温暖输入法选择一张 JPG/PNG。60 秒内回聊天点输入框，观察是否出现图片预览。
3. 要测试电脑 Ctrl+V，需安装配套独立桥接补丁。关闭旧面板、投屏和 ClipboardBridge.exe，将补丁解压覆盖到已经装有 preview.8 图片桥接的温暖投屏目录。原版 preview.6 需要先安装 preview.8 桥接增量包。
4. 重新启动温暖投屏，确认“图片剪贴板桥接”已启用。手机选中温暖输入法、点聊天输入框。电脑截图／复制图片，或在文件夹选图片 Ctrl+C，在该手机投屏窗口按 Ctrl+V。
5. 成功含义仅为聊天应用的 commitContent 返回接受；请自己确认预览并手动发送。若不出现，打开温暖输入法，点“复制测试信息”反馈结果。应用拒绝、未选中输入法或请求失效时，电脑桥接保留原来的相册保存回退。

不会调用发送按钮、Enter、ACTION_SEND、辅助功能或剪贴板 URI 文本粘贴。不保证所有版本的 KakaoTalk 支持标准图片接口。没有真实手机验证结果。本机选图测试没有相册回退，仅报告接口结果。首次建议测试一张 JPG/PNG。

## 边界

- 无网络、存储读取、无障碍权限；图片由系统选图器或已授权 ADB shell 送入。
- 上传 Provider 受 DUMP 权限保护，普通应用无法上传或选择目标；对聊天应用只授予单张图片只读 URI 权限。
- 请求绑定输入框会话和应用包名；切换应用／输入框或超过 30 秒会拒绝，不重定向到新的聊天。队列中尚未开始的项目在开始处理时绑定当前输入框，因此传输期间请保持聊天不变，首次逐张测试。
- 单图 32 MB，缓存约 128 MB。缓存不会自动清理，以免破坏未完成的预览；完成发送后可在设置手动清理。清理会撤销已授权的图片 URI。
- 不记录聊天文字；设置页保留输入应用包名、声明的图片类型和上次接口状态，便于排查。
- 支持 Android 7.1/API 25 以上。系统的键盘工具栏／导航条是否显示由系统决定。

## 构建

JDK 21、Android SDK platform 36、build-tools 36.0.0；无第三方依赖。

```
ANDROID_HOME=/path/to/sdk \
WARM_IME_KEYSTORE=/private/warm-ime.p12 \
WARM_IME_STORE_PASS_FILE=/private/password-file \
BUILD_DIR=/tmp/warm-ime-build bash tools/warm-ime/build.sh
```

签名别名 warm-ime。签名私钥和密码不在源码包中。使用自己的签名不能直接覆盖本次发行 APK，需先卸载。

配套桥接 helper 源码 `server/src/main/java/com/genymobile/scrcpy/WarmImeBridge.java` 使用已有 FakeContext/Workarounds；通过 `server/build_without_gradle.sh` 单独构建，仅复制输出为 engine/warm-clipboard-scanner。**不能替换正常投屏配套的 engine/scrcpy-server**。Windows 独立模块见 tools/windows-clipboard-bridge/，没有修改或重新打包 scrcpy 核心。

## 回退

切回三星／其他输入法即可回到相册模式。需移除更新时先关闭所有窗口，将备份的 modules/ClipboardBridge.exe 与 engine/warm-clipboard-scanner 还原，再启动旧版；卸载温暖输入法不影响 scrcpy。补丁不包含投屏程序、原投屏 server、ADB、DLL 或主面板。
