#!/usr/bin/env bash
set -euo pipefail
. /workspace/setup/activate.sh
unset CPATH LIBRARY_PATH PKG_CONFIG_SYSROOT_DIR PKG_CONFIG_PATH
export PKG_CONFIG_LIBDIR=/workspace/setup/windows/deps/lib/pkgconfig
export PKG_CONFIG_PATH="$PKG_CONFIG_LIBDIR"
base=/workspace/setup/windows
mkdir -p "$base/deps/include/SDL3" "$base/deps/include/libusb-1.0" "$base/deps/lib/pkgconfig" "$base/imports"
cp "$base/SDL-release-3.4.18/include/SDL3/"*.h "$base/deps/include/SDL3/"
cp "$base/libusb-1.0.30/libusb/libusb.h" "$base/deps/include/libusb-1.0/"
for lib in libavcodec libavformat libavutil libswresample; do
 mkdir -p "$base/deps/include/$lib"
 cp "$base/ffmpeg-source/$lib/"*.h "$base/deps/include/$lib/"
done
cp "$base/ffmpeg-config/libavutil/avconfig.h" "$base/deps/include/libavutil/"
cd "$base/imports"
for pair in 'avcodec-63 avcodec' 'avformat-63 avformat' 'avutil-61 avutil' 'swresample-7 swresample' 'SDL3 SDL3' 'libusb-1.0 usb-1.0'; do
 read -r dll lib <<< "$pair"
 gendef "$base/scrcpy-win64-v5.0.1/$dll.dll"
 x86_64-w64-mingw32-dlltool -m i386:x86-64 -D "$dll.dll" -d "$dll.def" -l "$base/deps/lib/lib$lib.dll.a"
done
python3 - <<'PY'
from pathlib import Path
base=Path('/workspace/setup/windows')
for name,version,lib,inc in [
 ('libavcodec','63.0.0','avcodec',''),
 ('libavformat','63.0.0','avformat',''),
 ('libavutil','61.0.0','avutil',''),
 ('libswresample','7.0.0','swresample',''),
 ('sdl3','3.4.18','SDL3',''),
 ('libusb-1.0','1.0.30','usb-1.0','/libusb-1.0'),
]:
 # ABI majors match the official release DLLs; actual versions come from headers.
 if name.startswith('libav') or name=='libswresample':
  import re
  source=base/'ffmpeg-source'/name
  headers=(source/'version.h').read_text()+(source/'version_major.h').read_text()
  nums=[re.search(r'#define\s+\w+_VERSION_'+k+r'\s+(\d+)',headers).group(1) for k in ['MAJOR','MINOR','MICRO']]
  version='.'.join(nums)
 (base/'deps/lib/pkgconfig'/f'{name}.pc').write_text(f'''prefix={base}/deps
Name: {name}
Description: Official scrcpy release DLL with matching upstream headers
Version: {version}
Libs: -L${{prefix}}/lib -l{lib}
Cflags: -I${{prefix}}/include{inc}
''')
PY
cat > "$base/cross.ini" <<'CROSS'
[binaries]
c = '/workspace/setup/root/usr/bin/x86_64-w64-mingw32-gcc-posix'
ar = '/workspace/setup/root/usr/bin/x86_64-w64-mingw32-ar'
strip = '/workspace/setup/root/usr/bin/x86_64-w64-mingw32-strip'
pkg-config = '/usr/bin/pkg-config'
windres = '/workspace/setup/root/usr/bin/x86_64-w64-mingw32-windres'
[host_machine]
system = 'windows'
cpu_family = 'x86_64'
cpu = 'x86_64'
endian = 'little'
[built-in options]
c_link_args = ['-static-libgcc']
CROSS
# GCC package alternatives are normally made by dpkg; provide a local alias.
if [ ! -e /workspace/setup/root/usr/bin/x86_64-w64-mingw32-gcc ]; then
 ln -s x86_64-w64-mingw32-gcc-posix /workspace/setup/root/usr/bin/x86_64-w64-mingw32-gcc
fi
meson setup "$base/build" /workspace/scrcpy --cross-file="$base/cross.ini" --buildtype=release --strip -Dcompile_server=false -Dportable=true
ninja -C "$base/build" -j 4
