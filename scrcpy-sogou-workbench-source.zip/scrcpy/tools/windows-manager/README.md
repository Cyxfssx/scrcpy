# Windows multi-device manager

A native Win32 control panel for the custom scrcpy client. It uses Windows
system controls and one scrcpy process per selected phone; no browser, Python,
.NET, or Qt runtime is required on the user's computer.

The left panel lists ADB devices and supports start all, start/stop checked,
stop all, tile windows, focus a selected window, and per-session log viewing.
The right panel configures the maximum video size, maximum FPS, bitrate,
hardware decoder, audio, recording, video buffering, always-on-top and
borderless windows. Defaults: 1280, 30 FPS, 2 Mbps, auto hardware decoding,
audio off, recording off, and zero extra video buffering.

Turning off a size limit uses the original resolution. Turning off a frame-rate
limit uses unlimited FPS. These switches remove limits; they do not turn off
video. Settings apply when launching a phone. Applying to already running
checked devices closes those sessions normally, finalizes their recording,
then starts new sessions with the chosen parameters. Recording files have
unique names and use MKV. Stop does not forcibly terminate a recording.

Committed host IME text always uses `--text-via-clipboard`. The paired custom
client retains Ctrl+V image-to-gallery transfers. These are independent phone
windows; the manager does not embed, hook, or redirect their keyboard input.
No chat message or image is automatically sent.

## Package layout

```
Manager.exe
engine/             # scrcpy.exe, adb.exe, matching DLLs, custom server, icons
logs/               # created on launch, unique file per device/session
recordings/         # created if recording is requested
manager-settings.ini # last launched profile; generated locally
```

The manager can also run with the engine files beside Manager.exe for developer
use. Keep the entire package together, in a writable folder. It manages its own
launched sessions only, supports up to 32 discovered devices per run, and queues
launches about 400–500 ms apart. Unauthorized/offline devices are not started.
Existing sessions are not duplicated on repeated start commands. A user can
choose to leave phone windows open when closing the manager; those retained
windows are not adopted automatically when reopening the manager.

`Manager.exe` uses the Windows GUI subsystem. Explicit inherited log/pipe
handles plus `CREATE_NO_WINDOW` hide console children. The paired scrcpy client
also uses `CREATE_NO_WINDOW` for its ADB helpers so image transfers do not open
additional console windows. UI errors and device exits are visible through the
status/list and per-session logs.

## Build and validation

From the repository root, with an x86_64 MinGW GCC toolchain on PATH:

```bash
bash tools/windows-manager/build.sh /absolute/output/directory
```

The normal executable is `Manager.exe`. `Manager-smoke.exe` is test-only and
must not be shipped to users. It creates simulated phone processes only in a
build made with `MANAGER_SMOKE_TEST`.

Portable argument/profile/parser tests:

```bash
gcc -std=c11 -Wall -Wextra -Werror -fsanitize=address,undefined \
  tools/windows-manager/model.c tools/windows-manager/test_model.c \
  -o /tmp/manager-model-tests
/tmp/manager-model-tests
```

Windows smoke test (on Windows or under Wine with a desktop):

```text
Manager-smoke.exe --self-test
```

This checks default controls, disabling limits, audio/record switches, hidden
child process output capture, device parsing, prevention of duplicate launches,
ten independent simulated windows and graceful shutdown. It saves a screenshot
and test logs next to the test executable. It does not validate ten real Android
devices, hardware-decoder capacity, actual recordings, Sogou integration or
Samsung gallery indexing. Those require the user's Windows/phone hardware.

The existing scrcpy debug test suite remains available through Meson.

## Frosted glass appearance

The native GDI+ skin draws rounded translucent cards, blue primary buttons,
iOS-style switches, and rounded inputs. The background and frost are cached;
normal device/status updates do not rebuild the blur. Only a wallpaper change,
window resize, or DPI change rebuilds the backdrop. This is a static wallpaper
material, not a continuous desktop-blur shader or web view.

Use the upper-right **更换壁纸** button to choose PNG, JPG or BMP. The entire image
is fitted without cropping; empty side margins use its opaque corner color (or
cream for transparency). Images are loaded once into an independent bitmap,
limited to a 2048-pixel longest side for retained bitmap memory, and the original
file is released. File size is limited to 32 MiB and source size to 64 megapixels
and 16384 pixels per side. This does not change the source image file.

The selected absolute path is stored in a new UTF-16 `appearance.ini`, keeping
Chinese filenames valid on English Windows. Existing `manager-settings.ini`
profile data is independent. A root `wallpaper.png` or `wallpaper.jpg` is used
as a portable default when no saved wallpaper path is usable.

The package now bundles an AI-generated cream lucky-cat wallpaper matching the
approved UI concept. It is not the user's original inline illustration. Use
**更换壁纸** to select any local original image. The bundled artwork is in
`assets/wallpaper.png`; distributing the source archive includes this asset.

The UI smoke test additionally checks real automatic-switch clicks, disabled
fields, bitmap wallpaper decoding, releasing the source file lock, and keeping
the backdrop generation count stable while ten simulated sessions run.

## Workbench UI and device recovery

The three-column native UI provides a searchable device list with state badges
and per-row start, focus, stop, or reconnect actions. Selection and batch
checkboxes are independent. **启动此设备** affects only the selected device;
**启动所选** applies visible editor settings to all checked ready devices;
**全部启动** retains each other device's saved profile and uses editor settings
for the selected device. **保存配置** saves the selected device and last defaults;
**应用到勾选设备** gracefully restarts checked ready devices using editor settings.

Devices can be renamed using **命名** then **保存名**. Unicode aliases, per-serial
profiles and normal window positions/sizes are stored in a UTF-16 INI. Previous
ASCII settings files are upgraded in place. Window geometry is restored only
if its monitor is present and the remember-position switch is on.

ADB enumeration runs asynchronously every three seconds without resetting the
ADB server. The per-device reconnect action can invoke `adb -s SERIAL reconnect`
for an offline device, never `kill-server`, global `reconnect`, or `usb`.
A missing USB connection must be physically restored and authorization granted.
Only previously launched devices with an unexpected exit/nonzero code or a
known disconnection are eligible for automatic recovery. Manually closing or
stopping a session cancels recovery. Retry delays back off from 5 to 60 seconds,
with at most six attempts until an explicit start/reconnect; a session that is
stable for a minute resets the failure count. Manual reconnect also works when
automatic reconnect is disabled. Individual actions do not restart neighbours.

The CPU and memory readings sample each managed scrcpy process once per second
using GetProcessTimes and GetProcessMemoryInfo. CPU is normalized across logical
processors, as Task Manager does. Memory is the working set. FPS is the actual
render counter from `--print-fps` log lines, not the configured maximum. Unavailable
or stale values show a dash. Static scenes can legitimately report 0 FPS.

The text toggle controls `--text-via-clipboard`. Disabling it returns to scrcpy's
standard SDK keyboard behaviour; it is not a promise of alternate IME support.
The image toggle controls the new `--no-clipboard-images` option independently
of text clipboard synchronization. Default behaviour remains enabled for both.

Smoke tests additionally crash a simulated phone and check that only its PID
changes, check explicit stop suppression, offline gating, manual recovery with
auto disabled, real window placement capture, search-to-device mapping,
per-device profile selection, and a round trip of Chinese aliases through an
isolated settings file. The published UI screenshot uses simulated devices and
is labelled accordingly. Production builds have no simulated device entries.
