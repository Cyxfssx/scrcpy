#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#define _WIN32_WINNT 0x0A00
#define WINVER 0x0A00
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <commctrl.h>
#include <shellapi.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <wchar.h>
#include <math.h>
#include "model.h"
#include "theme.h"
#include <uxtheme.h>
#include <psapi.h>
#include <windowsx.h>

#define PATH_SIZE 2048
#define SCAN_MESSAGE (WM_APP + 1)
#define TIMER_ID 1
#define RECONNECT_MESSAGE (WM_APP + 2)
#define CAPTURE_SIZE 65536

enum {
    ID_REFRESH = 101, ID_CHECK_ALL, ID_UNCHECK, ID_START_ALL, ID_START_CHECKED,
    ID_STOP_CHECKED, ID_STOP_ALL, ID_TILE, ID_FOCUS, ID_LOG, ID_LOG_DIR,
    ID_RESET, ID_APPLY, ID_RECORD_DIR, ID_SIZE_CHECK, ID_FPS_CHECK,
    ID_BUFFER_CHECK, ID_AUDIO, ID_RECORD, ID_TOPMOST, ID_BORDERLESS,
    ID_SIZE, ID_FPS, ID_BITRATE, ID_BUFFER, ID_HWDEC, ID_DEVICES, ID_WALLPAPER,
    ID_SEARCH, ID_SINGLE_START, ID_SINGLE_STOP, ID_RECONNECT, ID_SAVE,
    ID_PRESET_LOW, ID_PRESET_MID, ID_PRESET_HIGH, ID_REMEMBER, ID_TEXT, ID_IMAGES,
    ID_AUTO, ID_RENAME,
};
struct device {
    wchar_t serial[WM_SERIAL_SIZE], model[WM_MODEL_SIZE], alias[64];
    bool wanted, manual_reconnect, reconnect_job, restore_geometry;
    unsigned retries;
    ULONGLONG retry_at, cpu_time, sample_at, fps_at, started_at;
    double cpu; SIZE_T memory; unsigned fps;
    RECT geometry; bool geometry_valid;
    uint64_t log_offset; char log_partial[512]; size_t log_partial_size;
    enum wm_device_state state;
    bool connected, checked, pending, stopping, restart;
    HANDLE process;
    DWORD pid, last_exit;
    HWND window;
    struct wm_profile desired;
    wchar_t log_path[PATH_SIZE];
};
struct capture_result { char output[CAPTURE_SIZE]; DWORD error, exit_code; bool overflow; };
struct manager {
    HINSTANCE instance;
    HWND window, list, status, heading, subtitle, devices_label, settings_label;
    HWND refresh, check_all, uncheck, start_all, start_checked, stop_checked, wallpaper,
         stop_all, tile, focus, log, log_dir, reset, apply, record_dir;
    HWND size_check, size_edit, fps_check, fps_edit, bitrate_label, bitrate_edit, buffer_label,
         audio, record, buffer_check, buffer_edit, hwdec_label, hwdec,
         topmost, borderless, help;
    HWND search, selected_title, selected_detail, stats, picture_label, current_label, quick_label,
         single_start, single_stop, reconnect, save, preset_low, preset_mid, preset_high,
         remember, text_input, images, auto_reconnect, rename, rename_edit, footer, quick_hint;
    HFONT font, title_font, section_font, compact_font; HIMAGELIST row_images;
    int row_map[WM_MAX_DEVICES], visible_count, selected, preset_mode;
    bool rebuilding, scan_silent;
    unsigned jobs; DWORD processors;
    ULONGLONG next_scan, next_sample;
    HBRUSH background, white;
    UINT dpi;
    wchar_t directory[PATH_SIZE], exe[PATH_SIZE], adb[PATH_SIZE], ini[PATH_SIZE];
    wchar_t logs[PATH_SIZE], recordings[PATH_SIZE];
    struct device devices[WM_MAX_DEVICES];
    size_t count;
    bool scanning, closing, keep_windows;
    ULONGLONG next_launch, close_deadline;
    unsigned launch_counter;
#ifdef MANAGER_SMOKE_TEST
    bool smoke;
#endif
};
static struct manager g;
static void refresh_devices(void);
static void update_rows(void);
static void update_enabled(void);
static void tick(void);
static void rebuild_list(void);
static void select_device(int index);
static void single_action(int index, int action);
static void device_section(const struct device *d, wchar_t *out, size_t capacity);
static void load_device(struct device *d);
static void save_device(struct device *d);
static void sample_devices(ULONGLONG now);
static void reconnect_device(int index);
static void capture_geometry(struct device *d);
static void refresh_devices_silent(void);
static void unicode_ini(void);
static void draw_device(const DRAWITEMSTRUCT *di);

static int scaled(int v) { return MulDiv(v, (int)g.dpi, 96); }
static void status(const wchar_t *text) { SetWindowTextW(g.status, text); }
static void error_box(const wchar_t *text) { MessageBoxW(g.window, text, L"scrcpy 多开控制台", MB_OK | MB_ICONWARNING); }
static bool checked(HWND h) { return SendMessageW(h, BM_GETCHECK, 0, 0) == BST_CHECKED; }
static void check(HWND h, bool value) { SendMessageW(h, BM_SETCHECK, value ? BST_CHECKED : BST_UNCHECKED, 0); }
static bool join_path(wchar_t *out, size_t cap, const wchar_t *dir, const wchar_t *name) {
    int n = swprintf(out, cap, L"%ls\\%ls", dir, name);
    return n >= 0 && (size_t)n < cap;
}
static bool folder(const wchar_t *path) {
    if (CreateDirectoryW(path, NULL)) return true;
    DWORD attr = GetFileAttributesW(path);
    return attr != INVALID_FILE_ATTRIBUTES && (attr & FILE_ATTRIBUTE_DIRECTORY);
}
static void system_error(const wchar_t *operation, DWORD code) {
    wchar_t detail[512] = L"", message[1024];
    FormatMessageW(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
                    NULL, code, 0, detail, 512, NULL);
    swprintf(message, 1024, L"%ls失败（%lu）：%ls", operation, (unsigned long)code, detail);
    error_box(message);
}
static void utf8(wchar_t *out, size_t cap, const char *text) {
    if (!MultiByteToWideChar(CP_UTF8, 0, text, -1, out, (int)cap)) *out = 0;
}

// Restrict inheritance to the explicit log/pipe and NUL handles. This also
// prevents an unrelated running phone from retaining another scan's pipe.
static bool spawn_hidden(const wchar_t *exe, wchar_t *command, HANDLE output,
                          PROCESS_INFORMATION *process) {
    SECURITY_ATTRIBUTES sa = {sizeof(sa), NULL, TRUE};
    HANDLE input = CreateFileW(L"NUL", GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE,
                               &sa, OPEN_EXISTING, 0, NULL);
    if (input == INVALID_HANDLE_VALUE) return false;
    STARTUPINFOEXW si;
    ZeroMemory(&si, sizeof(si));
    si.StartupInfo.cb = sizeof(si);
    si.StartupInfo.dwFlags = STARTF_USESTDHANDLES;
    si.StartupInfo.hStdInput = input;
    si.StartupInfo.hStdOutput = si.StartupInfo.hStdError = output;
    SIZE_T size = 0;
    InitializeProcThreadAttributeList(NULL, 1, 0, &size);
    si.lpAttributeList = HeapAlloc(GetProcessHeap(), 0, size);
    bool ok = false;
    DWORD last = ERROR_NOT_ENOUGH_MEMORY;
    bool initialized = si.lpAttributeList
        && InitializeProcThreadAttributeList(si.lpAttributeList, 1, 0, &size);
    if (initialized) {
        HANDLE handles[] = {input, output};
        if (UpdateProcThreadAttribute(si.lpAttributeList, 0,
                PROC_THREAD_ATTRIBUTE_HANDLE_LIST, handles, sizeof(handles), NULL, NULL)) {
            ok = CreateProcessW(exe, command, NULL, NULL, TRUE,
                    CREATE_NO_WINDOW | EXTENDED_STARTUPINFO_PRESENT,
                    NULL, g.directory, &si.StartupInfo, process) != FALSE;
        }
        last = GetLastError();
        DeleteProcThreadAttributeList(si.lpAttributeList);
    }
    if (si.lpAttributeList) HeapFree(GetProcessHeap(), 0, si.lpAttributeList);
    CloseHandle(input);
    SetLastError(last);
    return ok;
}

static struct capture_result *capture(const wchar_t *exe, wchar_t *command) {
    struct capture_result *r = calloc(1, sizeof(*r));
    if (!r) return NULL;
    SECURITY_ATTRIBUTES sa = {sizeof(sa), NULL, TRUE};
    HANDLE read_pipe = NULL, write_pipe = NULL;
    if (!CreatePipe(&read_pipe, &write_pipe, &sa, 0)) { r->error = GetLastError(); return r; }
    SetHandleInformation(read_pipe, HANDLE_FLAG_INHERIT, 0);
    PROCESS_INFORMATION pi;
    if (!spawn_hidden(exe, command, write_pipe, &pi)) {
        r->error = GetLastError(); CloseHandle(read_pipe); CloseHandle(write_pipe); return r;
    }
    CloseHandle(write_pipe); CloseHandle(pi.hThread);
    ULONGLONG deadline = GetTickCount64() + 15000;
    size_t used = 0;
    bool exited = false;
    for (;;) {
        if (GetTickCount64() >= deadline) {
            r->error = WAIT_TIMEOUT;
            TerminateProcess(pi.hProcess, WAIT_TIMEOUT);
            WaitForSingleObject(pi.hProcess, 2000);
            break;
        }
        DWORD available = 0;
        if (!PeekNamedPipe(read_pipe, NULL, 0, NULL, &available, NULL)) break;
        if (available) {
            char chunk[4096]; DWORD got;
            DWORD want = available < sizeof(chunk) ? available : (DWORD)sizeof(chunk);
            if (!ReadFile(read_pipe, chunk, want, &got, NULL) || !got) break;
            size_t room = sizeof(r->output) - 1 - used;
            size_t copy = got < room ? got : room;
            memcpy(r->output + used, chunk, copy); used += copy;
            if (copy != got) r->overflow = true;
            continue;
        }
        if (exited) break;
        if (WaitForSingleObject(pi.hProcess, 30) == WAIT_OBJECT_0) {
            exited = true; // Drain final pipe bytes on the next pass.
        }
    }
    GetExitCodeProcess(pi.hProcess, &r->exit_code);
    CloseHandle(pi.hProcess); CloseHandle(read_pipe);
    return r;
}
static DWORD WINAPI scan_thread(void *param) {
    HWND window = param;
    wchar_t command[PATH_SIZE + 40];
    swprintf(command, PATH_SIZE + 40, L"\"%ls\" devices -l", g.adb);
    struct capture_result *r = capture(g.adb, command);
    if (!PostMessageW(window, SCAN_MESSAGE, 0, (LPARAM)r)) free(r);
    return 0;
}
static void begin_scan(bool silent) {
    if (g.scanning || g.closing) return;
    g.scan_silent=silent;
    g.scanning = true; EnableWindow(g.refresh, FALSE);
    if(!g.scan_silent)status(L"正在读取设备；请在手机上允许 USB 调试授权……");
    HANDLE thread = CreateThread(NULL, 0, scan_thread, g.window, 0, NULL);
    if (thread) CloseHandle(thread);
    else { g.scanning = false; EnableWindow(g.refresh, TRUE); system_error(L"读取设备", GetLastError()); }
}
static void refresh_devices(void){begin_scan(false);}
static void merge_devices(const char *output) {
    struct wm_discovered_device found[WM_MAX_DEVICES]; bool truncated;
    size_t count = wm_parse_devices(output, found, WM_MAX_DEVICES, &truncated);
    for (size_t i = 0; i < g.count; ++i) g.devices[i].connected = false;
    for (size_t i = 0; i < count; ++i) {
        wchar_t serial[WM_SERIAL_SIZE]; utf8(serial, WM_SERIAL_SIZE, found[i].serial);
        size_t index;
        for (index = 0; index < g.count; ++index)
            if (!wcscmp(g.devices[index].serial, serial)) break;
        if (index == g.count) {
            if (g.count == WM_MAX_DEVICES) { truncated = true; continue; }
            ++g.count;
            wcscpy(g.devices[index].serial, serial);
            g.devices[index].checked = found[i].state == WM_DEVICE_READY;
            swprintf(g.devices[index].alias,64,L"手机 %02u",(unsigned)index+1);
            load_device(&g.devices[index]);
        }
        g.devices[index].connected = true;
        g.devices[index].state = found[i].state;
        utf8(g.devices[index].model, WM_MODEL_SIZE, found[i].model);
    }
    rebuild_list();
    update_rows();
    if (truncated) error_box(L"设备列表超过 32 台或输出不完整；本次只显示可解析的设备，请检查设备连接。");
    else if (!count&&!g.scan_silent) status(L"未发现设备。请连接手机、启用 USB 调试，再点击“刷新设备”。");
    else if(!g.scan_silent)status(L"设备列表已更新。勾选设备后启动，或点击“一键全部启动”。");
}
static bool get_uint(HWND h, unsigned *out, unsigned low, unsigned high) {
    wchar_t text[64], *end; GetWindowTextW(h, text, 64);
    if (!*text || *text == L'-') return false;
    unsigned long n = wcstoul(text, &end, 10);
    if (*end || n < low || n > high) return false;
    *out = (unsigned)n; return true;
}
static bool read_profile(struct wm_profile *p) {
    *p = wm_default_profile();
    if (checked(g.size_check)) { if (!get_uint(g.size_edit, &p->max_size, 64, 8192)) goto invalid; }
    else p->max_size = 0;
    if (checked(g.fps_check)) { if (!get_uint(g.fps_edit, &p->max_fps, 1, 240)) goto invalid; }
    else p->max_fps = 0;
    if (checked(g.buffer_check)) { if (!get_uint(g.buffer_edit, &p->buffer_ms, 1, 2000)) goto invalid; }
    else p->buffer_ms = 0;
    wchar_t text[64], *end; GetWindowTextW(g.bitrate_edit, text, 64);
    double rate = wcstod(text, &end);
    if (!*text || *end || !isfinite(rate) || rate < 0.1 || rate > 100.0) goto invalid;
    p->bitrate = (uint32_t)(rate * 1000000.0 + 0.5);
    LRESULT hw = SendMessageW(g.hwdec, CB_GETCURSEL, 0, 0);
    p->hwdec = hw >= 0 ? (unsigned)hw : 0;
    p->audio = checked(g.audio); p->record = checked(g.record);
    p->topmost = checked(g.topmost); p->borderless = checked(g.borderless);
    p->text_input = checked(g.text_input); p->clipboard_images = checked(g.images);
    if (!wm_profile_valid(p)) goto invalid;
    return true;
invalid:
    error_box(L"请检查参数：\n分辨率长边：64～8192\n帧率：1～240 FPS\n码率：0.1～100 Mbps（小数用英文句点）\n额外缓存：1～2000 毫秒，关闭时为 0。");
    return false;
}
static void set_profile(const struct wm_profile *p) {
    wchar_t text[64];
    check(g.size_check, p->max_size != 0); swprintf(text, 64, L"%u", p->max_size ? p->max_size : 1280); SetWindowTextW(g.size_edit, text);
    check(g.fps_check, p->max_fps != 0); swprintf(text, 64, L"%u", p->max_fps ? p->max_fps : 30); SetWindowTextW(g.fps_edit, text);
    check(g.buffer_check, p->buffer_ms != 0); swprintf(text, 64, L"%u", p->buffer_ms ? p->buffer_ms : 50); SetWindowTextW(g.buffer_edit, text);
    swprintf(text, 64, L"%.2f", p->bitrate / 1000000.0); SetWindowTextW(g.bitrate_edit, text);
    SendMessageW(g.hwdec, CB_SETCURSEL, p->hwdec, 0);
    check(g.audio, p->audio); check(g.record, p->record);
    check(g.topmost, p->topmost); check(g.borderless, p->borderless);
    check(g.text_input,p->text_input); check(g.images,p->clipboard_images);
    g.preset_mode=p->max_size==1280&&p->max_fps==30&&p->bitrate==2000000?1:p->max_size==1600&&p->max_fps==45&&p->bitrate==4000000?2:p->max_size==1920&&p->max_fps==60&&p->bitrate==8000000?3:0;
    InvalidateRect(g.preset_low,NULL,FALSE);InvalidateRect(g.preset_mid,NULL,FALSE);InvalidateRect(g.preset_high,NULL,FALSE);
    update_enabled();
}
static void save_profile(const struct wm_profile *p) {
#ifdef MANAGER_SMOKE_TEST
    if (g.smoke) return;
#endif
    unicode_ini();
    const wchar_t *keys[] = {L"size",L"fps",L"bitrate",L"buffer",L"hwdec",L"audio",L"record",L"topmost",L"borderless",L"text_input",L"images"};
    unsigned values[] = {p->max_size,p->max_fps,p->bitrate,p->buffer_ms,p->hwdec,p->audio,p->record,p->topmost,p->borderless,p->text_input,p->clipboard_images};
    for (size_t i = 0; i < sizeof(values)/sizeof(*values); ++i) {
        wchar_t text[40]; swprintf(text, 40, L"%u", values[i]);
        WritePrivateProfileStringW(L"profile", keys[i], text, g.ini);
    }
}
static void load_profile(void) {
    struct wm_profile p = wm_default_profile();
#define READ(field, name) p.field = GetPrivateProfileIntW(L"profile", name, p.field, g.ini)
    READ(max_size,L"size"); READ(max_fps,L"fps"); READ(bitrate,L"bitrate"); READ(buffer_ms,L"buffer"); READ(hwdec,L"hwdec");
    READ(audio,L"audio"); READ(record,L"record"); READ(topmost,L"topmost"); READ(borderless,L"borderless");
#undef READ
    if (!wm_profile_valid(&p)) p = wm_default_profile();
    p.text_input=GetPrivateProfileIntW(L"profile",L"text_input",1,g.ini)!=0;
    p.clipboard_images=GetPrivateProfileIntW(L"profile",L"images",1,g.ini)!=0;
    check(g.remember,GetPrivateProfileIntW(L"manager",L"remember",1,g.ini)!=0);
    check(g.auto_reconnect,GetPrivateProfileIntW(L"manager",L"auto_reconnect",1,g.ini)!=0);
    set_profile(&p);
}
static void update_enabled(void) {
    EnableWindow(g.size_edit, checked(g.size_check));
    EnableWindow(g.fps_edit, checked(g.fps_check));
    EnableWindow(g.buffer_edit,checked(g.buffer_check));
    ShowWindow(g.buffer_edit,checked(g.buffer_check)?SW_SHOW:SW_HIDE);
    ShowWindow(g.buffer_label,checked(g.buffer_check)?SW_SHOW:SW_HIDE);
}
static BOOL CALLBACK find_window(HWND window, LPARAM param) {
    struct device *d = (struct device *)param; DWORD pid;
    GetWindowThreadProcessId(window, &pid);
    if (pid == d->pid && IsWindowVisible(window) && !GetWindow(window, GW_OWNER)) {
        d->window = window; return FALSE;
    }
    return TRUE;
}
static HWND phone_window(struct device *d) {
    if (!d->process) return NULL;
    DWORD owner = 0;
    if (IsWindow(d->window)) GetWindowThreadProcessId(d->window, &owner);
    if (owner != d->pid) { d->window = NULL; EnumWindows(find_window, (LPARAM)d); }
    return d->window;
}
static void close_phone(struct device *d) {
    capture_geometry(d);
    d->pending = false; d->stopping = d->process != NULL;
    HWND window = phone_window(d);
    if (window) PostMessageW(window, WM_CLOSE, 0, 0);
}
static bool launch(struct device *d) {
    if (!folder(g.logs) || (d->desired.record && !folder(g.recordings))) {
        status(L"无法创建日志或录屏目录，请将软件解压到可写文件夹后重试。"); return false;
    }
    wchar_t safe[WM_SERIAL_SIZE];
    size_t n = wcslen(d->serial);
    for (size_t i = 0; i <= n; ++i) {
        wchar_t c = d->serial[i];
        safe[i] = (c == 0 || (c >= L'a' && c <= L'z') || (c >= L'A' && c <= L'Z')
            || (c >= L'0' && c <= L'9') || c == L'-' || c == L'_') ? c : L'_';
    }
    SYSTEMTIME time; GetLocalTime(&time);
    wchar_t name[256], record_path[PATH_SIZE], title[256], command[WM_COMMAND_SIZE];
    swprintf(name, 256, L"%ls-%04u%02u%02u-%02u%02u%02u-%llu-%u", safe,
        time.wYear,time.wMonth,time.wDay,time.wHour,time.wMinute,time.wSecond,
        (unsigned long long)GetTickCount64(), ++g.launch_counter);
    wchar_t leaf[280]; swprintf(leaf, 280, L"%ls.log", name);
    if (!join_path(d->log_path, PATH_SIZE, g.logs, leaf)) return false;
    swprintf(leaf, 280, L"%ls.mkv", name);
    if (!join_path(record_path, PATH_SIZE, g.recordings, leaf)) return false;
    swprintf(title, 256, L"%ls · %ls", d->alias, d->serial);
    if (!wm_build_command(command, WM_COMMAND_SIZE, g.exe, d->serial, title, record_path, &d->desired)) return false;
    if (checked(g.remember) && d->geometry_valid) {
        RECT r=d->geometry;
        if(MonitorFromRect(&r,MONITOR_DEFAULTTONULL)) {
            size_t used=wcslen(command);
            swprintf(command+used,WM_COMMAND_SIZE-used,L" --window-x=%ld --window-y=%ld --window-width=%ld --window-height=%ld",
                r.left,r.top,r.right-r.left,r.bottom-r.top);
            d->restore_geometry=true;
        }
    }
    SECURITY_ATTRIBUTES sa = {sizeof(sa), NULL, TRUE};
    HANDLE log = CreateFileW(d->log_path, GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE,
                             &sa, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL);
    if (log == INVALID_HANDLE_VALUE) { status(L"创建日志失败，请检查文件夹写入权限。"); return false; }
    PROCESS_INFORMATION pi;
    bool ok = spawn_hidden(g.exe, command, log, &pi);
    DWORD code = GetLastError(); CloseHandle(log);
    if (!ok) {
        wchar_t text[180]; swprintf(text,180,L"启动投屏失败（%lu），请检查程序文件及日志。",(unsigned long)code);
        status(text); return false;
    }
    CloseHandle(pi.hThread); d->process = pi.hProcess; d->pid = pi.dwProcessId;
    d->window = NULL; d->stopping = d->restart = false; d->last_exit = 0;
    d->started_at=GetTickCount64();d->cpu_time=d->sample_at=d->fps_at=0; d->cpu=0; d->memory=0; d->log_offset=0; d->log_partial_size=0;
    return true;
}
static void start_devices(bool all, bool restart) {
    struct wm_profile p;
    if (!read_profile(&p)) return;
    if (restart && MessageBoxW(g.window,
        L"将重启勾选的投屏窗口并应用右侧参数。正在进行的录屏会结束保存，是否继续？",
        L"应用参数", MB_YESNO | MB_ICONQUESTION) != IDYES) return;
    unsigned queued = 0;
    for (size_t i = 0; i < g.count; ++i) {
        struct device *d = &g.devices[i];
        if (!all && !d->checked) continue;
        if (!d->connected || d->state != WM_DEVICE_READY) continue;
        if (d->process && !restart) continue;
        if(!all||(int)i==g.selected)d->desired=p;
        d->wanted=true;d->retries=0;save_device(d);
        if (d->process) { close_phone(d); d->restart = true; }
        else d->pending = true;
        ++queued;
    }
    save_profile(&p);
    if (!queued) status(L"没有可启动的设备：请刷新设备、检查调试授权及勾选状态；已运行的窗口不会重复打开。");
    else status(restart ? L"正在结束原窗口；退出后按新参数重新启动……" : L"设备已加入启动队列，将依次启动以减少瞬时占用。");
    update_rows();
}
static void stop_devices(bool all) {
    for (size_t i = 0; i < g.count; ++i) {
        if (all || g.devices[i].checked) {
            g.devices[i].wanted=false;g.devices[i].manual_reconnect=false;g.devices[i].retries=0;
            g.devices[i].restart = false;
            close_phone(&g.devices[i]);
        }
    }
    status(L"已请求关闭投屏，正在等待退出和录屏保存；不会强制终止进程。");
}
static void focus_selected(void) {
    int index = g.selected;
    if (index < 0) { status(L"请先点击左侧的一台设备。"); return; }
    HWND window = phone_window(&g.devices[index]);
    if (window) { ShowWindow(window, SW_RESTORE); SetForegroundWindow(window); }
    else status(L"此设备的投屏窗口尚未打开。");
}
static void tile_windows(void) {
    HWND windows[WM_MAX_DEVICES]; unsigned count = 0;
    for (size_t i = 0; i < g.count; ++i) {
        HWND window = phone_window(&g.devices[i]);
        if (window && !g.devices[i].stopping) windows[count++] = window;
    }
    if (!count) { status(L"没有可排列的投屏窗口。"); return; }
    RECT area; SystemParametersInfoW(SPI_GETWORKAREA, 0, &area, 0);
    int screen_w = area.right - area.left, screen_h = area.bottom - area.top;
    unsigned columns = (unsigned)ceil(sqrt(count * (double)screen_w / screen_h / 0.55));
    if (columns > count) columns = count;
    unsigned rows = (count + columns - 1) / columns;
    int cell_w = screen_w / (int)columns, cell_h = screen_h / (int)rows;
    for (unsigned i = 0; i < count; ++i) {
        RECT outer, inner; GetWindowRect(windows[i], &outer); GetClientRect(windows[i], &inner);
        int border_w = (outer.right - outer.left) - inner.right;
        int border_h = (outer.bottom - outer.top) - inner.bottom;
        double aspect = inner.bottom ? (double)inner.right / inner.bottom : 0.46;
        int h = cell_h - 8, w = (int)((h - border_h) * aspect) + border_w;
        if (w > cell_w - 8) { w = cell_w - 8; h = (int)((w - border_w) / aspect) + border_h; }
        int x = area.left + (int)(i % columns) * cell_w + (cell_w - w) / 2;
        int y = area.top + (int)(i / columns) * cell_h + (cell_h - h) / 2;
        ShowWindow(windows[i], SW_RESTORE);
        SetWindowPos(windows[i], NULL, x, y, w, h, SWP_NOZORDER | SWP_NOACTIVATE);
    }
    status(L"已将本面板管理的投屏窗口平铺到主显示器。");
}
static const wchar_t *device_state(const struct device *d) {
    if(d->stopping)return L"正在停止";
    if(d->pending)return L"排队启动";
    if(d->reconnect_job)return L"正在重连";
    if(!d->connected)return L"已断开";
    if(d->state==WM_DEVICE_UNAUTHORIZED)return L"等待授权";
    if(d->state==WM_DEVICE_OFFLINE)return L"连接异常";
    if(d->process)return L"运行中";
    if(d->wanted&&checked(g.auto_reconnect))return d->retries>=6?L"重试已暂停":L"等待重连";
    if(d->last_exit)return L"异常退出";
    return L"已连接 · 未启动";
}
static void text_if_changed(HWND h,const wchar_t *text) {
    wchar_t old[1024];GetWindowTextW(h,old,1024);
    if(wcscmp(old,text))SetWindowTextW(h,text);
}
static void update_rows(void) {
    unsigned active=0,ready=0,abnormal=0;
    static wchar_t previous[WM_MAX_DEVICES][64];
    for(size_t i=0;i<g.count;++i) {
        struct device *d=&g.devices[i];
        active+=d->process!=NULL;
        ready+=d->connected&&d->state==WM_DEVICE_READY;
        abnormal+=d->connected&&(d->state!=WM_DEVICE_READY||d->last_exit!=0);
        const wchar_t *state=device_state(d);
        if(wcscmp(previous[i],state)) {
            wcscpy(previous[i],state);InvalidateRect(g.list,NULL,FALSE);
        }
    }
    wchar_t text[512];swprintf(text,512,L"设备（%u）",(unsigned)g.count);text_if_changed(g.devices_label,text);
    swprintf(text,512,L"● 已连接 %u 台   ·   运行中 %u 台   ·   异常 %u 台",ready,active,abnormal);text_if_changed(g.footer,text);
    if(g.selected>=0&&(size_t)g.selected<g.count) {
        struct device *d=&g.devices[g.selected];
        swprintf(text,512,L"%ls   ·   %ls",d->alias,device_state(d));text_if_changed(g.selected_title,text);
        swprintf(text,512,L"%ls  ·  USB / ADB   ·   %ls",d->model,d->serial);text_if_changed(g.selected_detail,text);
        if(d->process) {
            if(d->fps_at&&GetTickCount64()-d->fps_at<5000)
                swprintf(text,512,L"CPU  %.1f%%        内存  %.1f MB        帧率  %u FPS",d->cpu,(double)d->memory/1048576,d->fps);
            else swprintf(text,512,L"CPU  %.1f%%        内存  %.1f MB        帧率  —",d->cpu,(double)d->memory/1048576);
        } else wcscpy(text,L"CPU  —             内存  —             帧率  —");
        text_if_changed(g.stats,text);
        EnableWindow(g.single_start,d->connected&&d->state==WM_DEVICE_READY&&!d->process&&!d->pending);
        EnableWindow(g.single_stop,d->process!=NULL||d->pending||d->wanted);
        EnableWindow(g.reconnect,!d->reconnect_job);
    } else {
        text_if_changed(g.selected_title,L"选择一台手机");text_if_changed(g.selected_detail,L"连接手机并允许 USB 调试，点击左侧设备进行管理");
        text_if_changed(g.stats,L"CPU  —             内存  —             帧率  —");
        EnableWindow(g.single_start,FALSE);EnableWindow(g.single_stop,FALSE);EnableWindow(g.reconnect,FALSE);
    }
}
static void tick(void) {
    ULONGLONG now=GetTickCount64();bool any=false;
    if(!g.closing&&now>=g.next_scan) {
        g.next_scan=now+3000;
#ifdef MANAGER_SMOKE_TEST
        if(!g.smoke)
#endif
        refresh_devices_silent();
    }
    for(size_t i=0;i<g.count;++i) {
        struct device *d=&g.devices[i];
        if(d->process) {
            if(WaitForSingleObject(d->process,0)==WAIT_OBJECT_0) {
                bool intentional=d->stopping;
                GetExitCodeProcess(d->process,&d->last_exit);
                CloseHandle(d->process);d->process=NULL;d->window=NULL;d->stopping=false;
                if(d->restart&&!g.closing){d->pending=true;d->restart=false;}
                else if(!intentional&&d->wanted&&(d->last_exit||!d->connected)) {
                    unsigned delay=5u<<(d->retries<4?d->retries:4);
                    d->retry_at=now+(delay>60?60:delay)*1000;
                } else d->wanted=false; // Closing a phone window manually must stay closed.
            } else {
                HWND h=phone_window(d);
                if(h&&d->restore_geometry) {
                    RECT r=d->geometry;
                    SetWindowPos(h,NULL,r.left,r.top,r.right-r.left,r.bottom-r.top,SWP_NOZORDER|SWP_NOACTIVATE);
                    d->restore_geometry=false;
                }
                if(d->stopping&&h)PostMessageW(h,WM_CLOSE,0,0);
            }
        }
        if(!g.closing&&(checked(g.auto_reconnect)||d->manual_reconnect)&&d->wanted&&!d->process&&!d->pending&&!d->reconnect_job
            &&d->connected&&d->state==WM_DEVICE_READY&&d->retries<6&&now>=d->retry_at) {
            d->pending=true;++d->retries;
        }
        if(d->pending&&!g.closing&&now>=g.next_launch) {
            d->pending=false;d->manual_reconnect=false;
            if(d->connected&&d->state==WM_DEVICE_READY) {
                if(!launch(d))d->last_exit=1;
                unsigned delay=5u<< (d->retries<4?d->retries:4);
                d->retry_at=now+(delay>60?60:delay)*1000;
            }
            g.next_launch=now+400;
        }
        any|=d->process!=NULL||d->pending;
    }
    if(now>=g.next_sample){g.next_sample=now+1000;sample_devices(now);}
    update_rows();
    if(g.closing&&(!any||g.keep_windows)&&!g.scanning&&!g.jobs)DestroyWindow(g.window);
    else if(g.closing&&now>g.close_deadline) {
        g.close_deadline=now+60000;
        if(MessageBoxW(g.window,L"仍有投屏尚未退出。是否保留这些窗口并退出控制面板？",L"等待退出",MB_YESNO|MB_ICONQUESTION)==IDYES) {
            g.keep_windows=true;if(!g.scanning&&!g.jobs)DestroyWindow(g.window);
        } else {g.closing=false;status(L"已取消退出。");}
    }
}
static HWND control(const wchar_t *class_name, const wchar_t *text, DWORD style, int id) {
    HWND h = CreateWindowExW(0,
        class_name, text, WS_CHILD | WS_VISIBLE | style, 0,0,1,1,
        g.window, (HMENU)(INT_PTR)id, g.instance, NULL);
    if(!wcscmp(class_name,L"STATIC")) wm_theme_attach(h,WM_THEME_LABEL);
    else if(!wcscmp(class_name,L"EDIT")) wm_theme_attach(h,WM_THEME_INPUT);
    return h;
}
static HWND button(const wchar_t *text, int id, bool primary) {
    (void)primary;
    HWND h=control(L"BUTTON",text,WS_TABSTOP|BS_OWNERDRAW,id);
    wm_theme_attach(h,WM_THEME_BUTTON);return h;
}
static HWND toggle(const wchar_t *text, int id) {
    HWND h=control(L"BUTTON",text,WS_TABSTOP|BS_AUTOCHECKBOX,id);
    wm_theme_attach(h,WM_THEME_TOGGLE);return h;
}
static HWND edit(int id, bool number_only) {
    HWND h = control(L"EDIT", L"", WS_TABSTOP | ES_AUTOHSCROLL | (number_only ? ES_NUMBER : 0), id);
    SendMessageW(h, EM_SETLIMITTEXT, 24, 0); return h;
}
static BOOL CALLBACK font_child(HWND h, LPARAM param) { SendMessageW(h, WM_SETFONT, (WPARAM)param, TRUE); return TRUE; }
static void set_fonts(void) {
    HFONT old = g.font, old_title = g.title_font,old_section=g.section_font,old_compact=g.compact_font;
    g.font = CreateFontW(-scaled(15), 0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,
                         OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Microsoft YaHei UI");
    g.title_font = CreateFontW(-scaled(25),0,0,0,FW_BOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,
                         OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Microsoft YaHei UI");
    g.section_font=CreateFontW(-scaled(18),0,0,0,FW_SEMIBOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Microsoft YaHei UI");
    g.compact_font=CreateFontW(-scaled(13),0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Microsoft YaHei UI");
    EnumChildWindows(g.window, font_child, (LPARAM)g.font);
    HWND sections[]={g.devices_label,g.selected_title,g.picture_label,g.current_label,g.quick_label,g.settings_label,g.stats};
    for(unsigned i=0;i<sizeof(sections)/sizeof(*sections);++i)if(sections[i])SendMessageW(sections[i],WM_SETFONT,(WPARAM)g.section_font,TRUE);
    if(g.row_images)ImageList_SetIconSize(g.row_images,1,scaled(82));
    SendMessageW(g.heading, WM_SETFONT, (WPARAM)g.title_font, TRUE);
    if(old)DeleteObject(old);if(old_title)DeleteObject(old_title);if(old_section)DeleteObject(old_section);if(old_compact)DeleteObject(old_compact);
}
static void place(HWND h, int x, int y, int width, int height) {
    MoveWindow(h, scaled(x), scaled(y), scaled(width), scaled(height), TRUE);
}
static void body(HWND control,int x,int y,int width,int height) {
    RECT r;GetClientRect(g.window,&r);int h=MulDiv(r.bottom,96,(int)g.dpi);
    int available=h-188;if(available>654)available=654;
    int sy=88+MulDiv(y-88,available,654),sh=height>100?height:MulDiv(height,available,654);
    place(control,x,sy,width,sh);
}
static void layout(void) {
    RECT r;GetClientRect(g.window,&r);
    int w=MulDiv(r.right,96,(int)g.dpi),h=MulDiv(r.bottom,96,(int)g.dpi);
    int left=w*38/100,mid=w*39/100,cx=left+22,rx=cx+mid+14,rw=w-rx-24;
    wm_theme_resize(r.right,r.bottom,g.dpi);InvalidateRect(g.window,NULL,FALSE);
    place(g.heading,26,15,w-460,36);place(g.subtitle,28,51,w-56,22);place(g.wallpaper,w-158,22,132,34);
    place(g.devices_label,28,96,left-36,28);
    place(g.search,28,135,left-32,36);
    place(g.list,24,183,left-24,h-345);
    place(g.refresh,28,h-151,110,31);place(g.check_all,146,h-151,78,31);place(g.uncheck,232,h-151,78,31);
    place(g.quick_hint,28,h-110,left-34,28);
    body(g.selected_title,cx+16,98,mid-80,30);body(g.rename,cx+mid-64,96,58,30);
    body(g.selected_detail,cx+16,136,mid-22,24);body(g.stats,cx+18,181,mid-24,32);
    body(g.picture_label,cx+16,244,mid-24,28);
    int gap=12,half=(mid-44)/2,ax=cx+16,bx=ax+half+gap;
    body(g.size_check,ax,283,half,28);body(g.size_edit,ax,317,half,34);
    body(g.fps_check,bx,283,half,28);body(g.fps_edit,bx,317,half,34);
    body(g.bitrate_label,ax,363,half,24);body(g.bitrate_edit,ax,393,half,34);
    body(g.hwdec_label,bx,363,half,24);body(g.hwdec,bx,393,half,240);
    int third=(mid-56)/3;
    body(g.preset_low,ax,442,third,43);body(g.preset_mid,ax+third+12,442,third,43);body(g.preset_high,ax+2*(third+12),442,third,43);
    body(g.current_label,cx+16,517,mid-24,26);
    body(g.single_start,ax,555,third,40);body(g.reconnect,ax+third+12,555,third,40);body(g.single_stop,ax+2*(third+12),555,third,40);
    body(g.quick_label,cx+16,625,mid-24,25);
    body(g.tile,ax,662,third,38);body(g.save,ax+third+12,662,third,38);body(g.log,ax+2*(third+12),662,third,38);
    body(g.apply,ax,710,mid-40,32);
    body(g.settings_label,rx+16,98,rw-22,28);
    HWND toggles[]={g.audio,g.record,g.buffer_check,g.topmost,g.remember,g.text_input,g.images,g.auto_reconnect,g.borderless};
    for(unsigned i=0;i<9;++i){body(toggles[i],rx+16,149+(int)i*47,rw-28,36);SendMessageW(toggles[i],WM_SETFONT,(WPARAM)(w<1250?g.compact_font:g.font),FALSE);}
    body(g.buffer_label,rx+16,590,rw-110,28);
    body(g.buffer_edit,rx+rw-84,590,68,28);
    place(g.record_dir,w-430,22,124,34);place(g.log_dir,w-294,22,124,34);
    body(g.help,cx+16,750,mid-24,26);ShowWindow(g.help,h>=820?SW_SHOW:SW_HIDE);
    place(g.footer,28,h-69,w-620,25);
    place(g.start_checked,w-568,h-74,164,39);place(g.stop_all,w-390,h-74,164,39);place(g.start_all,w-212,h-74,184,39);
    place(g.status,28,h-33,w-56,20);
    ShowWindow(g.stop_checked,SW_HIDE);ShowWindow(g.focus,SW_HIDE);ShowWindow(g.reset,SW_HIDE);
    ListView_SetColumnWidth(g.list,0,scaled(left-56));
}
static LRESULT CALLBACK device_list_proc(HWND h,UINT m,WPARAM w,LPARAM l,UINT_PTR id,DWORD_PTR data);
static void create_controls(void) {
    g.heading=control(L"STATIC",L"▣  手机工作台",0,0);
    g.subtitle=control(L"STATIC",L"Scrcpy Manager   ·   独立聊天窗口 · 搜狗输入 · 图片存相册",0,0);
    g.wallpaper=button(L"更换壁纸",ID_WALLPAPER,false);
    g.devices_label=control(L"STATIC",L"设备（0）",0,0);
    g.search=control(L"EDIT",L"",WS_TABSTOP|ES_AUTOHSCROLL,ID_SEARCH);
    SendMessageW(g.search,EM_SETCUEBANNER,TRUE,(LPARAM)L"搜索设备名称 / 序列号");
    SendMessageW(g.search,EM_SETLIMITTEXT,128,0);
    g.list=control(WC_LISTVIEWW,L"",WS_TABSTOP|LVS_REPORT|LVS_OWNERDRAWFIXED|LVS_NOCOLUMNHEADER|LVS_SINGLESEL|LVS_SHOWSELALWAYS,ID_DEVICES);
    SetWindowTheme(g.list,L"",L"");
    ListView_SetExtendedListViewStyle(g.list,LVS_EX_CHECKBOXES|LVS_EX_FULLROWSELECT|LVS_EX_DOUBLEBUFFER);
    ListView_SetBkColor(g.list,RGB(251,249,245));ListView_SetTextBkColor(g.list,CLR_NONE);
    g.row_images=ImageList_Create(1,scaled(82),ILC_COLOR32,1,1);ListView_SetImageList(g.list,g.row_images,LVSIL_SMALL);
    LVCOLUMNW col={0};col.mask=LVCF_WIDTH;col.cx=500;ListView_InsertColumn(g.list,0,&col);
    SetWindowSubclass(g.list,device_list_proc,5,0);
    g.refresh=button(L"刷新设备",ID_REFRESH,false);g.check_all=button(L"全选",ID_CHECK_ALL,false);g.uncheck=button(L"取消全选",ID_UNCHECK,false);
    g.quick_hint=control(L"STATIC",L"单台启动、停止、重连；仅处理对应设备",0,0);
    g.selected_title=control(L"STATIC",L"选择一台手机",0,0);
    g.selected_detail=control(L"STATIC",L"连接手机并允许 USB 调试",0,0);
    g.rename=button(L"命名",ID_RENAME,false);
    g.stats=control(L"STATIC",L"CPU  —             内存  —             帧率  —",SS_CENTERIMAGE,0);
    g.picture_label=control(L"STATIC",L"▣  画面设置",SS_CENTERIMAGE,0);
    g.size_check=toggle(L"分辨率长边限制",ID_SIZE_CHECK);g.size_edit=edit(ID_SIZE,true);
    g.fps_check=toggle(L"帧率限制（FPS）",ID_FPS_CHECK);g.fps_edit=edit(ID_FPS,true);
    g.bitrate_label=control(L"STATIC",L"视频码率（Mbps）",SS_CENTERIMAGE,0);g.bitrate_edit=edit(ID_BITRATE,false);
    g.hwdec_label=control(L"STATIC",L"硬件解码",SS_CENTERIMAGE,0);
    g.hwdec=control(WC_COMBOBOXW,L"",WS_TABSTOP|CBS_DROPDOWNLIST|WS_VSCROLL,ID_HWDEC);wm_theme_attach(g.hwdec,WM_THEME_COMBO);
    SendMessageW(g.hwdec,CB_ADDSTRING,0,(LPARAM)L"自动（推荐）");SendMessageW(g.hwdec,CB_ADDSTRING,0,(LPARAM)L"D3D11 硬解");SendMessageW(g.hwdec,CB_ADDSTRING,0,(LPARAM)L"软件解码");
    g.preset_low=button(L"流畅",ID_PRESET_LOW,true);g.preset_mid=button(L"均衡",ID_PRESET_MID,false);g.preset_high=button(L"高清",ID_PRESET_HIGH,false);
    g.current_label=control(L"STATIC",L"当前设备",SS_CENTERIMAGE,0);
    g.single_start=button(L"▶ 启动此设备",ID_SINGLE_START,true);g.reconnect=button(L"重新连接",ID_RECONNECT,false);g.single_stop=button(L"停止此设备",ID_SINGLE_STOP,false);
    g.quick_label=control(L"STATIC",L"快捷操作",SS_CENTERIMAGE,0);
    g.tile=button(L"排列窗口",ID_TILE,false);g.save=button(L"保存配置",ID_SAVE,false);g.log=button(L"查看日志",ID_LOG,false);
    g.apply=button(L"应用到勾选设备（重启投屏）",ID_APPLY,false);
    g.settings_label=control(L"STATIC",L"功能开关",SS_CENTERIMAGE,0);
    g.audio=toggle(L"音频转发",ID_AUDIO);g.record=toggle(L"屏幕录制",ID_RECORD);
    g.buffer_check=toggle(L"额外视频缓存",ID_BUFFER_CHECK);g.buffer_edit=edit(ID_BUFFER,true);
    g.buffer_label=control(L"STATIC",L"时长（ms）",SS_CENTERIMAGE,0);
    g.topmost=toggle(L"窗口置顶",ID_TOPMOST);g.remember=toggle(L"记住窗口位置",ID_REMEMBER);
    g.text_input=toggle(L"中文输入",ID_TEXT);g.images=toggle(L"图片粘贴到相册",ID_IMAGES);
    g.auto_reconnect=toggle(L"自动重连",ID_AUTO);g.borderless=toggle(L"投屏窗口无边框",ID_BORDERLESS);
    g.record_dir=button(L"录屏文件夹",ID_RECORD_DIR,false);g.log_dir=button(L"日志文件夹",ID_LOG_DIR,false);
    g.help=control(L"STATIC",L"设置用于下次启动；运行中请点击应用。",0,0);
    g.footer=control(L"STATIC",L"● 已连接 0 台   ·   运行中 0 台",SS_CENTERIMAGE,0);
    g.start_checked=button(L"▶ 启动所选",ID_START_CHECKED,false);g.stop_all=button(L"■ 停止全部",ID_STOP_ALL,false);g.start_all=button(L"▶ 全部启动",ID_START_ALL,true);
    // Retain keyboard command handlers for existing actions.
    g.stop_checked=button(L"停止勾选",ID_STOP_CHECKED,false);g.focus=button(L"查看窗口",ID_FOCUS,false);g.reset=button(L"恢复推荐",ID_RESET,false);
    g.status=control(L"STATIC",L"就绪 · 每台手机保留独立投屏窗口",0,0);
    set_fonts();load_profile();layout();update_rows();
}
static void device_section(const struct device *d,wchar_t *out,size_t capacity) {
    size_t n=0;const wchar_t *prefix=L"device-";
    while(*prefix&&n+1<capacity)out[n++]=*prefix++;
    for(const wchar_t *p=d->serial;*p&&n+4<capacity;++p)n+=(size_t)swprintf(out+n,capacity-n,L"%04x",(unsigned)*p);
    out[n]=0;
}
static void unicode_ini(void) {
#ifdef MANAGER_SMOKE_TEST
    if(g.smoke)return;
#endif
    if(GetFileAttributesW(g.ini)==INVALID_FILE_ATTRIBUTES) {
        HANDLE f=CreateFileW(g.ini,GENERIC_WRITE,0,NULL,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,NULL);
        if(f!=INVALID_HANDLE_VALUE){wchar_t bom=0xfeff;DWORD written;WriteFile(f,&bom,2,&written,NULL);CloseHandle(f);}
    } else {
        // Upgrade legacy ASCII profile before writing Unicode device names.
        HANDLE f=CreateFileW(g.ini,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,0,NULL);
        if(f!=INVALID_HANDLE_VALUE) {
            DWORD size=GetFileSize(f,NULL),got=0;char *bytes=size<1024*1024?calloc(size+1,1):NULL;
            if(bytes&&ReadFile(f,bytes,size,&got,NULL)&&got==size&&!(size>=2&&(unsigned char)bytes[0]==255&&(unsigned char)bytes[1]==254)) {
                int len=MultiByteToWideChar(CP_ACP,0,bytes,(int)size,NULL,0);
                wchar_t *wide=calloc((size_t)len+1,sizeof(wchar_t));
                if(wide&&(!len||MultiByteToWideChar(CP_ACP,0,bytes,(int)size,wide,len))) {
                    CloseHandle(f);f=INVALID_HANDLE_VALUE;
                    wchar_t temp[PATH_SIZE];swprintf(temp,PATH_SIZE,L"%ls.unicode.tmp",g.ini);
                    HANDLE dest=CreateFileW(temp,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,0,NULL);
                    if(dest!=INVALID_HANDLE_VALUE){wchar_t bom=0xfeff;DWORD written;bool ok=WriteFile(dest,&bom,2,&written,NULL)&&WriteFile(dest,wide,(DWORD)len*2,&written,NULL);CloseHandle(dest);if(ok)MoveFileExW(temp,g.ini,MOVEFILE_REPLACE_EXISTING);else DeleteFileW(temp);}
                }
                free(wide);
            }
            free(bytes);if(f!=INVALID_HANDLE_VALUE)CloseHandle(f);
        }
    }
}
static void load_device(struct device *d) {
    wchar_t section[600];device_section(d,section,600);
    GetPrivateProfileStringW(section,L"name",d->alias,d->alias,64,g.ini);
    d->desired=wm_default_profile();
    if(GetPrivateProfileIntW(section,L"saved",0,g.ini)) {
#define DEV_READ(field,key) d->desired.field=GetPrivateProfileIntW(section,key,d->desired.field,g.ini)
        DEV_READ(max_size,L"size");DEV_READ(max_fps,L"fps");DEV_READ(bitrate,L"bitrate");DEV_READ(buffer_ms,L"buffer");DEV_READ(hwdec,L"hwdec");
        DEV_READ(audio,L"audio");DEV_READ(record,L"record");DEV_READ(topmost,L"topmost");DEV_READ(borderless,L"borderless");DEV_READ(text_input,L"text_input");DEV_READ(clipboard_images,L"images");
#undef DEV_READ
    } else { struct wm_profile p;if(read_profile(&p))d->desired=p; }
    if(!wm_profile_valid(&d->desired))d->desired=wm_default_profile();
    int x=(int)GetPrivateProfileIntW(section,L"x",0,g.ini),y=(int)GetPrivateProfileIntW(section,L"y",0,g.ini);
    int w=(int)GetPrivateProfileIntW(section,L"width",0,g.ini),h=(int)GetPrivateProfileIntW(section,L"height",0,g.ini);
    if(w>=100&&w<=10000&&h>=100&&h<=10000&&x>-100000&&x<100000&&y>-100000&&y<100000) {
        d->geometry=(RECT){x,y,x+w,y+h};d->geometry_valid=true;
    }
}
static void save_device(struct device *d) {
#ifdef MANAGER_SMOKE_TEST
    if(g.smoke)return;
#endif
    unicode_ini();wchar_t section[600],text[64];device_section(d,section,600);
    WritePrivateProfileStringW(section,L"name",d->alias,g.ini);
    const wchar_t *keys[]={L"size",L"fps",L"bitrate",L"buffer",L"hwdec",L"audio",L"record",L"topmost",L"borderless",L"text_input",L"images",L"saved"};
    unsigned values[]={d->desired.max_size,d->desired.max_fps,d->desired.bitrate,d->desired.buffer_ms,d->desired.hwdec,d->desired.audio,d->desired.record,d->desired.topmost,d->desired.borderless,d->desired.text_input,d->desired.clipboard_images,1};
    for(unsigned i=0;i<sizeof(values)/sizeof(*values);++i){swprintf(text,64,L"%u",values[i]);WritePrivateProfileStringW(section,keys[i],text,g.ini);}
    if(d->geometry_valid&&checked(g.remember)) {
        const wchar_t *k[]={L"x",L"y",L"width",L"height"};LONG v[]={d->geometry.left,d->geometry.top,d->geometry.right-d->geometry.left,d->geometry.bottom-d->geometry.top};
        for(unsigned i=0;i<4;++i){swprintf(text,64,L"%ld",v[i]);WritePrivateProfileStringW(section,k[i],text,g.ini);}
    }
}
static void capture_geometry(struct device *d) {
    HWND h=phone_window(d);if(!h||!checked(g.remember)||d->restore_geometry)return;
    WINDOWPLACEMENT p={0};p.length=sizeof(p);
    if(GetWindowPlacement(h,&p)) {
        RECT r;if(p.showCmd==SW_SHOWNORMAL&&!IsIconic(h)&&!IsZoomed(h))GetWindowRect(h,&r);
        else { // rcNormalPosition uses workspace coordinates, not screen coordinates.
            r=p.rcNormalPosition;MONITORINFO mi={sizeof(mi),{0},{0},0};
            if(GetMonitorInfoW(MonitorFromWindow(h,MONITOR_DEFAULTTONEAREST),&mi))OffsetRect(&r,mi.rcWork.left-mi.rcMonitor.left,mi.rcWork.top-mi.rcMonitor.top);
        }
        if(r.right-r.left>=100&&r.bottom-r.top>=100){d->geometry=r;d->geometry_valid=true;}
    }
}
static bool contains_case(const wchar_t *text,const wchar_t *query) {
    if(!*query)return true;size_t n=wcslen(query);
    for(;*text;++text)if(!_wcsnicmp(text,query,n))return true;
    return false;
}
static void rebuild_list(void) {
    if(!g.list)return;
    wchar_t query[160];GetWindowTextW(g.search,query,160);
    int desired[WM_MAX_DEVICES],count=0;
    for(size_t i=0;i<g.count;++i)if(contains_case(g.devices[i].alias,query)||contains_case(g.devices[i].serial,query)||contains_case(g.devices[i].model,query))desired[count++]=(int)i;
    bool same=count==g.visible_count;
    for(int i=0;same&&i<count;++i)same=g.row_map[i]==desired[i];
    if(same)return;
    g.rebuilding=true;SendMessageW(g.list,WM_SETREDRAW,FALSE,0);ListView_DeleteAllItems(g.list);g.visible_count=count;
    for(int i=0;i<count;++i){g.row_map[i]=desired[i];LVITEMW item={0};item.mask=LVIF_TEXT;item.iItem=i;item.pszText=g.devices[desired[i]].alias;ListView_InsertItem(g.list,&item);ListView_SetCheckState(g.list,i,g.devices[desired[i]].checked);if(desired[i]==g.selected)ListView_SetItemState(g.list,i,LVIS_SELECTED|LVIS_FOCUSED,LVIS_SELECTED|LVIS_FOCUSED);}
    SendMessageW(g.list,WM_SETREDRAW,TRUE,0);g.rebuilding=false;InvalidateRect(g.list,NULL,FALSE);
    if(g.selected<0&&count)select_device(desired[0]);
}
static void select_device(int index) {
    if(g.rename_edit){DestroyWindow(g.rename_edit);g.rename_edit=NULL;SetWindowTextW(g.rename,L"命名");}
    if(index<0||(size_t)index>=g.count)return;
    g.selected=index;set_profile(&g.devices[index].desired);update_rows();
    InvalidateRect(g.list,NULL,FALSE);
}
static void refresh_devices_silent(void) {
    if(g.scanning||g.closing)return;
    begin_scan(true);
}
struct reconnect_result {int index;struct capture_result *capture;};
static DWORD WINAPI reconnect_thread(void *data) {
    struct reconnect_result *r=data;wchar_t command[WM_COMMAND_SIZE];
    // Device serials from ADB cannot contain whitespace; quote anyway and reject quotes.
    const wchar_t *serial=g.devices[r->index].serial;
    if(!wcschr(serial,L'"')) {
        swprintf(command,WM_COMMAND_SIZE,L"\"%ls\" -s \"%ls\" reconnect",g.adb,serial);
        r->capture=capture(g.adb,command);
    }
    if(!PostMessageW(g.window,RECONNECT_MESSAGE,0,(LPARAM)r)){free(r->capture);free(r);}return 0;
}
static void reconnect_device(int index) {
    if(index<0||(size_t)index>=g.count)return;struct device *d=&g.devices[index];
    if(d->reconnect_job)return;
    d->manual_reconnect=true;
    if(!d->connected){status(L"此手机已断开：请接好数据线并允许调试；正在重新检测，不影响其他手机。");d->wanted=true;d->retries=0;d->retry_at=GetTickCount64()+3000;refresh_devices();return;}
    if(d->state==WM_DEVICE_UNAUTHORIZED){status(L"请先在这台手机上确认“允许 USB 调试”，然后刷新设备。");refresh_devices();return;}
    if(d->process){struct wm_profile p;if(index==g.selected&&read_profile(&p))d->desired=p;save_device(d);close_phone(d);d->restart=true;d->wanted=true;d->retries=0;return;}
    if(d->state==WM_DEVICE_READY){single_action(index,ID_SINGLE_START);return;}
    struct reconnect_result *r=calloc(1,sizeof(*r));if(!r){status(L"重连失败：内存不足。");return;}r->index=index;
    d->wanted=true;d->retries=0;d->reconnect_job=true;++g.jobs;
    HANDLE thread=CreateThread(NULL,0,reconnect_thread,r,0,NULL);
    if(thread)CloseHandle(thread);else {--g.jobs;d->reconnect_job=false;free(r);status(L"无法启动重连任务，请重试。");}
}
static void single_action(int index,int action) {
    if(index<0||(size_t)index>=g.count){status(L"请先选择一台设备。");return;}
    struct device *d=&g.devices[index];
    if(action==ID_SINGLE_STOP){d->wanted=false;d->manual_reconnect=false;d->restart=false;d->retries=0;close_phone(d);status(L"仅停止这台手机，其他投屏保持运行。");}
    else if(action==ID_FOCUS){HWND h=phone_window(d);if(h){ShowWindow(h,SW_RESTORE);SetForegroundWindow(h);}}
    else if(action==ID_RECONNECT)reconnect_device(index);
    else {
        if(d->process||d->pending)return;
        if(!d->connected||d->state!=WM_DEVICE_READY){reconnect_device(index);return;}
        struct wm_profile p;if(!read_profile(&p))return;
        d->desired=p;d->wanted=true;d->retries=0;d->pending=true;save_device(d);save_profile(&p);status(L"这台手机已加入启动队列，其他设备不受影响。");
    }
    update_rows();
}
static uint64_t file_time(FILETIME t){return ((uint64_t)t.dwHighDateTime<<32)|t.dwLowDateTime;}
static void sample_fps(struct device *d,ULONGLONG now) {
    if(!d->log_path[0])return;
    HANDLE f=CreateFileW(d->log_path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,0,NULL);if(f==INVALID_HANDLE_VALUE)return;
    LARGE_INTEGER size;if(!GetFileSizeEx(f,&size)){CloseHandle(f);return;}
    // Bound work if the phone produced a very large diagnostic burst.
    if((uint64_t)size.QuadPart>d->log_offset+8192){d->log_offset=(uint64_t)size.QuadPart-8192;d->log_partial_size=0;}
    LARGE_INTEGER pos;pos.QuadPart=(LONGLONG)d->log_offset;SetFilePointerEx(f,pos,NULL,FILE_BEGIN);
    char bytes[8192];DWORD got=0;if(ReadFile(f,bytes,sizeof(bytes),&got,NULL)) {
        d->log_offset+=got;
        for(DWORD i=0;i<got;++i) {
            char c=bytes[i];
            if(c=='\n') {
                d->log_partial[d->log_partial_size]=0;
                char *fps=strstr(d->log_partial," fps");
                if(fps){char *n=fps;while(n>d->log_partial&&n[-1]>='0'&&n[-1]<='9')--n;if(n<fps){d->fps=(unsigned)strtoul(n,NULL,10);d->fps_at=now;}}
                d->log_partial_size=0;
            } else if(d->log_partial_size+1<sizeof(d->log_partial))d->log_partial[d->log_partial_size++]=c;
        }
    }
    CloseHandle(f);
}
static void sample_devices(ULONGLONG now) {
    for(size_t i=0;i<g.count;++i){struct device *d=&g.devices[i];if(!d->process)continue;
        FILETIME creation,exit,kernel,user;
        if(GetProcessTimes(d->process,&creation,&exit,&kernel,&user)) {
            uint64_t total=file_time(kernel)+file_time(user);
            if(d->sample_at&&now>d->sample_at&&total>=d->cpu_time)d->cpu=(double)(total-d->cpu_time)/((double)(now-d->sample_at)*10000)*100/(g.processors?g.processors:1);
            d->cpu_time=total;d->sample_at=now;
        }
        PROCESS_MEMORY_COUNTERS mem={0};mem.cb=sizeof(mem);if(GetProcessMemoryInfo(d->process,&mem,sizeof(mem)))d->memory=mem.WorkingSetSize;
        sample_fps(d,now);capture_geometry(d);
        if(now-d->started_at>=60000)d->retries=0;
    }
}
static void draw_text_at(HDC dc,const wchar_t *text,RECT r,COLORREF color,bool center) {
    SetTextColor(dc,color);SetBkMode(dc,TRANSPARENT);DrawTextW(dc,text,-1,&r,DT_SINGLELINE|DT_VCENTER|DT_END_ELLIPSIS|(center?DT_CENTER:0));
}
static void draw_device(const DRAWITEMSTRUCT *di) {
    if(di->itemID>=(UINT)g.visible_count)return;
    int index=g.row_map[di->itemID];struct device *d=&g.devices[index];HDC dc=di->hDC;RECT r=di->rcItem;
    int saved=SaveDC(dc);IntersectClipRect(dc,r.left,r.top,r.right,r.bottom);
    wm_theme_child_background(g.list,dc);
    bool selected=index==g.selected;
    if(selected)wm_theme_round(dc,r.left+scaled(2),r.top+scaled(3),r.right-r.left-scaled(5),r.bottom-r.top-scaled(6),12,0xC9DAE9FF,0);
    int y=(r.top+r.bottom)/2,x=r.left;
    wm_theme_round(dc,x+scaled(8),y-scaled(9),scaled(18),scaled(18),4,d->checked?0xFF007AFF:0xFFFFFFFF,0xFFB7BFCA);
    if(d->checked){RECT c={x+scaled(8),y-scaled(10),x+scaled(26),y+scaled(10)};draw_text_at(dc,L"✓",c,RGB(255,255,255),true);}
    // Deliberately draw a simple phone icon instead of a heavy thumbnail renderer.
    wm_theme_round(dc,x+scaled(39),y-scaled(23),scaled(25),scaled(46),5,0xFF2869BA,0xFF112C4B);
    wm_theme_round(dc,x+scaled(42),y-scaled(19),scaled(19),scaled(36),3,0xFF8EC8FF,0);
    RECT name={x+scaled(76),y-scaled(29),r.right-scaled(148),y-scaled(3)};
    SelectObject(dc,g.section_font);draw_text_at(dc,d->alias,name,RGB(30,40,55),false);SelectObject(dc,g.font);
    RECT serial={x+scaled(76),y+scaled(6),r.right-scaled(130),y+scaled(29)};

    const wchar_t *state=device_state(d);
    COLORREF color;unsigned fill;
    if(!d->connected){color=RGB(214,55,64);fill=0xFFFFE2E2;}
    else if(d->state!=WM_DEVICE_READY||d->last_exit){color=RGB(175,116,13);fill=0xFFFFF0C8;}
    else if(d->process){color=RGB(28,136,66);fill=0xFFDDF3E1;}
    else {color=RGB(0,112,240);fill=0xFFDCEBFF;}
    int actions=d->process?2:1;
    int buttonw=scaled(actions==2?53:82),end=r.right-scaled(10);
    if(actions==2) {
        wm_theme_round(dc,end-2*buttonw-scaled(6),y-scaled(16),buttonw,scaled(32),8,0xEEFFFFFF,0xFFDEE3EB);
        RECT b={end-2*buttonw-scaled(6),y-scaled(16),end-buttonw-scaled(6),y+scaled(16)};draw_text_at(dc,L"查看",b,RGB(50,75,100),true);
    }
    bool blue=d->connected&&d->state==WM_DEVICE_READY&&!d->process;
    wm_theme_round(dc,end-buttonw,y-scaled(16),buttonw,scaled(32),8,blue?0xFF007AFF:0xEEFFFFFF,0xFFDEE3EB);
    RECT b={end-buttonw,y-scaled(16),end,y+scaled(16)};
    draw_text_at(dc,d->process?L"停止":!d->connected?L"重新检测":d->state!=WM_DEVICE_READY||d->last_exit?L"重连":L"启动",b,blue?RGB(255,255,255):d->process?RGB(211,68,62):RGB(45,78,110),true);
    // State is a second line under the device name, ahead of row actions.
    RECT badge={x+scaled(76),y-scaled(3),end-(actions==2?2*buttonw+scaled(12):buttonw+scaled(8)),y+scaled(18)};
    int badge_width=scaled((int)wcslen(state)*12+20);if(badge_width>badge.right-badge.left)badge_width=badge.right-badge.left;
    if(badge_width>0){badge.right=badge.left+badge_width;wm_theme_round(dc,badge.left,badge.top,badge_width,badge.bottom-badge.top,10,fill,0);draw_text_at(dc,state,badge,color,true);}
    // Put serial below the status to avoid overlap at compact widths.
    serial.top=y+scaled(20);serial.bottom=y+scaled(39);draw_text_at(dc,d->serial,serial,RGB(130,136,148),false);
    if(di->itemState&ODS_FOCUS){RECT f=r;InflateRect(&f,-scaled(3),-scaled(3));DrawFocusRect(dc,&f);}
    RestoreDC(dc,saved);
}
static LRESULT CALLBACK device_list_proc(HWND h,UINT m,WPARAM w,LPARAM l,UINT_PTR id,DWORD_PTR data) {
    (void)id;(void)data;
    if(m==WM_LBUTTONDOWN) {
        LVHITTESTINFO hit={0};hit.pt.x=GET_X_LPARAM(l);hit.pt.y=GET_Y_LPARAM(l);int row=ListView_HitTest(h,&hit);
        if(row>=0&&row<g.visible_count) {
            int index=g.row_map[row];RECT r;ListView_GetItemRect(h,row,&r,LVIR_BOUNDS);
            if(hit.pt.x<scaled(34)){g.devices[index].checked=!g.devices[index].checked;g.rebuilding=true;ListView_SetCheckState(h,row,g.devices[index].checked);g.rebuilding=false;InvalidateRect(h,NULL,FALSE);return 0;}
            select_device(index);ListView_SetItemState(h,row,LVIS_SELECTED|LVIS_FOCUSED,LVIS_SELECTED|LVIS_FOCUSED);
            if(hit.pt.x>r.right-scaled(g.devices[index].process?128:100)) {
                int action=g.devices[index].process?(hit.pt.x<r.right-scaled(69)?ID_FOCUS:ID_SINGLE_STOP):(!g.devices[index].connected||g.devices[index].state!=WM_DEVICE_READY||g.devices[index].last_exit?ID_RECONNECT:ID_SINGLE_START);
                single_action(index,action);return 0;
            }
        }
    }
    if(m==WM_KEYDOWN&&w==VK_RETURN&&g.selected>=0){single_action(g.selected,g.devices[g.selected].process?ID_FOCUS:ID_SINGLE_START);return 0;}
    return DefSubclassProc(h,m,w,l);
}
#ifdef MANAGER_SMOKE_TEST
static LRESULT CALLBACK smoke_phone_proc(HWND h,UINT m,WPARAM w,LPARAM l) {
    if(m==WM_TIMER) { DestroyWindow(h); return 0; }
    if(m==WM_DESTROY) { PostQuitMessage(0); return 0; }
    return DefWindowProcW(h,m,w,l);
}
static int smoke_phone(HINSTANCE instance) {
    int count; LPWSTR *args=CommandLineToArgvW(GetCommandLineW(),&count);
    const wchar_t *title=L"Smoke phone";
    for(int i=1;i+1<count;++i) if(!wcscmp(args[i],L"--window-title")) title=args[i+1];
    WNDCLASSW cls={0}; cls.hInstance=instance; cls.lpfnWndProc=smoke_phone_proc; cls.lpszClassName=L"ManagerSmokePhone";
    RegisterClassW(&cls);
    HWND h=CreateWindowW(cls.lpszClassName,title,WS_OVERLAPPEDWINDOW,100,100,300,500,NULL,NULL,instance,NULL);
    LocalFree(args);
    if(!h || GetConsoleWindow()!=NULL) return 20;
    ShowWindow(h,SW_SHOW); SetTimer(h,1,60000,NULL);
    const char text[]="fake-phone: no console; explicit handles inherited correctly\nINFO: 30 fps\n"; DWORD written;
    WriteFile(GetStdHandle(STD_OUTPUT_HANDLE),text,sizeof(text)-1,&written,NULL);
    MSG msg;
    while(GetMessageW(&msg,NULL,0,0)>0) { TranslateMessage(&msg); DispatchMessageW(&msg); }
    return 0;
}
static void smoke_screenshot(const wchar_t *leaf) {
    RedrawWindow(g.window,NULL,NULL,RDW_INVALIDATE|RDW_UPDATENOW|RDW_ALLCHILDREN);
    RECT r; GetClientRect(g.window,&r);
    HDC screen=GetDC(g.window), mem=CreateCompatibleDC(screen);
    BITMAPINFO info; ZeroMemory(&info,sizeof(info));
    info.bmiHeader.biSize=sizeof(BITMAPINFOHEADER); info.bmiHeader.biWidth=r.right;
    info.bmiHeader.biHeight=-r.bottom; info.bmiHeader.biPlanes=1; info.bmiHeader.biBitCount=32;
    void *bits; HBITMAP bmp=CreateDIBSection(screen,&info,DIB_RGB_COLORS,&bits,NULL,0);
    if(bmp) {
        HGDIOBJ old=SelectObject(mem,bmp);
        BitBlt(mem,0,0,r.right,r.bottom,screen,0,0,SRCCOPY);
        BITMAPFILEHEADER header={0}; header.bfType=0x4d42;
        header.bfOffBits=sizeof(header)+sizeof(BITMAPINFOHEADER);
        DWORD bytes=(DWORD)(r.right*r.bottom*4); header.bfSize=header.bfOffBits+bytes;
        wchar_t path[PATH_SIZE]; join_path(path,PATH_SIZE,g.directory,leaf);
        HANDLE file=CreateFileW(path,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,0,NULL); DWORD written;
        if(file!=INVALID_HANDLE_VALUE) {
            WriteFile(file,&header,sizeof(header),&written,NULL);
            WriteFile(file,&info.bmiHeader,sizeof(BITMAPINFOHEADER),&written,NULL);
            WriteFile(file,bits,bytes,&written,NULL); CloseHandle(file);
        }
        SelectObject(mem,old); DeleteObject(bmp);
    }
    DeleteDC(mem); ReleaseDC(g.window,screen);
}
static int smoke_test(void) {
    struct wm_profile p;
    if (!read_profile(&p) || p.max_size != 1280 || p.max_fps != 30 || p.audio || p.record || p.buffer_ms) return 10;
    SendMessageW(g.audio,BM_CLICK,0,0);
    if(!checked(g.audio))return 21;
    SendMessageW(g.audio,BM_CLICK,0,0);
    if(checked(g.audio))return 22;
    SendMessageW(g.fps_check,BM_CLICK,0,0);
    if(checked(g.fps_check)||IsWindowEnabled(g.fps_edit))return 23;
    SendMessageW(g.fps_check,BM_CLICK,0,0);
    check(g.size_check,false); check(g.fps_check,false); check(g.buffer_check,false); check(g.audio,true); check(g.record,true);
    if (!read_profile(&p) || p.max_size || p.max_fps || p.buffer_ms || !p.audio || !p.record) return 11;
    p=wm_default_profile(); set_profile(&p);
    wchar_t test_image[PATH_SIZE];join_path(test_image,PATH_SIZE,g.directory,L"theme-test.bmp");
    HANDLE image=CreateFileW(test_image,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,0,NULL);
    if(image==INVALID_HANDLE_VALUE)return 24;
    BITMAPFILEHEADER image_header={0};image_header.bfType=0x4d42;image_header.bfOffBits=54;image_header.bfSize=70;
    BITMAPINFOHEADER image_info={0};image_info.biSize=40;image_info.biWidth=2;image_info.biHeight=2;image_info.biPlanes=1;image_info.biBitCount=32;
    DWORD pixels[4]={0x00F0D0A0,0x00B0D0E0,0x00C0F0A0,0x00D0A0F0},written;
    WriteFile(image,&image_header,sizeof(image_header),&written,NULL);WriteFile(image,&image_info,sizeof(image_info),&written,NULL);
    WriteFile(image,pixels,sizeof(pixels),&written,NULL);CloseHandle(image);
    unsigned generation=wm_theme_generation();
    if(wm_theme_test_wallpaper(L"Z:\\definitely-missing-wallpaper.png"))return 25;
    if(!wm_theme_test_wallpaper(test_image)||wm_theme_generation()<=generation)return 26;
    if(!DeleteFileW(test_image))return 27; // Original image file is not kept locked.
    wm_theme_test_wallpaper(NULL);
    wchar_t bundled[PATH_SIZE];join_path(bundled,PATH_SIZE,g.directory,L"wallpaper.png");
    if(GetFileAttributesW(bundled)!=INVALID_FILE_ATTRIBUTES&&!wm_theme_test_wallpaper(bundled))return 29;
    wchar_t self[PATH_SIZE], cmd[PATH_SIZE+50]; GetModuleFileNameW(NULL,self,PATH_SIZE);
    swprintf(cmd,PATH_SIZE+50,L"\"%ls\" --self-test-helper",self);
    struct capture_result *result=capture(self,cmd);
    if (!result || result->error || result->exit_code || !strstr(result->output,"smoke-device")) { free(result); return 12; }
    merge_devices(result->output); free(result);
    if (g.count!=1 || !ListView_GetCheckState(g.list,0)) return 13;
    wcscpy(g.exe,self); // The test-only executable acts as a simulated phone.
    start_devices(true,false); tick();
    if(!g.devices[0].process) return 14;
    DWORD original=g.devices[0].pid;
    start_devices(true,false);
    if(g.devices[0].pid!=original || g.devices[0].pending) return 15;
    ULONGLONG deadline=GetTickCount64()+5000;
    while(!phone_window(&g.devices[0]) && GetTickCount64()<deadline) Sleep(20);
    if(!g.devices[0].window) return 16;
    stop_devices(true);
    while(g.devices[0].process && GetTickCount64()<deadline) { tick(); Sleep(20); }
    if(g.devices[0].process || g.devices[0].last_exit) return 17;
    wchar_t tail[128]; swprintf(tail,128,L"界面与进程测试通过；日志保存正常；无控制台黑框。"); status(tail);
    merge_devices("smoke-device device model:SM_A376B\nphone-02 device model:Pixel_8\nphone-03 device model:Pixel_8\nphone-04 device model:SM_A376B\nphone-05 device model:SM_A376B\nphone-06 device model:Pixel_8\nphone-07 device model:SM_A376B\nphone-08 device model:Pixel_8\nphone-09 device model:SM_A376B\nphone-10 device model:SM_A376B\n");
    unsigned stable_generation=wm_theme_generation();
    start_devices(true,false);
    deadline=GetTickCount64()+14000;
    unsigned windows=0;
    do {
        tick(); windows=0;
        for(size_t i=0;i<g.count;++i) if(phone_window(&g.devices[i])) ++windows;
        if(windows==10) break;
        Sleep(30);
    } while(GetTickCount64()<deadline);
    if(windows!=10) return 18;
    if(wm_theme_generation()!=stable_generation)return 28;
    // A failed phone is restarted independently; its neighbours retain their PID.
    DWORD neighbour=g.devices[1].pid,failed=g.devices[0].pid;
    TerminateProcess(g.devices[0].process,7);WaitForSingleObject(g.devices[0].process,2000);tick();
    if(!g.devices[0].wanted||g.devices[0].process)return 30;
    g.devices[0].retry_at=0;g.next_launch=0;tick();
    if(!g.devices[0].process||g.devices[0].pid==failed||g.devices[1].pid!=neighbour)return 31;
    deadline=GetTickCount64()+5000;
    while(!phone_window(&g.devices[0])&&GetTickCount64()<deadline)Sleep(20);
    // Explicit stop remains stopped even with auto reconnect enabled.
    single_action(0,ID_SINGLE_STOP);
    while(g.devices[0].process&&GetTickCount64()<deadline){tick();Sleep(20);}
    g.devices[0].retry_at=0;tick();
    if(g.devices[0].process||g.devices[0].pending||g.devices[0].wanted||g.devices[1].pid!=neighbour)return 32;
    // Offline devices are never launched. Manual recovery works with auto off.
    check(g.auto_reconnect,false);g.devices[0].state=WM_DEVICE_OFFLINE;g.devices[0].wanted=true;tick();
    if(g.devices[0].process||g.devices[0].pending)return 33;
    g.devices[0].state=WM_DEVICE_READY;g.devices[0].manual_reconnect=true;g.devices[0].retry_at=0;g.next_launch=0;tick();
    if(!g.devices[0].process||g.devices[1].pid!=neighbour)return 34;
    check(g.auto_reconnect,true);
    // Real window placement can be captured and retained without changing neighbours.
    deadline=GetTickCount64()+5000;
    while(!phone_window(&g.devices[0])&&GetTickCount64()<deadline)Sleep(20);
    tick();
    SetWindowPos(g.devices[0].window,NULL,110,130,330,510,SWP_NOZORDER);capture_geometry(&g.devices[0]);
    if(!g.devices[0].geometry_valid||g.devices[0].geometry.left!=110||g.devices[0].geometry.top!=130)return 35;
    // Exercise filter mapping, independent checkbox state, and per-device profile selection.
    SetWindowTextW(g.search,L"phone-03");rebuild_list();
    if(g.visible_count!=1||g.row_map[0]!=2)return 36;
    g.devices[2].desired.max_size=1600;select_device(2);
    if(!read_profile(&p)||p.max_size!=1600)return 37;
    SetWindowTextW(g.search,L"");rebuild_list();if(g.visible_count!=10)return 38;
    // Write/read an isolated Unicode settings file, leaving user settings untouched.
    wchar_t original_ini[PATH_SIZE];wcscpy(original_ini,g.ini);join_path(g.ini,PATH_SIZE,g.directory,L"smoke-profile.ini");
    DeleteFileW(g.ini);g.smoke=false;save_profile(&p);wcscpy(g.devices[2].alias,L"客服测试三");save_device(&g.devices[2]);
    struct device loaded={0};wcscpy(loaded.serial,g.devices[2].serial);load_device(&loaded);g.smoke=true;
    if(wcscmp(loaded.alias,L"客服测试三")||loaded.desired.max_size!=1600)return 39;
    DeleteFileW(g.ini);wcscpy(g.ini,original_ini);
    // Preview the actual UI with two running simulated phones and several states.
    for(size_t i=2;i<g.count;++i)single_action((int)i,ID_SINGLE_STOP);
    deadline=GetTickCount64()+5000;
    for(;;){tick();bool remaining=false;for(size_t i=2;i<g.count;++i)remaining|=g.devices[i].process!=NULL;if(!remaining)break;if(GetTickCount64()>deadline)return 40;Sleep(20);}
    for(size_t i=0;i<g.count;++i)swprintf(g.devices[i].alias,64,L"客服 %02u",(unsigned)i+1);
    g.devices[3].connected=false;g.devices[4].state=WM_DEVICE_OFFLINE;
    select_device(2);sample_devices(GetTickCount64());update_rows();ListView_EnsureVisible(g.list,0,FALSE);
    SetWindowTextW(g.subtitle,L"Scrcpy Manager · 界面验证预览（模拟设备）");
    SetForegroundWindow(g.window);UpdateWindow(g.window);smoke_screenshot(L"manager-smoke.bmp");
    SetWindowPos(g.window,NULL,0,0,1040,680,SWP_NOZORDER);layout();
    RECT small,button_rect;GetClientRect(g.window,&small);GetWindowRect(g.start_all,&button_rect);MapWindowPoints(NULL,g.window,(POINT*)&button_rect,2);
    if(button_rect.bottom>small.bottom||button_rect.right>small.right)return 41;
    smoke_screenshot(L"manager-smoke-small.bmp");
    stop_devices(true);deadline=GetTickCount64()+5000;
    unsigned active;
    do{tick();active=0;for(size_t i=0;i<g.count;++i)if(g.devices[i].process)++active;if(!active)break;Sleep(20);}while(GetTickCount64()<deadline);
    if(active)return 19;
    return 0;
}
#endif
static LRESULT CALLBACK window_proc(HWND window, UINT message, WPARAM w, LPARAM l) {
    switch(message) {
        case WM_CREATE: g.window=window; g.dpi=GetDpiForWindow(window);
            wm_theme_init(window,g.directory,g.ini);create_controls();SetTimer(window,TIMER_ID,250,NULL);return 0;
        case WM_ERASEBKGND: { RECT r;GetClientRect(window,&r);wm_theme_paint((HDC)w,&r);return 1; }
        case WM_PAINT: { PAINTSTRUCT p;HDC dc=BeginPaint(window,&p);wm_theme_paint(dc,&p.rcPaint);EndPaint(window,&p);return 0; }
        case WM_SIZE: layout(); return 0;
        case WM_GETMINMAXINFO: { MINMAXINFO *m=(MINMAXINFO*)l; m->ptMinTrackSize.x=scaled(1040);m->ptMinTrackSize.y=scaled(680); return 0; }
        case WM_DPICHANGED: { g.dpi=HIWORD(w); set_fonts(); RECT *r=(RECT*)l; SetWindowPos(window,NULL,r->left,r->top,r->right-r->left,r->bottom-r->top,SWP_NOZORDER); layout(); return 0; }
        case WM_CTLCOLOREDIT:
            SetTextColor((HDC)w,wm_theme_text_color());SetBkColor((HDC)w,RGB(243,245,248));return (LRESULT)wm_theme_input_brush(false);
        case WM_CTLCOLORSTATIC: {
            wchar_t cls[32];GetClassNameW((HWND)l,cls,32);
            if(!wcscmp(cls,L"EDIT")) {
                SetTextColor((HDC)w,RGB(145,145,155));SetBkColor((HDC)w,RGB(247,247,249));return (LRESULT)wm_theme_input_brush(true);
            }
            SetTextColor((HDC)w,wm_theme_text_color());SetBkMode((HDC)w,TRANSPARENT);return (LRESULT)GetStockObject(NULL_BRUSH);
        }
        case WM_CTLCOLORBTN: SetBkMode((HDC)w,TRANSPARENT);return (LRESULT)GetStockObject(NULL_BRUSH);
        case WM_DRAWITEM: {
            DRAWITEMSTRUCT *draw=(DRAWITEMSTRUCT*)l;
            if(draw->CtlID==ID_DEVICES){SelectObject(draw->hDC,g.font);draw_device(draw);return TRUE;}
            wm_theme_draw_button(draw,draw->CtlID==ID_START_ALL||draw->CtlID==ID_SINGLE_START||(g.preset_mode==1&&draw->CtlID==ID_PRESET_LOW)||(g.preset_mode==2&&draw->CtlID==ID_PRESET_MID)||(g.preset_mode==3&&draw->CtlID==ID_PRESET_HIGH),
                                 draw->CtlID==ID_STOP_ALL||draw->CtlID==ID_STOP_CHECKED||draw->CtlID==ID_SINGLE_STOP);return TRUE;
        }
        case WM_COMMAND:
            if(g.closing) return 0;
            switch(LOWORD(w)) {
                case ID_WALLPAPER:
                    if(wm_theme_choose_wallpaper())status(L"壁纸已更新并保存；毛玻璃背景使用静态缓存，不持续模糊渲染。");break;
                case ID_REFRESH: refresh_devices(); break;
                case ID_CHECK_ALL: case ID_UNCHECK:
                    g.rebuilding=true;
                    for(size_t i=0;i<g.count;++i)g.devices[i].checked=LOWORD(w)==ID_CHECK_ALL;
                    for(int i=0;i<g.visible_count;++i)ListView_SetCheckState(g.list,i,g.devices[g.row_map[i]].checked);
                    g.rebuilding=false;InvalidateRect(g.list,NULL,FALSE);break;
                case ID_START_ALL: start_devices(true,false); break;
                case ID_START_CHECKED: start_devices(false,false); break;
                case ID_STOP_ALL: stop_devices(true); break;
                case ID_STOP_CHECKED: stop_devices(false); break;
                case ID_APPLY: start_devices(false,true); break;
                case ID_RESET: { struct wm_profile p=wm_default_profile(); set_profile(&p); status(L"已恢复推荐参数，应用到运行中窗口需点击“应用到勾选设备”。"); break; }
                case ID_TILE: tile_windows(); break;
                case ID_FOCUS: focus_selected(); break;
                case ID_LOG: {
                    int i=g.selected;
                    if(i>=0 && g.devices[i].log_path[0]) {
                        wchar_t argument[PATH_SIZE+4]; swprintf(argument,PATH_SIZE+4,L"\"%ls\"",g.devices[i].log_path);
                        ShellExecuteW(window,L"open",L"notepad.exe",argument,g.directory,SW_SHOWNORMAL);
                    } else status(L"请先点击一台启动过的设备，再查看日志。"); break;
                }
                case ID_LOG_DIR: if(folder(g.logs)) ShellExecuteW(window,L"open",g.logs,NULL,g.directory,SW_SHOWNORMAL); break;
                case ID_RECORD_DIR: if(folder(g.recordings)) ShellExecuteW(window,L"open",g.recordings,NULL,g.directory,SW_SHOWNORMAL); break;
                case ID_SEARCH: if(HIWORD(w)==EN_CHANGE)rebuild_list();break;
                case ID_SINGLE_START:case ID_SINGLE_STOP:case ID_RECONNECT:single_action(g.selected,LOWORD(w));break;
                case ID_SAVE: {
                    struct wm_profile p;if(!read_profile(&p))break;
                    save_profile(&p);unsigned count=0;
                    if(g.selected>=0){g.devices[g.selected].desired=p;save_device(&g.devices[g.selected]);count=1;}
                    status(count?L"此设备配置已保存，下次启动或重连时生效。批量修改请使用“应用到勾选设备”。":L"默认配置已保存。");break;
                }
                case ID_PRESET_LOW:case ID_PRESET_MID:case ID_PRESET_HIGH: {
                    struct wm_profile p;if(!read_profile(&p))break;
                    if(LOWORD(w)==ID_PRESET_LOW){p.max_size=1280;p.max_fps=30;p.bitrate=2000000;}
                    else if(LOWORD(w)==ID_PRESET_MID){p.max_size=1600;p.max_fps=45;p.bitrate=4000000;}
                    else {p.max_size=1920;p.max_fps=60;p.bitrate=8000000;}
                    set_profile(&p);status(L"画质预设已选择；启动或点击应用后生效。音频、录屏等开关保持当前选择。");break;
                }
                case ID_REMEMBER:case ID_AUTO:
                    unicode_ini();WritePrivateProfileStringW(L"manager",LOWORD(w)==ID_AUTO?L"auto_reconnect":L"remember",checked(LOWORD(w)==ID_AUTO?g.auto_reconnect:g.remember)?L"1":L"0",g.ini);
                    if(LOWORD(w)==ID_AUTO&&!checked(g.auto_reconnect))for(size_t i=0;i<g.count;++i)if(!g.devices[i].process&&!g.devices[i].pending&&!g.devices[i].manual_reconnect)g.devices[i].wanted=false;
                    status(L"管理选项已保存。");break;
                case ID_RENAME: {
                    if(g.selected<0)break;
                    if(!g.rename_edit) {
                        RECT r;GetWindowRect(g.selected_title,&r);MapWindowPoints(NULL,g.window,(POINT*)&r,2);
                        g.rename_edit=control(L"EDIT",g.devices[g.selected].alias,WS_TABSTOP|ES_AUTOHSCROLL,0);
                        SendMessageW(g.rename_edit,EM_SETLIMITTEXT,40,0);SendMessageW(g.rename_edit,WM_SETFONT,(WPARAM)g.font,TRUE);
                        MoveWindow(g.rename_edit,r.left,r.top,r.right-r.left,r.bottom-r.top,TRUE);
                        SetWindowTextW(g.rename,L"保存名");SetFocus(g.rename_edit);SendMessageW(g.rename_edit,EM_SETSEL,0,-1);
                    } else {
                        wchar_t name[64];GetWindowTextW(g.rename_edit,name,64);
                        if(!*name){status(L"设备名称不能为空。");break;}
                        struct device *d=&g.devices[g.selected];wcscpy(d->alias,name);save_device(d);
                        HWND h=phone_window(d);if(h){wchar_t title[256];swprintf(title,256,L"%ls · %ls",d->alias,d->serial);SetWindowTextW(h,title);}
                        DestroyWindow(g.rename_edit);g.rename_edit=NULL;SetWindowTextW(g.rename,L"命名");update_rows();InvalidateRect(g.list,NULL,FALSE);
                    }break;
                }
                case ID_HWDEC: InvalidateRect(g.hwdec,NULL,FALSE); break;
                case ID_SIZE_CHECK:case ID_FPS_CHECK:case ID_BUFFER_CHECK:update_enabled();break;
            } return 0;
        case WM_NOTIFY: {
            NMHDR *n=(NMHDR*)l;
            if(n->idFrom==ID_DEVICES&&!g.rebuilding) {
                if(n->code==LVN_ITEMCHANGED) {
                    NMLISTVIEW *v=(NMLISTVIEW*)l;
                    if(v->iItem>=0&&v->iItem<g.visible_count){int i=g.row_map[v->iItem];
                        if((v->uNewState^v->uOldState)&LVIS_STATEIMAGEMASK)g.devices[i].checked=ListView_GetCheckState(g.list,v->iItem);
                        if((v->uNewState&LVIS_SELECTED)&&!(v->uOldState&LVIS_SELECTED))select_device(i);
                    }
                } else if(n->code==NM_DBLCLK)single_action(g.selected,g.selected>=0&&g.devices[g.selected].process?ID_FOCUS:ID_SINGLE_START);
            }return 0;
        }
        case RECONNECT_MESSAGE: {
            struct reconnect_result *r=(struct reconnect_result*)l;
            if(g.jobs)--g.jobs;
            if(r){struct device *d=&g.devices[r->index];d->reconnect_job=false;d->retry_at=GetTickCount64()+3000;
                if(!r->capture||r->capture->error||r->capture->exit_code)status(L"这台手机重连未完成，请检查数据线和 USB 调试；其他设备未改动。");
                else status(L"已请求重连这台手机，等待设备恢复。");
                free(r->capture);free(r);
            }
            refresh_devices();return 0;
        }
        case SCAN_MESSAGE: {
            struct capture_result *r=(struct capture_result*)l; g.scanning=false; EnableWindow(g.refresh,TRUE);
            if(!r) status(L"读取设备失败：内存不足。");
            else if(r->error || r->exit_code || r->overflow) {
                status(L"读取设备失败，请检查 adb.exe 和 USB 连接，再刷新。未更改已有窗口。");
                if(r->error&&!g.scan_silent)system_error(L"读取设备",r->error);
                else if(!g.closing&&!g.scan_silent) { wchar_t detail[1500]; utf8(detail,1500,r->output); error_box(*detail?detail:L"ADB 返回错误或设备列表过长。"); }
            } else merge_devices(r->output);
            free(r); return 0;
        }
        case WM_TIMER:
#ifdef MANAGER_SMOKE_TEST
            if(g.smoke) { KillTimer(window,TIMER_ID); int result=smoke_test(); DestroyWindow(window); PostQuitMessage(result); return 0; }
#endif
            tick(); return 0;
        case WM_CLOSE: {
            bool running=false; for(size_t i=0;i<g.count;++i) running|=g.devices[i].process!=NULL || g.devices[i].pending;
            if(running) {
                int answer=MessageBoxW(window,L"是否关闭本面板启动的投屏窗口？\n\n是：关闭投屏、等待录屏保存后退出。\n否：保留投屏窗口，仅退出控制面板。\n取消：返回。",L"退出控制面板",MB_YESNOCANCEL|MB_ICONQUESTION);
                if(answer==IDCANCEL) return 0;
                if(answer==IDYES) { g.closing=true; g.close_deadline=GetTickCount64()+15000; stop_devices(true); return 0; }
                g.keep_windows = true;
            }
            if(g.scanning||g.jobs) { g.closing=true; g.close_deadline=GetTickCount64()+16000; return 0; }
            DestroyWindow(window); return 0;
        }
        case WM_DESTROY:
            for(size_t i=0;i<g.count;++i){capture_geometry(&g.devices[i]);save_device(&g.devices[i]);}
            KillTimer(window,TIMER_ID);PostQuitMessage(0);return 0;
    }
    return DefWindowProcW(window,message,w,l);
}

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE previous, LPWSTR command_line, int show) {
    (void)previous; (void)command_line;
#ifdef MANAGER_SMOKE_TEST
    if(!wcscmp(command_line,L"--self-test-helper")) {
        const char text[]="List of devices attached\r\nsmoke-device device model:SM_A376B\r\n"; DWORD written;
        return WriteFile(GetStdHandle(STD_OUTPUT_HANDLE),text,sizeof(text)-1,&written,NULL)?0:2;
    }
    if(wcsstr(command_line,L"--text-via-clipboard")) return smoke_phone(instance);
    g.smoke=!wcscmp(command_line,L"--self-test");
#endif
    HANDLE singleton = CreateMutexW(NULL,FALSE,L"Local\\ScrcpySogouMultiManager");
    if(singleton && GetLastError()==ERROR_ALREADY_EXISTS) {
        HWND existing=FindWindowW(L"ScrcpyMultiManager",NULL);
        if(existing) { ShowWindow(existing,SW_RESTORE); SetForegroundWindow(existing); }
        CloseHandle(singleton); return 0;
    }
    g.instance=instance;g.dpi=96;g.selected=-1;
    SYSTEM_INFO system;GetSystemInfo(&system);g.processors=system.dwNumberOfProcessors;
    DWORD length=GetModuleFileNameW(NULL,g.directory,PATH_SIZE);
    if(!length || length>=PATH_SIZE-1) return 1;
    wchar_t *slash=wcsrchr(g.directory,L'\\'); if(!slash) return 1; *slash=0;
    wchar_t runtime[PATH_SIZE];
    if(!join_path(runtime,PATH_SIZE,g.directory,L"engine")) return 1;
    if(!join_path(g.exe,PATH_SIZE,runtime,L"scrcpy.exe")) return 1;
    if(GetFileAttributesW(g.exe)==INVALID_FILE_ATTRIBUTES) wcscpy(runtime,g.directory);
    if(!join_path(g.exe,PATH_SIZE,runtime,L"scrcpy.exe") || !join_path(g.adb,PATH_SIZE,runtime,L"adb.exe")
       || !join_path(g.logs,PATH_SIZE,g.directory,L"logs") || !join_path(g.recordings,PATH_SIZE,g.directory,L"recordings")
       || !join_path(g.ini,PATH_SIZE,g.directory,L"manager-settings.ini")) return 1;
#ifdef MANAGER_SMOKE_TEST
    if(!g.smoke)
#endif
    if(GetFileAttributesW(g.exe)==INVALID_FILE_ATTRIBUTES || GetFileAttributesW(g.adb)==INVALID_FILE_ATTRIBUTES) {
        MessageBoxW(NULL,L"请先把压缩包全部解压到一个新文件夹，再运行本程序。\n请保留 Manager.exe 旁的 engine 文件夹及其内容。",L"文件不完整",MB_OK|MB_ICONWARNING); return 1;
    }
    g.background=CreateSolidBrush(RGB(255,248,239)); g.white=CreateSolidBrush(RGB(255,255,255));
    INITCOMMONCONTROLSEX init={sizeof(init),ICC_LISTVIEW_CLASSES|ICC_STANDARD_CLASSES}; InitCommonControlsEx(&init);
    WNDCLASSEXW cls={0}; cls.cbSize=sizeof(cls); cls.lpfnWndProc=window_proc; cls.hInstance=instance;
    cls.hIcon=LoadIconW(instance,MAKEINTRESOURCEW(1)); cls.hIconSm=cls.hIcon;
    cls.hCursor=LoadCursorW(NULL,IDC_ARROW); cls.hbrBackground=g.background; cls.lpszClassName=L"ScrcpyMultiManager";
    if(!RegisterClassExW(&cls)) return 1;
    HWND window=CreateWindowExW(0,cls.lpszClassName,L"手机工作台 · Scrcpy Manager",WS_OVERLAPPEDWINDOW|WS_CLIPCHILDREN,
        CW_USEDEFAULT,CW_USEDEFAULT,1460,940,NULL,NULL,instance,NULL);
    if(!window) return 1;
    RECT work; SystemParametersInfoW(SPI_GETWORKAREA,0,&work,0);
    int width=scaled(1460), height=scaled(940);
    if(width>work.right-work.left-24) width=work.right-work.left-24;
    if(height>work.bottom-work.top-24) height=work.bottom-work.top-24;
    SetWindowPos(window,NULL,work.left+(work.right-work.left-width)/2,
        work.top+(work.bottom-work.top-height)/2,width,height,SWP_NOZORDER);
    ShowWindow(window,show); UpdateWindow(window);
#ifdef MANAGER_SMOKE_TEST
    if(!g.smoke)
#endif
    refresh_devices();
    MSG msg; BOOL result;
    while((result=GetMessageW(&msg,NULL,0,0))>0) {
        if(!IsDialogMessageW(window,&msg)) { TranslateMessage(&msg); DispatchMessageW(&msg); }
    }
    for(size_t i=0;i<g.count;++i) if(g.devices[i].process) CloseHandle(g.devices[i].process);
    if(g.row_images)ImageList_Destroy(g.row_images);
    wm_theme_destroy();
    DeleteObject(g.font);DeleteObject(g.title_font);DeleteObject(g.section_font);DeleteObject(g.compact_font);DeleteObject(g.background); DeleteObject(g.white);
    if(singleton) CloseHandle(singleton);
    return result==-1?1:(int)msg.wParam;
}
