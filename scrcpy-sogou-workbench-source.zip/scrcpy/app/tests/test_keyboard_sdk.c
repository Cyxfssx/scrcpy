#include "common.h"

#include <assert.h>
#include <stdlib.h>
#include <string.h>

#include "keyboard_sdk.h"
#include "android/keycodes.h"

static unsigned message_count;
static struct sc_control_msg captured;
static bool accept_messages = true;

// Exercise the real SDK processor, intercepting messages at the queue boundary.
bool
sc_controller_push_msg(struct sc_controller *controller,
                       const struct sc_control_msg *msg) {
    (void) controller;
    if (!accept_messages) {
        return false;
    }
    ++message_count;
    captured = *msg;
    return true;
}

static void
test_committed_text(void) {
    struct sc_keyboard_sdk kb;
    struct sc_controller controller;
    sc_keyboard_sdk_init(&kb, &controller, SC_KEY_INJECT_MODE_CLIPBOARD, true);
    const char *commits[] = {
        "\xe4\xbd\xa0\xe5\xa5\xbd", // Chinese
        "\xed\x95\x9c\xea\xb8\x80", // Korean
        "hello \xf0\x9f\x98\x80",     // ASCII and emoji
        "a", " ", "123", "a",       // Repeated commits must still paste
    };
    for (size_t i = 0; i < ARRAY_LEN(commits); ++i) {
        message_count = 0;
        struct sc_text_event event = {.text = commits[i]};
        kb.key_processor.ops->process_text(&kb.key_processor, &event);
        assert(message_count == 1); // No additional Enter or text injection
        assert(captured.type == SC_CONTROL_MSG_TYPE_SET_CLIPBOARD);
        assert(captured.set_clipboard.paste);
        assert(captured.set_clipboard.sequence == SC_SEQUENCE_INVALID);
        assert(!strcmp(captured.set_clipboard.text, commits[i]));
        assert(captured.set_clipboard.text != commits[i]);
        free(captured.set_clipboard.text);
    }

    message_count = 0;
    struct sc_text_event empty = {.text = ""};
    kb.key_processor.ops->process_text(&kb.key_processor, &empty);
    assert(!message_count);

    char *oversize = malloc(SC_CONTROL_MSG_CLIPBOARD_TEXT_MAX_LENGTH + 2);
    assert(oversize);
    memset(oversize, 'a', SC_CONTROL_MSG_CLIPBOARD_TEXT_MAX_LENGTH + 1);
    oversize[SC_CONTROL_MSG_CLIPBOARD_TEXT_MAX_LENGTH + 1] = 0;
    struct sc_text_event too_long = {.text = oversize};
    kb.key_processor.ops->process_text(&kb.key_processor, &too_long);
    assert(!message_count); // Never silently truncate a committed string
    free(oversize);

    accept_messages = false;
    struct sc_text_event rejected = {.text = "rejected"};
    kb.key_processor.ops->process_text(&kb.key_processor, &rejected);
    assert(!message_count);
    accept_messages = true;
}

static void
test_keys(void) {
    struct sc_keyboard_sdk kb;
    struct sc_controller controller;
    sc_keyboard_sdk_init(&kb, &controller, SC_KEY_INJECT_MODE_CLIPBOARD, true);
    struct sc_key_event event = {
        .action = SC_ACTION_DOWN,
        .keycode = SC_KEYCODE_a,
    };
    message_count = 0;
    kb.key_processor.ops->process_key(&kb.key_processor, &event,
                                      SC_SEQUENCE_INVALID);
    assert(!message_count); // The text event is responsible for the letter
    event.keycode = SC_KEYCODE_SPACE;
    kb.key_processor.ops->process_key(&kb.key_processor, &event,
                                      SC_SEQUENCE_INVALID);
    assert(!message_count);
    event.keycode = SC_KEYCODE_BACKSPACE;
    kb.key_processor.ops->process_key(&kb.key_processor, &event,
                                      SC_SEQUENCE_INVALID);
    assert(message_count == 1);
    assert(captured.type == SC_CONTROL_MSG_TYPE_INJECT_KEYCODE);
    assert(captured.inject_keycode.keycode == AKEYCODE_DEL);
    event.keycode = SC_KEYCODE_a;
    event.mods_state = SC_MOD_LCTRL;
    kb.key_processor.ops->process_key(&kb.key_processor, &event,
                                      SC_SEQUENCE_INVALID);
    assert(message_count == 2); // Ctrl+A remains a shortcut
    assert(captured.inject_keycode.keycode == AKEYCODE_A);
}

int
main(int argc, char *argv[]) {
    (void) argc;
    (void) argv;
    test_committed_text();
    test_keys();
    return 0;
}
