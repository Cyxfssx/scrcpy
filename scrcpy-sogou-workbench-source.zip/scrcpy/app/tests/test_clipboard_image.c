#include "common.h"

#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <SDL3/SDL.h>

#include "clipboard_image.h"
#include "util/binary.h"

// Valid 1x1 transparent PNG, including CRCs and IEND.
static const uint8_t png_image[] = {
    0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a,0x00,0x00,0x00,0x0d,
    0x49,0x48,0x44,0x52,0x00,0x00,0x00,0x01,0x00,0x00,0x00,0x01,
    0x08,0x04,0x00,0x00,0x00,0xb5,0x1c,0x0c,0x02,0x00,0x00,0x00,
    0x0b,0x49,0x44,0x41,0x54,0x78,0xda,0x63,0x64,0xf8,0x0f,0x00,
    0x01,0x05,0x01,0x01,0x27,0x18,0xe3,0x66,0x00,0x00,0x00,0x00,
    0x49,0x45,0x4e,0x44,0xae,0x42,0x60,0x82,
};

static const uint8_t *clipboard_data;
static size_t clipboard_size;

static const void * SDLCALL
get_clipboard(void *userdata, const char *mime, size_t *size) {
    (void) userdata;
    (void) mime;
    *size = clipboard_size;
    return clipboard_data;
}

static void
test_png(void) {
    const char *file = "test-clipboard-image.png";
    assert(sc_clipboard_image_save(file, png_image, sizeof(png_image), true));
    size_t len;
    void *readback = SDL_LoadFile(file, &len);
    assert(readback && len == sizeof(png_image));
    assert(!memcmp(readback, png_image, len));
    SDL_free(readback);
    assert(SDL_RemovePath(file));

    uint8_t invalid[sizeof(png_image)];
    memcpy(invalid, png_image, sizeof(invalid));
    sc_write32be(invalid + 16, 100000); // Unsafe decoder dimensions
    assert(!sc_clipboard_image_save(file, invalid, sizeof(invalid), true));
    assert(!sc_clipboard_image_save(file, png_image, 20, true));
    assert(!sc_clipboard_image_save(file, NULL, 0, true));
    assert(!sc_clipboard_image_save(file, png_image,
                                    SC_CLIPBOARD_IMAGE_MAX_BYTES + 1, true));
}

static void
test_bmp(void) {
    SDL_Surface *surface = SDL_CreateSurface(2, 2, SDL_PIXELFORMAT_RGBA32);
    assert(surface);
    assert(SDL_FillSurfaceRect(surface, NULL,
                              SDL_MapSurfaceRGBA(surface, 255, 0, 0, 255)));
    assert(SDL_SaveBMP(surface, "test-clipboard-input.bmp"));
    SDL_DestroySurface(surface);
    size_t len;
    void *bmp = SDL_LoadFile("test-clipboard-input.bmp", &len);
    assert(bmp);
#if SDL_VERSION_ATLEAST(3, 4, 0)
    const char *output = "test-clipboard-output.png";
#else
    const char *output = "test-clipboard-output.bmp";
#endif
    assert(sc_clipboard_image_save(output, bmp, len, false));
    SDL_free(bmp);
#if SDL_VERSION_ATLEAST(3, 4, 0)
    surface = SDL_LoadPNG(output);
#else
    surface = SDL_LoadBMP(output);
#endif
    assert(surface && surface->w == 2 && surface->h == 2);
    uint8_t r, g, b, a;
    assert(SDL_ReadSurfacePixel(surface, 0, 0, &r, &g, &b, &a));
    assert(r == 255 && g == 0 && b == 0 && a == 255);
    SDL_DestroySurface(surface);
    assert(SDL_RemovePath(output));
    assert(SDL_RemovePath("test-clipboard-input.bmp"));
    assert(!sc_clipboard_image_save(output, png_image, sizeof(png_image), false));
}

static void
test_clipboard_snapshot(void) {
    assert(SDL_SetClipboardText("text remains text"));
    char *file = NULL;
    assert(sc_clipboard_image_export(".", &file) == SC_CLIPBOARD_IMAGE_NONE);
    assert(!file);

    clipboard_data = png_image;
    clipboard_size = sizeof(png_image);
    const char *types[] = {"image/png"};
    assert(SDL_SetClipboardData(get_clipboard, NULL, NULL, types, 1));
    assert(sc_clipboard_image_export(".", &file) == SC_CLIPBOARD_IMAGE_READY);
    assert(file);
    char *second = NULL;
    assert(sc_clipboard_image_export(".", &second) == SC_CLIPBOARD_IMAGE_READY);
    assert(strcmp(file, second)); // Distinct transfers never replace each other
    char *remote = sc_clipboard_image_device_path(file);
    assert(remote && !strncmp(remote, SC_CLIPBOARD_IMAGE_DEVICE_DIR,
                              strlen(SC_CLIPBOARD_IMAGE_DEVICE_DIR)));
    free(remote);
    assert(SDL_RemovePath(file));
    assert(SDL_RemovePath(second));
    free(file);
    free(second);

    assert(SDL_HasClipboardData("image/png")); // Never replace PC clipboard
    assert(SDL_SetClipboardText("normal text"));
}

static void
test_device_path(void) {
    char *path = sc_clipboard_image_device_path("C:\\Users\\a\\clipboard-123-456.png");
    assert(path && !strcmp(path, SC_CLIPBOARD_IMAGE_DEVICE_DIR "clipboard-123-456.png"));
    free(path);
    path = sc_clipboard_image_device_path("/tmp/clipboard-1-2.bmp");
    assert(path && !strcmp(path, SC_CLIPBOARD_IMAGE_DEVICE_DIR "clipboard-1-2.bmp"));
    free(path);
    assert(!sc_clipboard_image_device_path("/tmp/not-an-image.txt"));
}

int
main(int argc, char *argv[]) {
    (void) argc;
    (void) argv;
    assert(SDL_SetHint(SDL_HINT_VIDEO_DRIVER, "dummy"));
    assert(SDL_Init(SDL_INIT_VIDEO));
    test_png();
    test_bmp();
    test_clipboard_snapshot();
    test_device_path();
    SDL_Quit();
    return 0;
}
