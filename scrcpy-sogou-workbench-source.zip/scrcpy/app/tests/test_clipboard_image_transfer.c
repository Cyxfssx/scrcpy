#include "common.h"

#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <SDL3/SDL.h>

#include "file_pusher.h"
#include "clipboard_image.h"
#include "controller.h"
#include "adb/adb.h"
#include "util/file.h"

static SDL_AtomicInt pushed;
static bool push_success;
static unsigned scans;
static const char *expected_target;
static const char *expected_scan;

bool
sc_adb_push(struct sc_intr *intr, const char *serial, const char *local,
            const char *remote, unsigned flags) {
    (void) intr;
    (void) flags;
    assert(!strcmp(serial, "selected-test-phone"));
    assert(sc_file_is_regular(local));
    assert(!strcmp(remote, expected_target));
    SDL_SetAtomicInt(&pushed, 1);
    return push_success;
}

bool
sc_adb_install(struct sc_intr *intr, const char *serial, const char *file,
               unsigned flags) {
    (void) intr; (void) serial; (void) file; (void) flags;
    assert(!"Image paste must not install APKs");
    return false;
}

bool
sc_controller_push_msg(struct sc_controller *controller,
                       const struct sc_control_msg *msg) {
    (void) controller;
    assert(msg->type == SC_CONTROL_MSG_TYPE_SCAN_FILE);
    assert(!strcmp(msg->scan_file.path, expected_scan));
    ++scans;
    free(msg->scan_file.path); // This test queue accepts ownership
    return true;
}

bool
sc_process_terminate(sc_pid pid) {
    (void) pid;
    assert(!"No real adb process is used by this test");
    return false;
}

bool
net_interrupt(sc_socket socket) {
    (void) socket;
    assert(!"No real socket is used by this test");
    return false;
}

static void
test_transfer(bool success, bool image) {
    const char *local = image ? "clipboard-test-123.png" : "test-ordinary-file.txt";
    assert(SDL_SaveFile(local, "test payload", 12));
    push_success = success;
    scans = 0;
    SDL_SetAtomicInt(&pushed, 0);
    expected_target = image ? SC_CLIPBOARD_IMAGE_DEVICE_DIR "clipboard-test-123.png"
                            : "/sdcard/Custom/";
    expected_scan = expected_target;

    struct sc_file_pusher fp;
    struct sc_controller controller;
    assert(sc_file_pusher_init(&fp, &controller, "selected-test-phone", "/sdcard/Custom/"));
    assert(sc_file_pusher_request(&fp, image ? SC_FILE_PUSHER_ACTION_PUSH_CLIPBOARD_IMAGE
                                           : SC_FILE_PUSHER_ACTION_PUSH_FILE,
                                  strdup(local)));
    uint64_t deadline = SDL_GetTicks() + 2000;
    while (!SDL_GetAtomicInt(&pushed) && SDL_GetTicks() < deadline) {
        SDL_Delay(1);
    }
    assert(SDL_GetAtomicInt(&pushed));
    sc_file_pusher_stop(&fp);
    sc_file_pusher_join(&fp); // Processing and cleanup have completed
    sc_file_pusher_destroy(&fp);
    assert(scans == (unsigned) success);
    assert(sc_file_is_regular(local) == !image);
    if (!image) {
        assert(SDL_RemovePath(local));
    }
}

int
main(int argc, char *argv[]) {
    (void) argc; (void) argv;
    test_transfer(true, true);
    test_transfer(false, true); // Never scan after a failed transfer
    test_transfer(true, false); // Existing ordinary file transfers stay intact
    return 0;
}
