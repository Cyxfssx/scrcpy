#ifndef SC_CLIPBOARD_IMAGE_H
#define SC_CLIPBOARD_IMAGE_H

#include "common.h"

#include <stdbool.h>
#include <stddef.h>

#define SC_CLIPBOARD_IMAGE_DEVICE_DIR "/sdcard/Pictures/scrcpy/"
#define SC_CLIPBOARD_IMAGE_MAX_BYTES (64u * 1024u * 1024u)

enum sc_clipboard_image_result {
    SC_CLIPBOARD_IMAGE_NONE,
    SC_CLIPBOARD_IMAGE_ERROR,
    SC_CLIPBOARD_IMAGE_READY,
};

// Save a clipboard snapshot on the SDL main thread. The returned path is owned
// by the caller (free()); remove the file after transferring or cancelling it.
enum sc_clipboard_image_result
sc_clipboard_image_export(const char *directory, char **out_path);

// Exposed separately for testing image validation/conversion without a desktop.
bool
sc_clipboard_image_save(const char *path, const void *data, size_t size,
                         bool png);

// Caller owns the returned device path (free()).
char *
sc_clipboard_image_device_path(const char *local_path);

#endif
