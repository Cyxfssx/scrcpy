#include "clipboard_image.h"

#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <SDL3/SDL.h>

#include "util/file.h"
#include "util/binary.h"
#include "util/log.h"

static uint32_t
read32le(const uint8_t *bytes) {
    return (uint32_t) bytes[0] | (uint32_t) bytes[1] << 8
         | (uint32_t) bytes[2] << 16 | (uint32_t) bytes[3] << 24;
}

static bool
valid_dimensions(uint32_t width, uint32_t height) {
    return width && height && width <= 16384 && height <= 16384
        && (uint64_t) width * height <= 64u * 1024u * 1024u;
}

bool
sc_clipboard_image_save(const char *path, const void *data, size_t size,
                         bool png) {
    if (!data || !size || size > SC_CLIPBOARD_IMAGE_MAX_BYTES) {
        return SDL_SetError("Clipboard image is empty or exceeds 64 MiB");
    }
    const uint8_t *bytes = data;
    if (png) {
        static const uint8_t signature[] = {137, 80, 78, 71, 13, 10, 26, 10};
        if (size < 45 || memcmp(bytes, signature, sizeof(signature))
                || memcmp(bytes + size - 8, "IEND", 4)
                || sc_read32be(bytes + 8) != 13
                || memcmp(bytes + 12, "IHDR", 4)
                || !valid_dimensions(sc_read32be(bytes + 16),
                                      sc_read32be(bytes + 20))) {
            return SDL_SetError("Invalid clipboard PNG header or dimensions");
        }
        // Keep the original PNG bytes, including transparency.
        return SDL_SaveFile(path, data, size);
    }
    if (size < 54 || bytes[0] != 'B' || bytes[1] != 'M'
            || read32le(bytes + 14) < 40) {
        return SDL_SetError("Unsupported clipboard BMP header");
    }
    uint32_t width = read32le(bytes + 18);
    int32_t signed_height = (int32_t) read32le(bytes + 22);
    int64_t height = signed_height < 0 ? -(int64_t) signed_height
                                     : signed_height;
    if (!valid_dimensions(width, (uint32_t) height)) {
        return SDL_SetError("Clipboard BMP dimensions exceed supported limits");
    }
    SDL_Surface *surface = SDL_LoadBMP_IO(SDL_IOFromConstMem(data, size), true);
    if (!surface) {
        return false;
    }
#if SDL_VERSION_ATLEAST(3, 4, 0)
    // Windows package uses SDL 3.4: screenshots (DIB/BMP) become gallery PNGs.
    bool ok = SDL_SavePNG(surface, path);
#else
    // Keep compatibility with Linux development systems using SDL 3.2.
    bool ok = SDL_SaveBMP(surface, path);
#endif
    SDL_DestroySurface(surface);
    return ok;
}

enum sc_clipboard_image_result
sc_clipboard_image_export(const char *directory, char **out_path) {
    *out_path = NULL;
    bool png = SDL_HasClipboardData("image/png");
    if (!png && !SDL_HasClipboardData("image/bmp")) {
        return SC_CLIPBOARD_IMAGE_NONE;
    }
    if (!directory) {
        LOGE("Could not create clipboard image staging directory");
        return SC_CLIPBOARD_IMAGE_ERROR;
    }
    size_t size;
    void *data = SDL_GetClipboardData(png ? "image/png" : "image/bmp", &size);
    if (!data) {
        LOGE("Could not read clipboard image: %s", SDL_GetError());
        return SC_CLIPBOARD_IMAGE_ERROR;
    }
    SDL_Time now;
    if (!SDL_GetCurrentTime(&now)) {
        SDL_free(data);
        return SC_CLIPBOARD_IMAGE_ERROR;
    }
    const char *extension = "png";
#if !SDL_VERSION_ATLEAST(3, 4, 0)
    if (!png) {
        extension = "bmp";
    }
#endif
    char name[96];
    snprintf(name, sizeof(name), "clipboard-%" PRIu64 "-%" PRIu64 ".%s",
             (uint64_t) now, SDL_GetTicksNS(), extension);
    char *path = sc_file_build_path(directory, name);
    if (!path) {
        SDL_free(data);
        return SC_CLIPBOARD_IMAGE_ERROR;
    }
    bool ok = sc_clipboard_image_save(path, data, size, png);
    SDL_free(data);
    if (!ok) {
        LOGE("Could not save clipboard image: %s", SDL_GetError());
        SDL_RemovePath(path); // Remove a possible partial write
        free(path);
        return SC_CLIPBOARD_IMAGE_ERROR;
    }
    *out_path = path;
    return SC_CLIPBOARD_IMAGE_READY;
}

char *
sc_clipboard_image_device_path(const char *local_path) {
    // Accept either separator regardless of host platform.
    const char *name = local_path;
    for (const char *p = local_path; *p; ++p) {
        if (*p == '/' || *p == '\\') {
            name = p + 1;
        }
    }
    if (strncmp(name, "clipboard-", 10)
            || (strlen(name) < 5)
            || (strcmp(name + strlen(name) - 4, ".png")
                && strcmp(name + strlen(name) - 4, ".bmp"))) {
        return NULL;
    }
    char *path;
    if (asprintf(&path, "%s%s", SC_CLIPBOARD_IMAGE_DEVICE_DIR, name) == -1) {
        return NULL;
    }
    return path;
}
