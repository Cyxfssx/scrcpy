package com.cyxfssx.warmime;

public final class EnterRouterTest {
    static void check(boolean ok, String why) { if (!ok) throw new AssertionError(why); }
    static final class Sink implements EnterRouter.Actions {
        int sends, newlines, empty;
        public void send() { ++sends; }
        public void newline() { ++newlines; }
        public void empty() { ++empty; }
    }
    static EnterRouter.Mode mode(String pkg,int type,int action,boolean shift,boolean modifier,boolean composing,boolean image,boolean text) {
        return EnterRouter.mode(pkg,type,action,true,shift,modifier,composing,image,text);
    }
    public static void main(String[] args) {
        EnterRouter r = new EnterRouter(); Sink sink = new Sink();
        EnterRouter.Mode send=mode("com.kakao.talk",0x20001,0x40000001,false,false,false,false,true);
        check(send==EnterRouter.Mode.SEND,"multiline/no-enter-action must permit explicit SEND");
        check(r.down(66,0,send,sink),"consume Enter down");
        for(int repeat=1;repeat<=20;++repeat)check(r.down(66,repeat,EnterRouter.Mode.EMPTY,sink),"consume held repeat, even after text cleared");
        check(sink.sends==1&&sink.newlines==0,"one press must not repeat send or add newline");
        check(r.up(66)&&!r.up(66),"consume only paired key up");
        check(r.down(66,0,send,sink)&&r.up(66)&&sink.sends==2,"a later explicit press is a new request");
        EnterRouter.Mode newline=mode("com.kakao.talk",1,1,true,false,false,false,true);
        check(newline==EnterRouter.Mode.NEWLINE&&r.down(66,0,newline,sink)&&r.up(66),"Shift Enter newline");
        check(sink.newlines==1&&sink.sends==2,"newline must not send");
        check(r.down(66,0,EnterRouter.Mode.EMPTY,sink)&&r.up(66)&&sink.empty==1,"empty input is consumed without send");
        check(!r.down(66,2,send,sink),"orphan repeat must not send");
        for(String pkg:new String[]{"other.app",null})check(mode(pkg,1,1,false,false,false,false,true)==EnterRouter.Mode.PASS,"other apps pass");
        for(int type:new int[]{0,2,0x81,0x91,0xe1,0x21,0xb1})check(mode("com.kakao.talk",type,1,false,false,false,false,true)==EnterRouter.Mode.PASS,"password/search/non-chat types pass");
        for(int action:new int[]{2,3,5,6,7})check(mode("com.kakao.talk",1,action,false,false,false,false,true)==EnterRouter.Mode.PASS,"search/next/done must not become sends");
        check(mode("com.kakao.talk",1,1,false,true,false,false,true)==EnterRouter.Mode.PASS,"Ctrl/Alt/Meta pass");
        check(mode("com.kakao.talk",1,1,false,false,true,false,true)==EnterRouter.Mode.PASS,"Android composing text pass");
        check(mode("com.kakao.talk",1,1,false,false,false,true,true)==EnterRouter.Mode.PASS,"image guard prevents SEND mapping");
        check(EnterRouter.mode("com.kakao.talk",1,1,false,false,false,false,false,true)==EnterRouter.Mode.PASS,"disabled switch pass");
        int before=sink.sends;check(!r.down(66,0,EnterRouter.Mode.PASS,sink)&&!r.up(66)&&sink.sends==before,"pass-through must not consume key pair");
        check(r.down(66,0,send,sink)&&r.down(160,0,send,sink)&&r.up(66)&&r.up(160),"normal/numpad key pairs are independent");
        // No callback retries, no ACTION_SEND, no injection of Enter as a fallback.
        check(sink.sends==before+2,"exactly one callback for each independent explicit press");
        System.out.println("Enter router passed: one-shot, repeats, key-up, Shift newline, empty, package/editor exclusions, composition and image guard.");
    }
}
