package com.cyxfssx.warmime;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.WindowInsets;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public final class MainActivity extends Activity {
    private TextView status;
    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    private TextView text(LinearLayout root, String value, int size) { TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(0xff29313d); t.setPadding(0, dp(10), 0, dp(10)); root.addView(t); return t; }
    private void button(LinearLayout root, String label, View.OnClickListener click) { Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setOnClickListener(click); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(56)); p.topMargin = dp(8); root.addView(b, p); }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state); ScrollView scroll = new ScrollView(this); LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(24), dp(20), dp(24), dp(28)); scroll.setBackgroundColor(0xfffff8f0); scroll.addView(root); setContentView(scroll);
        scroll.setOnApplyWindowInsetsListener((v, insets) -> { int top = insets.getSystemWindowInsetTop(), bottom = insets.getSystemWindowInsetBottom(); v.setPadding(0, top, 0, bottom); return insets; }); scroll.requestApplyInsets();
        text(root, "温暖输入法", 28);
        text(root, "无键盘面板 · 回车发送验证版 0.1.2", 17);
        text(root, "电脑搜狗继续负责选词。本输入法不显示字母键盘。KakaoTalk 中粘贴文字后按 Enter 请求发送，Shift+Enter 换行；粘贴本身不发送。图片仍通过原通道进入预览。", 16);
        button(root, "1．打开系统设置，启用温暖输入法", v -> startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        button(root, "2．切换到温暖输入法", v -> ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showInputMethodPicker());
        button(root, "3．选择一张图片做本机测试", v -> { Intent pick = new Intent(this, PickImageActivity.class); pick.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(pick); });
        text(root, "本机测试：选图后，在 60 秒内返回 KakaoTalk，点当前聊天输入框。只尝试插入一次。请先用无敏感内容的图片测试，观察应用是否出现预览。\n\n电脑 Ctrl+V：需要配套的独立图片桥接更新；仅安装 APK 不会自动接收到旧模块的图片。", 15);
        android.widget.Switch enter = new android.widget.Switch(this); enter.setText("KakaoTalk：回车发送文字"); enter.setTextSize(16); enter.setPadding(0, dp(12), 0, dp(12)); enter.setChecked(ImageStore.prefs(this).getBoolean("enter_send", true));
        enter.setOnCheckedChangeListener((b, checked) -> ImageStore.prefs(this).edit().putBoolean("enter_send", checked).apply()); root.addView(enter);
        text(root, "测试：回聊天点文字输入框，Ctrl+V 粘贴一句文字，再按 Enter。仅主动按回车才请求发送。声明为搜索、密码的输入框及其他应用保留原操作。请先在测试聊天验证；当前没有真实手机测试结果。", 15);
        status = text(root, "", 15);
        button(root, "刷新测试结果", v -> refresh());
        button(root, "复制测试信息", v -> { ((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("温暖输入法测试", report())); android.widget.Toast.makeText(this, "已复制测试信息，不包含聊天文字或图片", 0).show(); });
        button(root, "切回三星／其他输入法", v -> ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showInputMethodPicker());
        button(root, "清理本机图片缓存", v -> new AlertDialog.Builder(this).setMessage("请先完成当前待发送图片。清理后，尚未读取图片的预览可能失效。是否清理？").setPositiveButton("清理", (d, w) -> { try { ImageStore.clear(this); refresh(); } catch (Exception e) { status.setText(e.getMessage()); } }).setNegativeButton("取消", null).show());
        text(root, "本应用没有联网权限。不记录聊天文字。图片只缓存在本机，按你的操作提供给当前应用。\n若应用不接受标准图片接口，需要根据测试结果继续适配，当前不保证出现预览。", 14);
    }
    private String report() { android.content.SharedPreferences p = ImageStore.prefs(this); return "温暖输入法 0.1.2-preview\nAndroid API: " + android.os.Build.VERSION.SDK_INT + "\n已选中: " + WarmInputMethodService.selected(this) + "\n输入应用: " + p.getString("editor_package", "尚未检测") + "\n声明图片类型: " + p.getString("editor_mimes", "无") + "\n图片结果: " + p.getString("last_result", "尚未测试") + "\n图片说明: " + p.getString("last_detail", "请先启用并切换，再测试图片") + "\n捕获回车: " + p.contains("enter_key_seen") + "\n最近路由: " + p.getString("enter_mode", "无") + "\n图片预览保护: " + p.getBoolean("enter_image_guard", false) + "\n回车发送开关: " + p.getBoolean("enter_send", true) + "\n回车结果: " + p.getString("enter_result", "尚未捕获回车") + "\n回车说明: " + p.getString("enter_detail", "请回 KakaoTalk 粘贴文字，再按一次 Enter"); }
    private void refresh() { status.setText(report()); }
    @Override protected void onResume() { super.onResume(); if (status != null) refresh(); }
}
