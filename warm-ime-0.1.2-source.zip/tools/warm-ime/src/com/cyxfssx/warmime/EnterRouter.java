package com.cyxfssx.warmime;

/** One physical press -> at most one action; never retry a rejected send as Enter. */
public final class EnterRouter {
    public enum Mode { PASS, SEND, NEWLINE, EMPTY }
    public interface Actions { void send(); void newline(); void empty(); }
    private final java.util.HashSet<Integer> held = new java.util.HashSet<>();
    public boolean down(int code, int repeat, Mode mode, Actions actions) {
        if (held.contains(code)) return true;
        if (repeat != 0 || mode == Mode.PASS) return false;
        held.add(code);
        if (mode == Mode.SEND) actions.send();
        else if (mode == Mode.NEWLINE) actions.newline();
        else actions.empty();
        return true;
    }
    public boolean up(int code) {
        return held.remove(code);
    }
    public static Mode mode(String pkg, int inputType, int imeOptions, boolean enabled,
            boolean shift, boolean otherModifiers, boolean composing, boolean imageGuard, boolean text) {
        // Android constants are copied numerically here to keep this policy host-testable.
        if (!enabled || !"com.kakao.talk".equals(pkg) || (inputType & 15) != 1
                || otherModifiers || composing || imageGuard) return Mode.PASS;
        int variation = inputType & 0xff0;
        if (variation != 0 && variation != 0x40 && variation != 0x50) return Mode.PASS;
        int action = imeOptions & 255;
        if (action != 0 && action != 1 && action != 4) return Mode.PASS; // unspecified / none / SEND
        if (shift) return Mode.NEWLINE;
        return text ? Mode.SEND : Mode.EMPTY;
    }
}
