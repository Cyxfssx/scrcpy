#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <uxtheme.h>
#include <dwmapi.h>
#include <gdiplus.h>
#include <stdint.h>
#include <stdlib.h>
#include <wchar.h>
#include <stdbool.h>
#include "theme.h"

#define THEME_PATH 2048
struct theme {
    HWND parent;
    ULONG_PTR token;
    GpBitmap *wallpaper;
    HDC cache;
    HBITMAP bitmap, old_bitmap;
    HBRUSH input, disabled_input;
    int width, height;
    unsigned dpi, generation;
    COLORREF matte;
    wchar_t ini[THEME_PATH], directory[THEME_PATH];
};
static struct theme theme;
struct control_theme { enum wm_theme_role role; bool hover; };
static int scale(int n) { return MulDiv(n,(int)theme.dpi,96); }
static void rounded_path(GpPath *path, float x, float y, float w, float h, float r) {
    float d=2*r;
    GdipAddPathArc(path,x,y,d,d,180,90);
    GdipAddPathArc(path,x+w-d,y,d,d,270,90);
    GdipAddPathArc(path,x+w-d,y+h-d,d,d,0,90);
    GdipAddPathArc(path,x,y+h-d,d,d,90,90);
    GdipClosePathFigure(path);
}
static void rounded(GpGraphics *graphics, float x,float y,float w,float h,float r,ARGB fill,ARGB outline) {
    if(w<=0||h<=0) return;
    GpPath *path=NULL; GdipCreatePath(FillModeAlternate,&path); if(!path) return;
    rounded_path(path,x,y,w,h,r);
    if(fill) { GpSolidFill *brush=NULL; GdipCreateSolidFill(fill,&brush); if(brush) { GdipFillPath(graphics,(GpBrush*)brush,path); GdipDeleteBrush((GpBrush*)brush); } }
    if(outline) { GpPen *pen=NULL; GdipCreatePen1(outline,1.0f,UnitPixel,&pen); if(pen) { GdipDrawPath(graphics,pen,path); GdipDeletePen(pen); } }
    GdipDeletePath(path);
}
static void clear_cache(void) {
    if(theme.cache) {
        SelectObject(theme.cache,theme.old_bitmap); DeleteObject(theme.bitmap); DeleteDC(theme.cache);
        theme.cache=NULL; theme.bitmap=NULL;
    }
}
static bool load_wallpaper(const wchar_t *path) {
    WIN32_FILE_ATTRIBUTE_DATA info;
    if(!GetFileAttributesExW(path,GetFileExInfoStandard,&info)
        || info.nFileSizeHigh || info.nFileSizeLow>32u*1024u*1024u) return false;
    GpBitmap *source=NULL,*image=NULL; UINT width=0,height=0;
    if(GdipCreateBitmapFromFile(path,&source)!=Ok || !source) return false;
    GdipGetImageWidth((GpImage*)source,&width); GdipGetImageHeight((GpImage*)source,&height);
    if(!width||!height||width>16384||height>16384||(uint64_t)width*height>64u*1024u*1024u) { GdipDisposeImage((GpImage*)source); return false; }
    UINT nw=width, nh=height;
    if(nw>2048||nh>2048) {
        if(nw>=nh) { nh=(UINT)((uint64_t)nh*2048/nw); nw=2048; }
        else { nw=(UINT)((uint64_t)nw*2048/nh); nh=2048; }
        if(!nw)nw=1; if(!nh)nh=1;
    }
    bool ok=false;
    if(GdipCreateBitmapFromScan0((INT)nw,(INT)nh,0,PixelFormat32bppPARGB,NULL,&image)==Ok) {
        GpGraphics *graphics=NULL;
        if(GdipGetImageGraphicsContext((GpImage*)image,&graphics)==Ok) {
            GdipSetInterpolationMode(graphics,InterpolationModeHighQualityBicubic);
            ok=GdipDrawImageRectI(graphics,(GpImage*)source,0,0,(INT)nw,(INT)nh)==Ok;
            GdipDeleteGraphics(graphics);
        }
    }
    GdipDisposeImage((GpImage*)source); // Release the user's original file lock.
    if(!ok) { if(image)GdipDisposeImage((GpImage*)image); return false; }
    if(theme.wallpaper)GdipDisposeImage((GpImage*)theme.wallpaper);
    theme.wallpaper=image;
    ARGB corner;
    theme.matte=RGB(255,248,239);
    if(GdipBitmapGetPixel(image,0,0,&corner)==Ok && (corner>>24)==255)
        theme.matte=RGB((corner>>16)&255,(corner>>8)&255,corner&255);
    clear_cache(); return true;
}
static void rebuild(void) {
    if(theme.width<=0||theme.height<=0||theme.width>10000||theme.height>10000) return;
    clear_cache();
    HDC screen=GetDC(theme.parent);
    theme.cache=CreateCompatibleDC(screen);
    BITMAPINFO info; ZeroMemory(&info,sizeof(info)); info.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);
    info.bmiHeader.biWidth=theme.width; info.bmiHeader.biHeight=-theme.height;
    info.bmiHeader.biPlanes=1; info.bmiHeader.biBitCount=32;
    void *bits; theme.bitmap=CreateDIBSection(screen,&info,DIB_RGB_COLORS,&bits,NULL,0);
    if(!theme.cache||!theme.bitmap) {
        if(theme.bitmap)DeleteObject(theme.bitmap);if(theme.cache)DeleteDC(theme.cache);
        theme.cache=NULL;theme.bitmap=NULL;ReleaseDC(theme.parent,screen);return;
    }
    theme.old_bitmap=SelectObject(theme.cache,theme.bitmap);
    HBRUSH matte=CreateSolidBrush(theme.matte); RECT full={0,0,theme.width,theme.height}; FillRect(theme.cache,&full,matte); DeleteObject(matte);
    GpGraphics *graphics=NULL; GdipCreateFromHDC(theme.cache,&graphics);
    if(graphics) {
        GdipSetSmoothingMode(graphics,SmoothingModeAntiAlias);
        GdipSetInterpolationMode(graphics,InterpolationModeHighQualityBicubic);
        if(theme.wallpaper) {
            UINT iw,ih; GdipGetImageWidth((GpImage*)theme.wallpaper,&iw); GdipGetImageHeight((GpImage*)theme.wallpaper,&ih);
            double ratio=(double)theme.height/ih;
            if(iw*ratio>theme.width) ratio=(double)theme.width/iw;
            int w=(int)(iw*ratio),h=(int)(ih*ratio);
            GdipDrawImageRectI(graphics,(GpImage*)theme.wallpaper,(theme.width-w)/2,(theme.height-h)/2,w,h);
        }
        GdipDeleteGraphics(graphics);
    }
    // Static frosted backing: downsample once, then interpolate back. No blur
    // shader, render loop or animation is kept running between UI changes.
    int sw=theme.width/16,sh=theme.height/16;if(sw<1)sw=1;if(sh<1)sh=1;
    HDC small=CreateCompatibleDC(screen),blur=CreateCompatibleDC(screen);
    HBITMAP sb=CreateCompatibleBitmap(screen,sw,sh),bb=CreateCompatibleBitmap(screen,theme.width,theme.height);
    HGDIOBJ so=SelectObject(small,sb),bo=SelectObject(blur,bb);
    SetStretchBltMode(small,HALFTONE);SetStretchBltMode(blur,HALFTONE);
    SetBrushOrgEx(small,0,0,NULL);SetBrushOrgEx(blur,0,0,NULL);
    StretchBlt(small,0,0,sw,sh,theme.cache,0,0,theme.width,theme.height,SRCCOPY);
    StretchBlt(blur,0,0,theme.width,theme.height,small,0,0,sw,sh,SRCCOPY);
    int logical_width=MulDiv(theme.width,96,(int)theme.dpi);
    int left=logical_width*46/100;
    RECT cards[]={ {scale(12),scale(92),scale(left+4),theme.height-scale(62)},
                   {scale(left+12),scale(92),theme.width-scale(12),theme.height-scale(62)},
                   {scale(12),theme.height-scale(54),theme.width-scale(12),theme.height-scale(10)} };
    for(unsigned i=0;i<3;++i) {
        RECT r=cards[i]; int radius=scale(i==2?14:22);
        GdipCreateFromHDC(theme.cache,&graphics);
        if(graphics) {
            GdipSetSmoothingMode(graphics,SmoothingModeAntiAlias);
            rounded(graphics,r.left,r.top+scale(4),r.right-r.left,r.bottom-r.top,(float)radius,0x10000000,0);
            GdipDeleteGraphics(graphics);
        }
        HRGN region=CreateRoundRectRgn(r.left,r.top,r.right+1,r.bottom+1,2*radius,2*radius);
        SelectClipRgn(theme.cache,region);
        BitBlt(theme.cache,r.left,r.top,r.right-r.left,r.bottom-r.top,blur,r.left,r.top,SRCCOPY);
        SelectClipRgn(theme.cache,NULL);DeleteObject(region);
        GdipCreateFromHDC(theme.cache,&graphics);
        if(graphics) {
            GdipSetSmoothingMode(graphics,SmoothingModeAntiAlias);
            rounded(graphics,r.left,r.top,r.right-r.left-1,r.bottom-r.top-1,(float)radius,0xB7FFFFFF,0xEEFFFFFF);
            GdipDeleteGraphics(graphics);
        }
    }
    SelectObject(small,so);SelectObject(blur,bo);DeleteObject(sb);DeleteObject(bb);DeleteDC(small);DeleteDC(blur);
    ReleaseDC(theme.parent,screen); ++theme.generation;
}
bool wm_theme_init(HWND parent,const wchar_t *directory,const wchar_t *ini) {
    theme.parent=parent;theme.dpi=96;theme.matte=RGB(255,248,239);
    (void)ini;
    wcsncpy(theme.directory,directory,THEME_PATH-1);
    swprintf(theme.ini,THEME_PATH,L"%ls\\appearance.ini",directory);
    GdiplusStartupInput startup={1,NULL,FALSE,TRUE};
    if(GdiplusStartup(&theme.token,&startup,NULL)!=Ok) return false;
    theme.input=CreateSolidBrush(RGB(243,245,248));theme.disabled_input=CreateSolidBrush(RGB(247,247,249));
    wchar_t file[THEME_PATH];GetPrivateProfileStringW(L"theme",L"wallpaper",L"",file,THEME_PATH,theme.ini);
    bool loaded=*file&&load_wallpaper(file);
    if(!loaded) {
        swprintf(file,THEME_PATH,L"%ls\\wallpaper.png",directory);loaded=load_wallpaper(file);
        if(!loaded){swprintf(file,THEME_PATH,L"%ls\\wallpaper.jpg",directory);load_wallpaper(file);}
    }
    DWORD corners=2; DwmSetWindowAttribute(parent,33,&corners,sizeof(corners));
    COLORREF caption=RGB(255,248,239);DwmSetWindowAttribute(parent,35,&caption,sizeof(caption));
    return true;
}
void wm_theme_destroy(void) {
    clear_cache();if(theme.wallpaper)GdipDisposeImage((GpImage*)theme.wallpaper);
    if(theme.input)DeleteObject(theme.input);if(theme.disabled_input)DeleteObject(theme.disabled_input);
    if(theme.token)GdiplusShutdown(theme.token);ZeroMemory(&theme,sizeof(theme));
}
void wm_theme_resize(int width,int height,unsigned dpi) {
    if(theme.width==width&&theme.height==height&&theme.dpi==dpi&&theme.cache)return;
    theme.width=width;theme.height=height;theme.dpi=dpi;rebuild();
}
void wm_theme_paint(HDC dc,const RECT *rect) {
    if(theme.cache)BitBlt(dc,rect->left,rect->top,rect->right-rect->left,rect->bottom-rect->top,theme.cache,rect->left,rect->top,SRCCOPY);
    else {HBRUSH b=CreateSolidBrush(RGB(255,248,239));FillRect(dc,rect,b);DeleteObject(b);}
}
static void child_background(HWND control,HDC dc) {
    RECT r;GetClientRect(control,&r);POINT origin={0,0};MapWindowPoints(control,theme.parent,&origin,1);
    if(theme.cache)BitBlt(dc,0,0,r.right,r.bottom,theme.cache,origin.x,origin.y,SRCCOPY);
    else {HBRUSH b=CreateSolidBrush(RGB(255,248,239));FillRect(dc,&r,b);DeleteObject(b);}
}
static void paint_toggle(HWND control,HDC dc) {
    child_background(control,dc);RECT r;GetClientRect(control,&r);
    bool selected=SendMessageW(control,BM_GETCHECK,0,0)==BST_CHECKED;
    int width=scale(38),height=scale(22),top=(r.bottom-height)/2;
    GpGraphics *graphics=NULL;GdipCreateFromHDC(dc,&graphics);
    if(graphics) {
        GdipSetSmoothingMode(graphics,SmoothingModeAntiAlias);
        rounded(graphics,0,(float)top,(float)width,(float)height,(float)height/2,
            selected?0xFF34C759:0xFFD8DAE0,0);
        int thumb=height-scale(4),x=selected?width-thumb-scale(2):scale(2);
        rounded(graphics,(float)x,(float)(top+scale(2)),(float)thumb,(float)thumb,(float)thumb/2,0xFFFFFFFF,0x18000000);
        GdipDeleteGraphics(graphics);
    }
    wchar_t text[256];GetWindowTextW(control,text,256);
    SelectObject(dc,(HFONT)SendMessageW(control,WM_GETFONT,0,0));SetBkMode(dc,TRANSPARENT);
    SetTextColor(dc,IsWindowEnabled(control)?RGB(43,43,48):RGB(150,150,158));
    r.left=width+scale(10);DrawTextW(dc,text,-1,&r,DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS);
    if(GetFocus()==control && !(SendMessageW(control,WM_QUERYUISTATE,0,0)&UISF_HIDEFOCUS)){
        r.left=0;InflateRect(&r,-1,-1);DrawFocusRect(dc,&r);
    }
}
static void paint_label(HWND control,HDC dc) {
    child_background(control,dc);RECT r;GetClientRect(control,&r);wchar_t text[2048];GetWindowTextW(control,text,2048);
    SelectObject(dc,(HFONT)SendMessageW(control,WM_GETFONT,0,0));SetBkMode(dc,TRANSPARENT);
    SetTextColor(dc,RGB(54,54,61));
    UINT format=DT_WORDBREAK;
    if(GetWindowLongPtrW(control,GWL_STYLE)&SS_CENTERIMAGE)format=DT_SINGLELINE|DT_VCENTER;
    DrawTextW(dc,text,-1,&r,format);
}
static void paint_combo(HWND control,HDC dc) {
    child_background(control,dc);RECT r;GetClientRect(control,&r);
    GpGraphics *graphics=NULL;GdipCreateFromHDC(dc,&graphics);
    if(graphics) {
        GdipSetSmoothingMode(graphics,SmoothingModeAntiAlias);
        rounded(graphics,0,0,(float)r.right,(float)r.bottom,(float)scale(8),0xFFF3F5F8,0);
        GpPen *pen=NULL;GdipCreatePen1(0xFF6E7480,1.6f,UnitPixel,&pen);
        if(pen) {
            float x=(float)(r.right-scale(18)),y=(float)r.bottom/2;
            GdipDrawLine(graphics,pen,x-scale(4),y-scale(2),x,y+scale(2));
            GdipDrawLine(graphics,pen,x,y+scale(2),x+scale(4),y-scale(2));GdipDeletePen(pen);
        }
        GdipDeleteGraphics(graphics);
    }
    wchar_t text[256]=L"";LRESULT index=SendMessageW(control,CB_GETCURSEL,0,0);
    if(index>=0)SendMessageW(control,CB_GETLBTEXT,index,(LPARAM)text);
    SelectObject(dc,(HFONT)SendMessageW(control,WM_GETFONT,0,0));SetBkMode(dc,TRANSPARENT);SetTextColor(dc,RGB(43,43,48));
    r.left+=scale(10);r.right-=scale(32);DrawTextW(dc,text,-1,&r,DT_SINGLELINE|DT_VCENTER|DT_END_ELLIPSIS);
}
static LRESULT CALLBACK themed_control(HWND control,UINT message,WPARAM w,LPARAM l,UINT_PTR id,DWORD_PTR data) {
    (void)id;struct control_theme *state=(struct control_theme*)data;
    if(message==WM_NCDESTROY){RemoveWindowSubclass(control,themed_control,1);free(state);return DefSubclassProc(control,message,w,l);}
    if(message==WM_MOUSEMOVE&&!state->hover){state->hover=true;TRACKMOUSEEVENT track={sizeof(track),TME_LEAVE,control,0};TrackMouseEvent(&track);InvalidateRect(control,NULL,FALSE);}
    if(message==WM_MOUSELEAVE){state->hover=false;InvalidateRect(control,NULL,FALSE);}
    if((state->role==WM_THEME_LABEL||state->role==WM_THEME_TOGGLE||state->role==WM_THEME_COMBO)&&(message==WM_PAINT||message==WM_PRINTCLIENT)) {
        PAINTSTRUCT paint;HDC dc=message==WM_PAINT?BeginPaint(control,&paint):(HDC)w;
        if(state->role==WM_THEME_LABEL)paint_label(control,dc);
        else if(state->role==WM_THEME_TOGGLE)paint_toggle(control,dc);else paint_combo(control,dc);
        if(message==WM_PAINT)EndPaint(control,&paint);return 0;
    }
    if(message==WM_ERASEBKGND&&(state->role!=WM_THEME_INPUT)){child_background(control,(HDC)w);return 1;}
    LRESULT result=DefSubclassProc(control,message,w,l);
    if(message==BM_SETCHECK||message==WM_ENABLE||message==WM_SETFOCUS||message==WM_KILLFOCUS||message==WM_LBUTTONUP||message==WM_KEYUP)
        InvalidateRect(control,NULL,FALSE);
    if((state->role==WM_THEME_INPUT||state->role==WM_THEME_COMBO)&&(message==WM_SIZE||message==WM_STYLECHANGED)) {
        RECT r;GetWindowRect(control,&r);SetWindowRgn(control,CreateRoundRectRgn(0,0,r.right-r.left+1,r.bottom-r.top+1,scale(14),scale(14)),TRUE);
    }
    return result;
}
void wm_theme_attach(HWND control,enum wm_theme_role role) {
    if(!control)return;struct control_theme *state=calloc(1,sizeof(*state));if(!state)return;
    state->role=role;if(!SetWindowSubclass(control,themed_control,1,(DWORD_PTR)state))free(state);
    if(role==WM_THEME_INPUT){SendMessageW(control,EM_SETMARGINS,EC_LEFTMARGIN|EC_RIGHTMARGIN,MAKELPARAM(scale(10),scale(10)));}
}
void wm_theme_draw_button(const DRAWITEMSTRUCT *d,bool primary,bool danger) {
    child_background(d->hwndItem,d->hDC);
    RECT r=d->rcItem;bool down=(d->itemState&ODS_SELECTED)!=0,enabled=(d->itemState&ODS_DISABLED)==0;
    struct control_theme *state=NULL;DWORD_PTR data;
    if(GetWindowSubclass(d->hwndItem,themed_control,1,&data))state=(struct control_theme*)data;
    bool hover=state&&state->hover;
    ARGB fill=primary?(down?0xFF0063D9:hover?0xFF248CFF:0xFF007AFF):(down?0xE5E6E9EF:hover?0xF5FFFFFF:0xCFFFFFFF);
    if(!enabled)fill=0xB5E5E5EA;
    GpGraphics *graphics=NULL;GdipCreateFromHDC(d->hDC,&graphics);
    if(graphics){GdipSetSmoothingMode(graphics,SmoothingModeAntiAlias);
        rounded(graphics,1,1,(float)(r.right-r.left-2),(float)(r.bottom-r.top-2),(float)scale(11),fill,primary?0:0xDCFFFFFF);
        GdipDeleteGraphics(graphics);}
    SetBkMode(d->hDC,TRANSPARENT);SetTextColor(d->hDC,!enabled?RGB(155,155,163):primary?RGB(255,255,255):danger?RGB(210,65,57):RGB(40,60,90));
    HFONT font=(HFONT)SendMessageW(d->hwndItem,WM_GETFONT,0,0);SelectObject(d->hDC,font);
    wchar_t text[256];GetWindowTextW(d->hwndItem,text,256);DrawTextW(d->hDC,text,-1,&r,DT_CENTER|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS);
    if((d->itemState&ODS_FOCUS)&&!(d->itemState&ODS_NOFOCUSRECT)){
        InflateRect(&r,-scale(4),-scale(4));DrawFocusRect(d->hDC,&r);
    }
}
bool wm_theme_choose_wallpaper(void) {
    wchar_t path[THEME_PATH]=L"";
    OPENFILENAMEW file={0};file.lStructSize=sizeof(file);file.hwndOwner=theme.parent;
    file.lpstrFilter=L"图片（PNG / JPG / BMP）\0*.png;*.jpg;*.jpeg;*.bmp\0所有文件\0*.*\0\0";
    file.lpstrFile=path;file.nMaxFile=THEME_PATH;file.lpstrTitle=L"选择你的背景壁纸";
    file.Flags=OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_NOCHANGEDIR|OFN_EXPLORER;
    if(!GetOpenFileNameW(&file))return false;
    if(!load_wallpaper(path)){MessageBoxW(theme.parent,L"这张图片无法读取。请选择 PNG、JPG 或 BMP，文件小于 32 MiB。",L"更换壁纸",MB_OK|MB_ICONWARNING);return false;}
    // New appearance files are UTF-16, preserving Chinese paths even on an
    // English Windows installation whose ANSI code page cannot represent them.
    HANDLE settings=CreateFileW(theme.ini,GENERIC_WRITE,0,NULL,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,NULL);
    if(settings!=INVALID_HANDLE_VALUE){WCHAR bom=0xFEFF;DWORD written;WriteFile(settings,&bom,sizeof(bom),&written,NULL);CloseHandle(settings);}
    WritePrivateProfileStringW(L"theme",L"wallpaper",path,theme.ini);rebuild();
    RedrawWindow(theme.parent,NULL,NULL,RDW_INVALIDATE|RDW_ERASE|RDW_ALLCHILDREN);return true;
}
HBRUSH wm_theme_input_brush(bool disabled){return disabled?theme.disabled_input:theme.input;}
COLORREF wm_theme_text_color(void){return RGB(43,43,48);}
unsigned wm_theme_generation(void){return theme.generation;}
#ifdef MANAGER_SMOKE_TEST
bool wm_theme_test_wallpaper(const wchar_t *path){
    if(!path){if(theme.wallpaper)GdipDisposeImage((GpImage*)theme.wallpaper);theme.wallpaper=NULL;theme.matte=RGB(255,248,239);rebuild();return true;}
    bool ok=load_wallpaper(path);if(ok)rebuild();return ok;
}
#endif
