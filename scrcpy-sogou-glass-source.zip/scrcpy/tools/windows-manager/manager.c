#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#define _WIN32_WINNT 0x0A00
#define WINVER 0x0A00
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <commctrl.h>
#include <shellapi.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <wchar.h>
#include <math.h>
#include "model.h"
#include "theme.h"
#include <uxtheme.h>

#define PATH_SIZE 2048
#define SCAN_MESSAGE (WM_APP + 1)
#define TIMER_ID 1
#define CAPTURE_SIZE 65536

enum {
    ID_REFRESH = 101, ID_CHECK_ALL, ID_UNCHECK, ID_START_ALL, ID_START_CHECKED,
    ID_STOP_CHECKED, ID_STOP_ALL, ID_TILE, ID_FOCUS, ID_LOG, ID_LOG_DIR,
    ID_RESET, ID_APPLY, ID_RECORD_DIR, ID_SIZE_CHECK, ID_FPS_CHECK,
    ID_BUFFER_CHECK, ID_AUDIO, ID_RECORD, ID_TOPMOST, ID_BORDERLESS,
    ID_SIZE, ID_FPS, ID_BITRATE, ID_BUFFER, ID_HWDEC, ID_DEVICES, ID_WALLPAPER,
};
struct device {
    wchar_t serial[WM_SERIAL_SIZE], model[WM_MODEL_SIZE];
    enum wm_device_state state;
    bool connected, checked, pending, stopping, restart;
    HANDLE process;
    DWORD pid, last_exit;
    HWND window;
    struct wm_profile desired;
    wchar_t log_path[PATH_SIZE];
};
struct capture_result { char output[CAPTURE_SIZE]; DWORD error, exit_code; bool overflow; };
struct manager {
    HINSTANCE instance;
    HWND window, list, status, heading, subtitle, devices_label, settings_label;
    HWND refresh, check_all, uncheck, start_all, start_checked, stop_checked, wallpaper,
         stop_all, tile, focus, log, log_dir, reset, apply, record_dir;
    HWND size_check, size_edit, fps_check, fps_edit, bitrate_label, bitrate_edit,
         audio, record, buffer_check, buffer_edit, hwdec_label, hwdec,
         topmost, borderless, help;
    HFONT font, title_font;
    HBRUSH background, white;
    UINT dpi;
    wchar_t directory[PATH_SIZE], exe[PATH_SIZE], adb[PATH_SIZE], ini[PATH_SIZE];
    wchar_t logs[PATH_SIZE], recordings[PATH_SIZE];
    struct device devices[WM_MAX_DEVICES];
    size_t count;
    bool scanning, closing, keep_windows;
    ULONGLONG next_launch, close_deadline;
    unsigned launch_counter;
#ifdef MANAGER_SMOKE_TEST
    bool smoke;
#endif
};
static struct manager g;
static void refresh_devices(void);
static void update_rows(void);
static void update_enabled(void);
static void tick(void);

static int scaled(int v) { return MulDiv(v, (int)g.dpi, 96); }
static void status(const wchar_t *text) { SetWindowTextW(g.status, text); }
static void error_box(const wchar_t *text) { MessageBoxW(g.window, text, L"scrcpy 多开控制台", MB_OK | MB_ICONWARNING); }
static bool checked(HWND h) { return SendMessageW(h, BM_GETCHECK, 0, 0) == BST_CHECKED; }
static void check(HWND h, bool value) { SendMessageW(h, BM_SETCHECK, value ? BST_CHECKED : BST_UNCHECKED, 0); }
static bool join_path(wchar_t *out, size_t cap, const wchar_t *dir, const wchar_t *name) {
    int n = swprintf(out, cap, L"%ls\\%ls", dir, name);
    return n >= 0 && (size_t)n < cap;
}
static bool folder(const wchar_t *path) {
    if (CreateDirectoryW(path, NULL)) return true;
    DWORD attr = GetFileAttributesW(path);
    return attr != INVALID_FILE_ATTRIBUTES && (attr & FILE_ATTRIBUTE_DIRECTORY);
}
static void system_error(const wchar_t *operation, DWORD code) {
    wchar_t detail[512] = L"", message[1024];
    FormatMessageW(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
                    NULL, code, 0, detail, 512, NULL);
    swprintf(message, 1024, L"%ls失败（%lu）：%ls", operation, (unsigned long)code, detail);
    error_box(message);
}
static void utf8(wchar_t *out, size_t cap, const char *text) {
    if (!MultiByteToWideChar(CP_UTF8, 0, text, -1, out, (int)cap)) *out = 0;
}

// Restrict inheritance to the explicit log/pipe and NUL handles. This also
// prevents an unrelated running phone from retaining another scan's pipe.
static bool spawn_hidden(const wchar_t *exe, wchar_t *command, HANDLE output,
                          PROCESS_INFORMATION *process) {
    SECURITY_ATTRIBUTES sa = {sizeof(sa), NULL, TRUE};
    HANDLE input = CreateFileW(L"NUL", GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE,
                               &sa, OPEN_EXISTING, 0, NULL);
    if (input == INVALID_HANDLE_VALUE) return false;
    STARTUPINFOEXW si;
    ZeroMemory(&si, sizeof(si));
    si.StartupInfo.cb = sizeof(si);
    si.StartupInfo.dwFlags = STARTF_USESTDHANDLES;
    si.StartupInfo.hStdInput = input;
    si.StartupInfo.hStdOutput = si.StartupInfo.hStdError = output;
    SIZE_T size = 0;
    InitializeProcThreadAttributeList(NULL, 1, 0, &size);
    si.lpAttributeList = HeapAlloc(GetProcessHeap(), 0, size);
    bool ok = false;
    DWORD last = ERROR_NOT_ENOUGH_MEMORY;
    bool initialized = si.lpAttributeList
        && InitializeProcThreadAttributeList(si.lpAttributeList, 1, 0, &size);
    if (initialized) {
        HANDLE handles[] = {input, output};
        if (UpdateProcThreadAttribute(si.lpAttributeList, 0,
                PROC_THREAD_ATTRIBUTE_HANDLE_LIST, handles, sizeof(handles), NULL, NULL)) {
            ok = CreateProcessW(exe, command, NULL, NULL, TRUE,
                    CREATE_NO_WINDOW | EXTENDED_STARTUPINFO_PRESENT,
                    NULL, g.directory, &si.StartupInfo, process) != FALSE;
        }
        last = GetLastError();
        DeleteProcThreadAttributeList(si.lpAttributeList);
    }
    if (si.lpAttributeList) HeapFree(GetProcessHeap(), 0, si.lpAttributeList);
    CloseHandle(input);
    SetLastError(last);
    return ok;
}

static struct capture_result *capture(const wchar_t *exe, wchar_t *command) {
    struct capture_result *r = calloc(1, sizeof(*r));
    if (!r) return NULL;
    SECURITY_ATTRIBUTES sa = {sizeof(sa), NULL, TRUE};
    HANDLE read_pipe = NULL, write_pipe = NULL;
    if (!CreatePipe(&read_pipe, &write_pipe, &sa, 0)) { r->error = GetLastError(); return r; }
    SetHandleInformation(read_pipe, HANDLE_FLAG_INHERIT, 0);
    PROCESS_INFORMATION pi;
    if (!spawn_hidden(exe, command, write_pipe, &pi)) {
        r->error = GetLastError(); CloseHandle(read_pipe); CloseHandle(write_pipe); return r;
    }
    CloseHandle(write_pipe); CloseHandle(pi.hThread);
    ULONGLONG deadline = GetTickCount64() + 15000;
    size_t used = 0;
    bool exited = false;
    for (;;) {
        if (GetTickCount64() >= deadline) {
            r->error = WAIT_TIMEOUT;
            TerminateProcess(pi.hProcess, WAIT_TIMEOUT);
            WaitForSingleObject(pi.hProcess, 2000);
            break;
        }
        DWORD available = 0;
        if (!PeekNamedPipe(read_pipe, NULL, 0, NULL, &available, NULL)) break;
        if (available) {
            char chunk[4096]; DWORD got;
            DWORD want = available < sizeof(chunk) ? available : (DWORD)sizeof(chunk);
            if (!ReadFile(read_pipe, chunk, want, &got, NULL) || !got) break;
            size_t room = sizeof(r->output) - 1 - used;
            size_t copy = got < room ? got : room;
            memcpy(r->output + used, chunk, copy); used += copy;
            if (copy != got) r->overflow = true;
            continue;
        }
        if (exited) break;
        if (WaitForSingleObject(pi.hProcess, 30) == WAIT_OBJECT_0) {
            exited = true; // Drain final pipe bytes on the next pass.
        }
    }
    GetExitCodeProcess(pi.hProcess, &r->exit_code);
    CloseHandle(pi.hProcess); CloseHandle(read_pipe);
    return r;
}
static DWORD WINAPI scan_thread(void *param) {
    HWND window = param;
    wchar_t command[PATH_SIZE + 40];
    swprintf(command, PATH_SIZE + 40, L"\"%ls\" devices -l", g.adb);
    struct capture_result *r = capture(g.adb, command);
    if (!PostMessageW(window, SCAN_MESSAGE, 0, (LPARAM)r)) free(r);
    return 0;
}
static void refresh_devices(void) {
    if (g.scanning || g.closing) return;
    g.scanning = true; EnableWindow(g.refresh, FALSE);
    status(L"正在读取设备；请在手机上允许 USB 调试授权……");
    HANDLE thread = CreateThread(NULL, 0, scan_thread, g.window, 0, NULL);
    if (thread) CloseHandle(thread);
    else { g.scanning = false; EnableWindow(g.refresh, TRUE); system_error(L"读取设备", GetLastError()); }
}
static void merge_devices(const char *output) {
    struct wm_discovered_device found[WM_MAX_DEVICES]; bool truncated;
    size_t count = wm_parse_devices(output, found, WM_MAX_DEVICES, &truncated);
    for (size_t i = 0; i < g.count; ++i) g.devices[i].connected = false;
    for (size_t i = 0; i < count; ++i) {
        wchar_t serial[WM_SERIAL_SIZE]; utf8(serial, WM_SERIAL_SIZE, found[i].serial);
        size_t index;
        for (index = 0; index < g.count; ++index)
            if (!wcscmp(g.devices[index].serial, serial)) break;
        if (index == g.count) {
            if (g.count == WM_MAX_DEVICES) { truncated = true; continue; }
            ++g.count;
            wcscpy(g.devices[index].serial, serial);
            g.devices[index].checked = found[i].state == WM_DEVICE_READY;
            LVITEMW item = {0}; item.mask = LVIF_TEXT; item.iItem = (int)index; item.pszText = serial;
            ListView_InsertItem(g.list, &item);
            ListView_SetCheckState(g.list, (int)index, g.devices[index].checked);
        }
        g.devices[index].connected = true;
        g.devices[index].state = found[i].state;
        utf8(g.devices[index].model, WM_MODEL_SIZE, found[i].model);
    }
    update_rows();
    if (truncated) error_box(L"设备列表超过 32 台或输出不完整；本次只显示可解析的设备，请检查设备连接。");
    else if (!count) status(L"未发现设备。请连接手机、启用 USB 调试，再点击“刷新设备”。");
    else status(L"设备列表已更新。勾选设备后启动，或点击“一键全部启动”。");
}
static bool get_uint(HWND h, unsigned *out, unsigned low, unsigned high) {
    wchar_t text[64], *end; GetWindowTextW(h, text, 64);
    if (!*text || *text == L'-') return false;
    unsigned long n = wcstoul(text, &end, 10);
    if (*end || n < low || n > high) return false;
    *out = (unsigned)n; return true;
}
static bool read_profile(struct wm_profile *p) {
    *p = wm_default_profile();
    if (checked(g.size_check)) { if (!get_uint(g.size_edit, &p->max_size, 64, 8192)) goto invalid; }
    else p->max_size = 0;
    if (checked(g.fps_check)) { if (!get_uint(g.fps_edit, &p->max_fps, 1, 240)) goto invalid; }
    else p->max_fps = 0;
    if (checked(g.buffer_check)) { if (!get_uint(g.buffer_edit, &p->buffer_ms, 1, 2000)) goto invalid; }
    else p->buffer_ms = 0;
    wchar_t text[64], *end; GetWindowTextW(g.bitrate_edit, text, 64);
    double rate = wcstod(text, &end);
    if (!*text || *end || !isfinite(rate) || rate < 0.1 || rate > 100.0) goto invalid;
    p->bitrate = (uint32_t)(rate * 1000000.0 + 0.5);
    LRESULT hw = SendMessageW(g.hwdec, CB_GETCURSEL, 0, 0);
    p->hwdec = hw >= 0 ? (unsigned)hw : 0;
    p->audio = checked(g.audio); p->record = checked(g.record);
    p->topmost = checked(g.topmost); p->borderless = checked(g.borderless);
    if (!wm_profile_valid(p)) goto invalid;
    return true;
invalid:
    error_box(L"请检查参数：\n分辨率长边：64～8192\n帧率：1～240 FPS\n码率：0.1～100 Mbps（小数用英文句点）\n额外缓存：1～2000 毫秒，关闭时为 0。");
    return false;
}
static void set_profile(const struct wm_profile *p) {
    wchar_t text[64];
    check(g.size_check, p->max_size != 0); swprintf(text, 64, L"%u", p->max_size ? p->max_size : 1280); SetWindowTextW(g.size_edit, text);
    check(g.fps_check, p->max_fps != 0); swprintf(text, 64, L"%u", p->max_fps ? p->max_fps : 30); SetWindowTextW(g.fps_edit, text);
    check(g.buffer_check, p->buffer_ms != 0); swprintf(text, 64, L"%u", p->buffer_ms ? p->buffer_ms : 50); SetWindowTextW(g.buffer_edit, text);
    swprintf(text, 64, L"%.2f", p->bitrate / 1000000.0); SetWindowTextW(g.bitrate_edit, text);
    SendMessageW(g.hwdec, CB_SETCURSEL, p->hwdec, 0);
    check(g.audio, p->audio); check(g.record, p->record);
    check(g.topmost, p->topmost); check(g.borderless, p->borderless);
    update_enabled();
}
static void save_profile(const struct wm_profile *p) {
#ifdef MANAGER_SMOKE_TEST
    if (g.smoke) return;
#endif
    const wchar_t *keys[] = {L"size",L"fps",L"bitrate",L"buffer",L"hwdec",L"audio",L"record",L"topmost",L"borderless"};
    unsigned values[] = {p->max_size,p->max_fps,p->bitrate,p->buffer_ms,p->hwdec,p->audio,p->record,p->topmost,p->borderless};
    for (size_t i = 0; i < sizeof(values)/sizeof(*values); ++i) {
        wchar_t text[40]; swprintf(text, 40, L"%u", values[i]);
        WritePrivateProfileStringW(L"profile", keys[i], text, g.ini);
    }
}
static void load_profile(void) {
    struct wm_profile p = wm_default_profile();
#define READ(field, name) p.field = GetPrivateProfileIntW(L"profile", name, p.field, g.ini)
    READ(max_size,L"size"); READ(max_fps,L"fps"); READ(bitrate,L"bitrate"); READ(buffer_ms,L"buffer"); READ(hwdec,L"hwdec");
    READ(audio,L"audio"); READ(record,L"record"); READ(topmost,L"topmost"); READ(borderless,L"borderless");
#undef READ
    if (!wm_profile_valid(&p)) p = wm_default_profile();
    set_profile(&p);
}
static void update_enabled(void) {
    EnableWindow(g.size_edit, checked(g.size_check));
    EnableWindow(g.fps_edit, checked(g.fps_check));
    EnableWindow(g.buffer_edit, checked(g.buffer_check));
}
static BOOL CALLBACK find_window(HWND window, LPARAM param) {
    struct device *d = (struct device *)param; DWORD pid;
    GetWindowThreadProcessId(window, &pid);
    if (pid == d->pid && IsWindowVisible(window) && !GetWindow(window, GW_OWNER)) {
        d->window = window; return FALSE;
    }
    return TRUE;
}
static HWND phone_window(struct device *d) {
    if (!d->process) return NULL;
    DWORD owner = 0;
    if (IsWindow(d->window)) GetWindowThreadProcessId(d->window, &owner);
    if (owner != d->pid) { d->window = NULL; EnumWindows(find_window, (LPARAM)d); }
    return d->window;
}
static void close_phone(struct device *d) {
    d->pending = false; d->stopping = d->process != NULL;
    HWND window = phone_window(d);
    if (window) PostMessageW(window, WM_CLOSE, 0, 0);
}
static bool launch(struct device *d) {
    if (!folder(g.logs) || (d->desired.record && !folder(g.recordings))) {
        status(L"无法创建日志或录屏目录，请将软件解压到可写文件夹后重试。"); return false;
    }
    wchar_t safe[WM_SERIAL_SIZE];
    size_t n = wcslen(d->serial);
    for (size_t i = 0; i <= n; ++i) {
        wchar_t c = d->serial[i];
        safe[i] = (c == 0 || (c >= L'a' && c <= L'z') || (c >= L'A' && c <= L'Z')
            || (c >= L'0' && c <= L'9') || c == L'-' || c == L'_') ? c : L'_';
    }
    SYSTEMTIME time; GetLocalTime(&time);
    wchar_t name[256], record_path[PATH_SIZE], title[256], command[WM_COMMAND_SIZE];
    swprintf(name, 256, L"%ls-%04u%02u%02u-%02u%02u%02u-%llu-%u", safe,
        time.wYear,time.wMonth,time.wDay,time.wHour,time.wMinute,time.wSecond,
        (unsigned long long)GetTickCount64(), ++g.launch_counter);
    wchar_t leaf[280]; swprintf(leaf, 280, L"%ls.log", name);
    if (!join_path(d->log_path, PATH_SIZE, g.logs, leaf)) return false;
    swprintf(leaf, 280, L"%ls.mkv", name);
    if (!join_path(record_path, PATH_SIZE, g.recordings, leaf)) return false;
    swprintf(title, 256, L"聊天 - %ls", d->serial);
    if (!wm_build_command(command, WM_COMMAND_SIZE, g.exe, d->serial, title, record_path, &d->desired)) return false;
    SECURITY_ATTRIBUTES sa = {sizeof(sa), NULL, TRUE};
    HANDLE log = CreateFileW(d->log_path, GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE,
                             &sa, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL);
    if (log == INVALID_HANDLE_VALUE) { status(L"创建日志失败，请检查文件夹写入权限。"); return false; }
    PROCESS_INFORMATION pi;
    bool ok = spawn_hidden(g.exe, command, log, &pi);
    DWORD code = GetLastError(); CloseHandle(log);
    if (!ok) {
        wchar_t text[180]; swprintf(text,180,L"启动投屏失败（%lu），请检查程序文件及日志。",(unsigned long)code);
        status(text); return false;
    }
    CloseHandle(pi.hThread); d->process = pi.hProcess; d->pid = pi.dwProcessId;
    d->window = NULL; d->stopping = d->restart = false; d->last_exit = 0;
    return true;
}
static void start_devices(bool all, bool restart) {
    struct wm_profile p;
    if (!read_profile(&p)) return;
    if (restart && MessageBoxW(g.window,
        L"将重启勾选的投屏窗口并应用右侧参数。正在进行的录屏会结束保存，是否继续？",
        L"应用参数", MB_YESNO | MB_ICONQUESTION) != IDYES) return;
    unsigned queued = 0;
    for (size_t i = 0; i < g.count; ++i) {
        struct device *d = &g.devices[i];
        if (!all && !ListView_GetCheckState(g.list, (int)i)) continue;
        if (!d->connected || d->state != WM_DEVICE_READY) continue;
        if (d->process && !restart) continue;
        d->desired = p;
        if (d->process) { close_phone(d); d->restart = true; }
        else d->pending = true;
        ++queued;
    }
    save_profile(&p);
    if (!queued) status(L"没有可启动的设备：请刷新设备、检查调试授权及勾选状态；已运行的窗口不会重复打开。");
    else status(restart ? L"正在结束原窗口；退出后按新参数重新启动……" : L"设备已加入启动队列，将依次启动以减少瞬时占用。");
    update_rows();
}
static void stop_devices(bool all) {
    for (size_t i = 0; i < g.count; ++i) {
        if (all || ListView_GetCheckState(g.list, (int)i)) {
            g.devices[i].restart = false;
            close_phone(&g.devices[i]);
        }
    }
    status(L"已请求关闭投屏，正在等待退出和录屏保存；不会强制终止进程。");
}
static void focus_selected(void) {
    int index = ListView_GetNextItem(g.list, -1, LVNI_SELECTED);
    if (index < 0) { status(L"请先点击左侧的一台设备。"); return; }
    HWND window = phone_window(&g.devices[index]);
    if (window) { ShowWindow(window, SW_RESTORE); SetForegroundWindow(window); }
    else status(L"此设备的投屏窗口尚未打开。");
}
static void tile_windows(void) {
    HWND windows[WM_MAX_DEVICES]; unsigned count = 0;
    for (size_t i = 0; i < g.count; ++i) {
        HWND window = phone_window(&g.devices[i]);
        if (window && !g.devices[i].stopping) windows[count++] = window;
    }
    if (!count) { status(L"没有可排列的投屏窗口。"); return; }
    RECT area; SystemParametersInfoW(SPI_GETWORKAREA, 0, &area, 0);
    int screen_w = area.right - area.left, screen_h = area.bottom - area.top;
    unsigned columns = (unsigned)ceil(sqrt(count * (double)screen_w / screen_h / 0.55));
    if (columns > count) columns = count;
    unsigned rows = (count + columns - 1) / columns;
    int cell_w = screen_w / (int)columns, cell_h = screen_h / (int)rows;
    for (unsigned i = 0; i < count; ++i) {
        RECT outer, inner; GetWindowRect(windows[i], &outer); GetClientRect(windows[i], &inner);
        int border_w = (outer.right - outer.left) - inner.right;
        int border_h = (outer.bottom - outer.top) - inner.bottom;
        double aspect = inner.bottom ? (double)inner.right / inner.bottom : 0.46;
        int h = cell_h - 8, w = (int)((h - border_h) * aspect) + border_w;
        if (w > cell_w - 8) { w = cell_w - 8; h = (int)((w - border_w) / aspect) + border_h; }
        int x = area.left + (int)(i % columns) * cell_w + (cell_w - w) / 2;
        int y = area.top + (int)(i / columns) * cell_h + (cell_h - h) / 2;
        ShowWindow(windows[i], SW_RESTORE);
        SetWindowPos(windows[i], NULL, x, y, w, h, SWP_NOZORDER | SWP_NOACTIVATE);
    }
    status(L"已将本面板管理的投屏窗口平铺到主显示器。");
}
static void set_cell(int row, int column, const wchar_t *text) {
    wchar_t current[256]; ListView_GetItemText(g.list, row, column, current, 256);
    if (wcscmp(current, text)) ListView_SetItemText(g.list, row, column, (wchar_t *)text);
}
static void update_rows(void) {
    unsigned active = 0, ready = 0;
    for (size_t i = 0; i < g.count; ++i) {
        struct device *d = &g.devices[i];
        if (d->process) ++active;
        if (d->connected && d->state == WM_DEVICE_READY) ++ready;
        const wchar_t *state = d->pending ? L"排队启动" : d->stopping ? L"正在停止/保存"
            : d->process ? L"运行中" : !d->connected ? L"未连接"
            : d->state == WM_DEVICE_UNAUTHORIZED ? L"请在手机授权"
            : d->state == WM_DEVICE_OFFLINE ? L"离线"
            : d->last_exit ? L"异常退出，查看日志" : L"就绪";
        set_cell((int)i, 1, d->model); set_cell((int)i, 2, state);
    }
    wchar_t title[160]; swprintf(title, 160, L"设备中心  ·  %u 台可用  /  %u 个窗口运行中", ready, active);
    wchar_t previous[160]; GetWindowTextW(g.devices_label,previous,160);
    if(wcscmp(previous,title)) SetWindowTextW(g.devices_label, title);
}
static void tick(void) {
    ULONGLONG now = GetTickCount64(); bool any = false;
    for (size_t i = 0; i < g.count; ++i) {
        struct device *d = &g.devices[i];
        if (d->process) {
            if (WaitForSingleObject(d->process, 0) == WAIT_OBJECT_0) {
                GetExitCodeProcess(d->process, &d->last_exit);
                CloseHandle(d->process); d->process = NULL; d->window = NULL;
                d->stopping = false;
                if (d->restart && !g.closing) { d->pending = true; d->restart = false; }
            } else if (d->stopping) {
                HWND window = phone_window(d);
                if (window) PostMessageW(window, WM_CLOSE, 0, 0);
            }
        }
        if (d->pending && !g.closing && now >= g.next_launch) {
            d->pending = false;
            if (!launch(d)) d->last_exit = 1;
            g.next_launch = now + 400;
        }
        any |= d->process != NULL || d->pending;
    }
    update_rows();
    if (g.closing && (!any || g.keep_windows) && !g.scanning) DestroyWindow(g.window);
    else if (g.closing && now > g.close_deadline) {
        g.close_deadline=now+60000; // A modal dialog also pumps timer messages.
        if (MessageBoxW(g.window, L"仍有投屏程序尚未退出。是否保留这些程序并退出控制面板？",
                        L"等待退出", MB_YESNO | MB_ICONQUESTION) == IDYES) DestroyWindow(g.window);
        else { g.closing = false; status(L"已取消退出，可继续管理窗口或查看日志。"); }
    }
}
static HWND control(const wchar_t *class_name, const wchar_t *text, DWORD style, int id) {
    HWND h = CreateWindowExW(0,
        class_name, text, WS_CHILD | WS_VISIBLE | style, 0,0,1,1,
        g.window, (HMENU)(INT_PTR)id, g.instance, NULL);
    if(!wcscmp(class_name,L"STATIC")) wm_theme_attach(h,WM_THEME_LABEL);
    else if(!wcscmp(class_name,L"EDIT")) wm_theme_attach(h,WM_THEME_INPUT);
    return h;
}
static HWND button(const wchar_t *text, int id, bool primary) {
    (void)primary;
    HWND h=control(L"BUTTON",text,WS_TABSTOP|BS_OWNERDRAW,id);
    wm_theme_attach(h,WM_THEME_BUTTON);return h;
}
static HWND toggle(const wchar_t *text, int id) {
    HWND h=control(L"BUTTON",text,WS_TABSTOP|BS_AUTOCHECKBOX,id);
    wm_theme_attach(h,WM_THEME_TOGGLE);return h;
}
static HWND edit(int id, bool number_only) {
    HWND h = control(L"EDIT", L"", WS_TABSTOP | ES_AUTOHSCROLL | (number_only ? ES_NUMBER : 0), id);
    SendMessageW(h, EM_SETLIMITTEXT, 24, 0); return h;
}
static BOOL CALLBACK font_child(HWND h, LPARAM param) { SendMessageW(h, WM_SETFONT, (WPARAM)param, TRUE); return TRUE; }
static void set_fonts(void) {
    HFONT old = g.font, old_title = g.title_font;
    g.font = CreateFontW(-scaled(14), 0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,
                         OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Microsoft YaHei UI");
    g.title_font = CreateFontW(-scaled(25),0,0,0,FW_BOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,
                         OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Microsoft YaHei UI");
    EnumChildWindows(g.window, font_child, (LPARAM)g.font);
    SendMessageW(g.heading, WM_SETFONT, (WPARAM)g.title_font, TRUE);
    if (old) DeleteObject(old); if (old_title) DeleteObject(old_title);
}
static void place(HWND h, int x, int y, int width, int height) {
    MoveWindow(h, scaled(x), scaled(y), scaled(width), scaled(height), TRUE);
}
static void layout(void) {
    RECT r; GetClientRect(g.window, &r);
    int width = MulDiv(r.right,96,(int)g.dpi), height = MulDiv(r.bottom,96,(int)g.dpi);
    int left = width * 46 / 100, right_x = left + 24, right_w = width - right_x - 24;
    wm_theme_resize(r.right,r.bottom,g.dpi);
    InvalidateRect(g.window,NULL,FALSE);
    place(g.heading,24,16,width-220,38); place(g.subtitle,26,58,width-52,24);
    place(g.wallpaper,width-156,22,132,34);
    place(g.devices_label,24,100,left-24,26);
    place(g.refresh,24,136,110,32); place(g.check_all,144,136,86,32); place(g.uncheck,240,136,86,32);
    place(g.list,24,180,left-32,height-390);
    int half = (left-44)/2;
    place(g.start_all,24,height-196,half,43); place(g.start_checked,36+half,height-196,half,43);
    place(g.stop_all,24,height-143,half,32); place(g.stop_checked,36+half,height-143,half,32);
    int third = (left-52)/3;
    place(g.tile,24,height-101,third,32); place(g.focus,34+third,height-101,third,32); place(g.log,44+2*third,height-101,third,32);
    place(g.settings_label,right_x,100,right_w,26);
    int input_x = right_x + right_w - 138;
    int step = (height - 260) / 10; if (step < 32) step = 32; if (step > 48) step = 48;
    place(g.size_check,right_x,142,right_w-150,30); place(g.size_edit,input_x,142,138,30);
    place(g.fps_check,right_x,142+step,right_w-150,30); place(g.fps_edit,input_x,142+step,138,30);
    place(g.bitrate_label,right_x,142+2*step,right_w-150,30); place(g.bitrate_edit,input_x,142+2*step,138,30);
    place(g.hwdec_label,right_x,142+3*step,right_w-170,30); place(g.hwdec,right_x+right_w-200,142+3*step,200,220);
    place(g.audio,right_x,142+4*step,right_w,30);
    place(g.record,right_x,142+5*step,right_w-150,30); place(g.record_dir,input_x-6,142+5*step,144,30);
    place(g.buffer_check,right_x,142+6*step,right_w-150,30); place(g.buffer_edit,input_x,142+6*step,138,30);
    place(g.topmost,right_x,142+7*step,right_w/2,30); place(g.borderless,right_x+right_w/2,142+7*step,right_w/2,30);
    place(g.reset,right_x,142+8*step,right_w/2-6,36); place(g.log_dir,right_x+right_w/2+6,142+8*step,right_w/2-6,36);
    place(g.apply,right_x,142+9*step,right_w,40); place(g.help,right_x,142+10*step,right_w,52);
    place(g.status,24,height-48,width-48,36);
    ListView_SetColumnWidth(g.list,0,scaled((left-24)*42/100));
    ListView_SetColumnWidth(g.list,1,scaled((left-24)*26/100));
    ListView_SetColumnWidth(g.list,2,scaled((left-24)*32/100-8));
}
static void create_controls(void) {
    g.heading = control(L"STATIC",L"scrcpy 多开控制台",0,0);
    g.wallpaper = button(L"更换壁纸",ID_WALLPAPER,false);
    g.subtitle = control(L"STATIC",L"搜狗选词输入  ·  Ctrl+V 图片存手机相册  ·  独立聊天窗口  ·  无 CMD 黑框",0,0);
    g.devices_label = control(L"STATIC",L"设备中心",0,0);
    g.settings_label = control(L"STATIC",L"参数与功能开关",0,0);
    g.refresh = button(L"刷新设备",ID_REFRESH,false); g.check_all = button(L"全部勾选",ID_CHECK_ALL,false); g.uncheck=button(L"清空勾选",ID_UNCHECK,false);
    g.list = control(WC_LISTVIEWW,L"",WS_TABSTOP|LVS_REPORT|LVS_SHOWSELALWAYS,ID_DEVICES);
    SetWindowTheme(g.list,L"Explorer",NULL);
    ListView_SetExtendedListViewStyle(g.list,LVS_EX_CHECKBOXES|LVS_EX_FULLROWSELECT|LVS_EX_DOUBLEBUFFER);
    ListView_SetBkColor(g.list,RGB(253,252,250)); ListView_SetTextBkColor(g.list,RGB(253,252,250));
    ListView_SetTextColor(g.list,RGB(45,45,52));
    const wchar_t *columns[] = {L"设备序列号",L"手机型号",L"状态"};
    for(int i=0;i<3;++i) { LVCOLUMNW c={0}; c.mask=LVCF_TEXT|LVCF_WIDTH; c.cx=140; c.pszText=(wchar_t*)columns[i]; ListView_InsertColumn(g.list,i,&c); }
    g.start_all=button(L"一键全部启动",ID_START_ALL,true); g.start_checked=button(L"启动勾选设备",ID_START_CHECKED,false);
    g.stop_all=button(L"全部停止",ID_STOP_ALL,false); g.stop_checked=button(L"停止勾选设备",ID_STOP_CHECKED,false);
    g.tile=button(L"平铺窗口",ID_TILE,false); g.focus=button(L"定位选中",ID_FOCUS,false); g.log=button(L"查看日志",ID_LOG,false);
    g.size_check=toggle(L"限制分辨率长边（像素）",ID_SIZE_CHECK); g.size_edit=edit(ID_SIZE,true);
    g.fps_check=toggle(L"限制视频帧率（FPS）",ID_FPS_CHECK); g.fps_edit=edit(ID_FPS,true);
    g.bitrate_label=control(L"STATIC",L"视频码率（Mbps）",SS_CENTERIMAGE,0); g.bitrate_edit=edit(ID_BITRATE,false);
    g.hwdec_label=control(L"STATIC",L"视频解码",SS_CENTERIMAGE,0);
    g.hwdec=control(WC_COMBOBOXW,L"",WS_TABSTOP|CBS_DROPDOWNLIST|WS_VSCROLL,ID_HWDEC);
    SetWindowTheme(g.hwdec,L"Explorer",NULL);wm_theme_attach(g.hwdec,WM_THEME_COMBO);
    SendMessageW(g.hwdec,CB_ADDSTRING,0,(LPARAM)L"自动硬解（推荐）"); SendMessageW(g.hwdec,CB_ADDSTRING,0,(LPARAM)L"D3D11 硬件解码"); SendMessageW(g.hwdec,CB_ADDSTRING,0,(LPARAM)L"软件解码（CPU）");
    g.audio=toggle(L"转发手机音频",ID_AUDIO); g.record=toggle(L"录制屏幕（MKV）",ID_RECORD);
    g.record_dir=button(L"打开录屏目录",ID_RECORD_DIR,false);
    g.buffer_check=toggle(L"额外视频缓存（毫秒）",ID_BUFFER_CHECK); g.buffer_edit=edit(ID_BUFFER,true);
    g.topmost=toggle(L"投屏窗口置顶",ID_TOPMOST); g.borderless=toggle(L"投屏窗口无边框",ID_BORDERLESS);
    g.reset=button(L"恢复低占用推荐",ID_RESET,false); g.log_dir=button(L"打开日志目录",ID_LOG_DIR,false);
    g.apply=button(L"应用到勾选设备（重启投屏）",ID_APPLY,true);
    g.help=control(L"STATIC",L"关闭分辨率限制 = 原始分辨率；关闭帧率限制 = 不限帧。\n关闭额外缓存 = 0 毫秒。参数对新启动的窗口生效。",0,0);
    g.status=control(L"STATIC",L"启动就绪",0,0);
    set_fonts(); load_profile(); layout();
}
#ifdef MANAGER_SMOKE_TEST
static LRESULT CALLBACK smoke_phone_proc(HWND h,UINT m,WPARAM w,LPARAM l) {
    if(m==WM_TIMER) { DestroyWindow(h); return 0; }
    if(m==WM_DESTROY) { PostQuitMessage(0); return 0; }
    return DefWindowProcW(h,m,w,l);
}
static int smoke_phone(HINSTANCE instance) {
    int count; LPWSTR *args=CommandLineToArgvW(GetCommandLineW(),&count);
    const wchar_t *title=L"Smoke phone";
    for(int i=1;i+1<count;++i) if(!wcscmp(args[i],L"--window-title")) title=args[i+1];
    WNDCLASSW cls={0}; cls.hInstance=instance; cls.lpfnWndProc=smoke_phone_proc; cls.lpszClassName=L"ManagerSmokePhone";
    RegisterClassW(&cls);
    HWND h=CreateWindowW(cls.lpszClassName,title,WS_OVERLAPPEDWINDOW,100,100,300,500,NULL,NULL,instance,NULL);
    LocalFree(args);
    if(!h || GetConsoleWindow()!=NULL) return 20;
    ShowWindow(h,SW_SHOW); SetTimer(h,1,20000,NULL);
    const char text[]="fake-phone: no console; explicit handles inherited correctly\n"; DWORD written;
    WriteFile(GetStdHandle(STD_OUTPUT_HANDLE),text,sizeof(text)-1,&written,NULL);
    MSG msg;
    while(GetMessageW(&msg,NULL,0,0)>0) { TranslateMessage(&msg); DispatchMessageW(&msg); }
    return 0;
}
static void smoke_screenshot(void) {
    RedrawWindow(g.window,NULL,NULL,RDW_INVALIDATE|RDW_UPDATENOW|RDW_ALLCHILDREN);
    RECT r; GetClientRect(g.window,&r);
    HDC screen=GetDC(g.window), mem=CreateCompatibleDC(screen);
    BITMAPINFO info; ZeroMemory(&info,sizeof(info));
    info.bmiHeader.biSize=sizeof(BITMAPINFOHEADER); info.bmiHeader.biWidth=r.right;
    info.bmiHeader.biHeight=-r.bottom; info.bmiHeader.biPlanes=1; info.bmiHeader.biBitCount=32;
    void *bits; HBITMAP bmp=CreateDIBSection(screen,&info,DIB_RGB_COLORS,&bits,NULL,0);
    if(bmp) {
        HGDIOBJ old=SelectObject(mem,bmp);
        BitBlt(mem,0,0,r.right,r.bottom,screen,0,0,SRCCOPY);
        BITMAPFILEHEADER header={0}; header.bfType=0x4d42;
        header.bfOffBits=sizeof(header)+sizeof(BITMAPINFOHEADER);
        DWORD bytes=(DWORD)(r.right*r.bottom*4); header.bfSize=header.bfOffBits+bytes;
        wchar_t path[PATH_SIZE]; join_path(path,PATH_SIZE,g.directory,L"manager-smoke.bmp");
        HANDLE file=CreateFileW(path,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,0,NULL); DWORD written;
        if(file!=INVALID_HANDLE_VALUE) {
            WriteFile(file,&header,sizeof(header),&written,NULL);
            WriteFile(file,&info.bmiHeader,sizeof(BITMAPINFOHEADER),&written,NULL);
            WriteFile(file,bits,bytes,&written,NULL); CloseHandle(file);
        }
        SelectObject(mem,old); DeleteObject(bmp);
    }
    DeleteDC(mem); ReleaseDC(g.window,screen);
}
static int smoke_test(void) {
    struct wm_profile p;
    if (!read_profile(&p) || p.max_size != 1280 || p.max_fps != 30 || p.audio || p.record || p.buffer_ms) return 10;
    SendMessageW(g.audio,BM_CLICK,0,0);
    if(!checked(g.audio))return 21;
    SendMessageW(g.audio,BM_CLICK,0,0);
    if(checked(g.audio))return 22;
    SendMessageW(g.fps_check,BM_CLICK,0,0);
    if(checked(g.fps_check)||IsWindowEnabled(g.fps_edit))return 23;
    SendMessageW(g.fps_check,BM_CLICK,0,0);
    check(g.size_check,false); check(g.fps_check,false); check(g.buffer_check,false); check(g.audio,true); check(g.record,true);
    if (!read_profile(&p) || p.max_size || p.max_fps || p.buffer_ms || !p.audio || !p.record) return 11;
    p=wm_default_profile(); set_profile(&p);
    wchar_t test_image[PATH_SIZE];join_path(test_image,PATH_SIZE,g.directory,L"theme-test.bmp");
    HANDLE image=CreateFileW(test_image,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,0,NULL);
    if(image==INVALID_HANDLE_VALUE)return 24;
    BITMAPFILEHEADER image_header={0};image_header.bfType=0x4d42;image_header.bfOffBits=54;image_header.bfSize=70;
    BITMAPINFOHEADER image_info={0};image_info.biSize=40;image_info.biWidth=2;image_info.biHeight=2;image_info.biPlanes=1;image_info.biBitCount=32;
    DWORD pixels[4]={0x00F0D0A0,0x00B0D0E0,0x00C0F0A0,0x00D0A0F0},written;
    WriteFile(image,&image_header,sizeof(image_header),&written,NULL);WriteFile(image,&image_info,sizeof(image_info),&written,NULL);
    WriteFile(image,pixels,sizeof(pixels),&written,NULL);CloseHandle(image);
    unsigned generation=wm_theme_generation();
    if(wm_theme_test_wallpaper(L"Z:\\definitely-missing-wallpaper.png"))return 25;
    if(!wm_theme_test_wallpaper(test_image)||wm_theme_generation()<=generation)return 26;
    if(!DeleteFileW(test_image))return 27; // Original image file is not kept locked.
    wm_theme_test_wallpaper(NULL);
    wchar_t self[PATH_SIZE], cmd[PATH_SIZE+50]; GetModuleFileNameW(NULL,self,PATH_SIZE);
    swprintf(cmd,PATH_SIZE+50,L"\"%ls\" --self-test-helper",self);
    struct capture_result *result=capture(self,cmd);
    if (!result || result->error || result->exit_code || !strstr(result->output,"smoke-device")) { free(result); return 12; }
    merge_devices(result->output); free(result);
    if (g.count!=1 || !ListView_GetCheckState(g.list,0)) return 13;
    wcscpy(g.exe,self); // The test-only executable acts as a simulated phone.
    start_devices(true,false); tick();
    if(!g.devices[0].process) return 14;
    DWORD original=g.devices[0].pid;
    start_devices(true,false);
    if(g.devices[0].pid!=original || g.devices[0].pending) return 15;
    ULONGLONG deadline=GetTickCount64()+5000;
    while(!phone_window(&g.devices[0]) && GetTickCount64()<deadline) Sleep(20);
    if(!g.devices[0].window) return 16;
    stop_devices(true);
    while(g.devices[0].process && GetTickCount64()<deadline) { tick(); Sleep(20); }
    if(g.devices[0].process || g.devices[0].last_exit) return 17;
    wchar_t tail[128]; swprintf(tail,128,L"界面与进程测试通过；日志保存正常；无控制台黑框。"); status(tail);
    merge_devices("smoke-device device model:SM_A376B\nphone-02 device model:Pixel_8\nphone-03 device model:Pixel_8\nphone-04 device model:SM_A376B\nphone-05 device model:SM_A376B\nphone-06 device model:Pixel_8\nphone-07 device model:SM_A376B\nphone-08 device model:Pixel_8\nphone-09 device model:SM_A376B\nphone-10 device model:SM_A376B\n");
    unsigned stable_generation=wm_theme_generation();
    start_devices(true,false);
    deadline=GetTickCount64()+14000;
    unsigned windows=0;
    do {
        tick(); windows=0;
        for(size_t i=0;i<g.count;++i) if(phone_window(&g.devices[i])) ++windows;
        if(windows==10) break;
        Sleep(30);
    } while(GetTickCount64()<deadline);
    if(windows!=10) return 18;
    if(wm_theme_generation()!=stable_generation)return 28;
    SetForegroundWindow(g.window); UpdateWindow(g.window);
    smoke_screenshot();
    stop_devices(true);
    deadline=GetTickCount64()+5000;
    unsigned active;
    do {
        tick(); active=0;
        for(size_t i=0;i<g.count;++i) if(g.devices[i].process) ++active;
        if(!active) break;
        Sleep(20);
    } while(GetTickCount64()<deadline);
    if(active) return 19;
    return 0;
}
#endif
static LRESULT CALLBACK window_proc(HWND window, UINT message, WPARAM w, LPARAM l) {
    switch(message) {
        case WM_CREATE: g.window=window; g.dpi=GetDpiForWindow(window);
            wm_theme_init(window,g.directory,g.ini);create_controls();SetTimer(window,TIMER_ID,250,NULL);return 0;
        case WM_ERASEBKGND: { RECT r;GetClientRect(window,&r);wm_theme_paint((HDC)w,&r);return 1; }
        case WM_PAINT: { PAINTSTRUCT p;HDC dc=BeginPaint(window,&p);wm_theme_paint(dc,&p.rcPaint);EndPaint(window,&p);return 0; }
        case WM_SIZE: layout(); return 0;
        case WM_GETMINMAXINFO: { MINMAXINFO *m=(MINMAXINFO*)l; m->ptMinTrackSize.x=scaled(960); m->ptMinTrackSize.y=scaled(650); return 0; }
        case WM_DPICHANGED: { g.dpi=HIWORD(w); set_fonts(); RECT *r=(RECT*)l; SetWindowPos(window,NULL,r->left,r->top,r->right-r->left,r->bottom-r->top,SWP_NOZORDER); layout(); return 0; }
        case WM_CTLCOLOREDIT:
            SetTextColor((HDC)w,wm_theme_text_color());SetBkColor((HDC)w,RGB(243,245,248));return (LRESULT)wm_theme_input_brush(false);
        case WM_CTLCOLORSTATIC: {
            wchar_t cls[32];GetClassNameW((HWND)l,cls,32);
            if(!wcscmp(cls,L"EDIT")) {
                SetTextColor((HDC)w,RGB(145,145,155));SetBkColor((HDC)w,RGB(247,247,249));return (LRESULT)wm_theme_input_brush(true);
            }
            SetTextColor((HDC)w,wm_theme_text_color());SetBkMode((HDC)w,TRANSPARENT);return (LRESULT)GetStockObject(NULL_BRUSH);
        }
        case WM_CTLCOLORBTN: SetBkMode((HDC)w,TRANSPARENT);return (LRESULT)GetStockObject(NULL_BRUSH);
        case WM_DRAWITEM: {
            DRAWITEMSTRUCT *draw=(DRAWITEMSTRUCT*)l;
            wm_theme_draw_button(draw,draw->CtlID==ID_START_ALL||draw->CtlID==ID_APPLY,
                                 draw->CtlID==ID_STOP_ALL||draw->CtlID==ID_STOP_CHECKED);return TRUE;
        }
        case WM_COMMAND:
            if(g.closing) return 0;
            switch(LOWORD(w)) {
                case ID_WALLPAPER:
                    if(wm_theme_choose_wallpaper())status(L"壁纸已更新并保存；毛玻璃背景使用静态缓存，不持续模糊渲染。");break;
                case ID_REFRESH: refresh_devices(); break;
                case ID_CHECK_ALL: case ID_UNCHECK:
                    for(size_t i=0;i<g.count;++i) ListView_SetCheckState(g.list,(int)i,LOWORD(w)==ID_CHECK_ALL); break;
                case ID_START_ALL: start_devices(true,false); break;
                case ID_START_CHECKED: start_devices(false,false); break;
                case ID_STOP_ALL: stop_devices(true); break;
                case ID_STOP_CHECKED: stop_devices(false); break;
                case ID_APPLY: start_devices(false,true); break;
                case ID_RESET: { struct wm_profile p=wm_default_profile(); set_profile(&p); status(L"已恢复推荐参数，应用到运行中窗口需点击“应用到勾选设备”。"); break; }
                case ID_TILE: tile_windows(); break;
                case ID_FOCUS: focus_selected(); break;
                case ID_LOG: {
                    int i=ListView_GetNextItem(g.list,-1,LVNI_SELECTED);
                    if(i>=0 && g.devices[i].log_path[0]) {
                        wchar_t argument[PATH_SIZE+4]; swprintf(argument,PATH_SIZE+4,L"\"%ls\"",g.devices[i].log_path);
                        ShellExecuteW(window,L"open",L"notepad.exe",argument,g.directory,SW_SHOWNORMAL);
                    } else status(L"请先点击一台启动过的设备，再查看日志。"); break;
                }
                case ID_LOG_DIR: if(folder(g.logs)) ShellExecuteW(window,L"open",g.logs,NULL,g.directory,SW_SHOWNORMAL); break;
                case ID_RECORD_DIR: if(folder(g.recordings)) ShellExecuteW(window,L"open",g.recordings,NULL,g.directory,SW_SHOWNORMAL); break;
                case ID_HWDEC: InvalidateRect(g.hwdec,NULL,FALSE); break;
                case ID_SIZE_CHECK: case ID_FPS_CHECK: case ID_BUFFER_CHECK: update_enabled(); break;
            } return 0;
        case WM_NOTIFY: if(((NMHDR*)l)->idFrom==ID_DEVICES && ((NMHDR*)l)->code==NM_DBLCLK) focus_selected(); return 0;
        case SCAN_MESSAGE: {
            struct capture_result *r=(struct capture_result*)l; g.scanning=false; EnableWindow(g.refresh,TRUE);
            if(!r) status(L"读取设备失败：内存不足。");
            else if(r->error || r->exit_code || r->overflow) {
                status(L"读取设备失败，请检查 adb.exe 和 USB 连接，再刷新。未更改已有窗口。");
                if(r->error) system_error(L"读取设备",r->error);
                else if(!g.closing) { wchar_t detail[1500]; utf8(detail,1500,r->output); error_box(*detail?detail:L"ADB 返回错误或设备列表过长。"); }
            } else merge_devices(r->output);
            free(r); return 0;
        }
        case WM_TIMER:
#ifdef MANAGER_SMOKE_TEST
            if(g.smoke) { KillTimer(window,TIMER_ID); int result=smoke_test(); DestroyWindow(window); PostQuitMessage(result); return 0; }
#endif
            tick(); return 0;
        case WM_CLOSE: {
            bool running=false; for(size_t i=0;i<g.count;++i) running|=g.devices[i].process!=NULL || g.devices[i].pending;
            if(running) {
                int answer=MessageBoxW(window,L"是否关闭本面板启动的投屏窗口？\n\n是：关闭投屏、等待录屏保存后退出。\n否：保留投屏窗口，仅退出控制面板。\n取消：返回。",L"退出控制面板",MB_YESNOCANCEL|MB_ICONQUESTION);
                if(answer==IDCANCEL) return 0;
                if(answer==IDYES) { g.closing=true; g.close_deadline=GetTickCount64()+15000; stop_devices(true); return 0; }
                g.keep_windows = true;
            }
            if(g.scanning) { g.closing=true; g.close_deadline=GetTickCount64()+16000; return 0; }
            DestroyWindow(window); return 0;
        }
        case WM_DESTROY: KillTimer(window,TIMER_ID); PostQuitMessage(0); return 0;
    }
    return DefWindowProcW(window,message,w,l);
}

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE previous, LPWSTR command_line, int show) {
    (void)previous; (void)command_line;
#ifdef MANAGER_SMOKE_TEST
    if(!wcscmp(command_line,L"--self-test-helper")) {
        const char text[]="List of devices attached\r\nsmoke-device device model:SM_A376B\r\n"; DWORD written;
        return WriteFile(GetStdHandle(STD_OUTPUT_HANDLE),text,sizeof(text)-1,&written,NULL)?0:2;
    }
    if(wcsstr(command_line,L"--text-via-clipboard")) return smoke_phone(instance);
    g.smoke=!wcscmp(command_line,L"--self-test");
#endif
    HANDLE singleton = CreateMutexW(NULL,FALSE,L"Local\\ScrcpySogouMultiManager");
    if(singleton && GetLastError()==ERROR_ALREADY_EXISTS) {
        HWND existing=FindWindowW(L"ScrcpyMultiManager",NULL);
        if(existing) { ShowWindow(existing,SW_RESTORE); SetForegroundWindow(existing); }
        CloseHandle(singleton); return 0;
    }
    g.instance=instance; g.dpi=96;
    DWORD length=GetModuleFileNameW(NULL,g.directory,PATH_SIZE);
    if(!length || length>=PATH_SIZE-1) return 1;
    wchar_t *slash=wcsrchr(g.directory,L'\\'); if(!slash) return 1; *slash=0;
    wchar_t runtime[PATH_SIZE];
    if(!join_path(runtime,PATH_SIZE,g.directory,L"engine")) return 1;
    if(!join_path(g.exe,PATH_SIZE,runtime,L"scrcpy.exe")) return 1;
    if(GetFileAttributesW(g.exe)==INVALID_FILE_ATTRIBUTES) wcscpy(runtime,g.directory);
    if(!join_path(g.exe,PATH_SIZE,runtime,L"scrcpy.exe") || !join_path(g.adb,PATH_SIZE,runtime,L"adb.exe")
       || !join_path(g.logs,PATH_SIZE,g.directory,L"logs") || !join_path(g.recordings,PATH_SIZE,g.directory,L"recordings")
       || !join_path(g.ini,PATH_SIZE,g.directory,L"manager-settings.ini")) return 1;
#ifdef MANAGER_SMOKE_TEST
    if(!g.smoke)
#endif
    if(GetFileAttributesW(g.exe)==INVALID_FILE_ATTRIBUTES || GetFileAttributesW(g.adb)==INVALID_FILE_ATTRIBUTES) {
        MessageBoxW(NULL,L"请先把压缩包全部解压到一个新文件夹，再运行本程序。\n请保留 Manager.exe 旁的 engine 文件夹及其内容。",L"文件不完整",MB_OK|MB_ICONWARNING); return 1;
    }
    g.background=CreateSolidBrush(RGB(255,248,239)); g.white=CreateSolidBrush(RGB(255,255,255));
    INITCOMMONCONTROLSEX init={sizeof(init),ICC_LISTVIEW_CLASSES|ICC_STANDARD_CLASSES}; InitCommonControlsEx(&init);
    WNDCLASSEXW cls={0}; cls.cbSize=sizeof(cls); cls.lpfnWndProc=window_proc; cls.hInstance=instance;
    cls.hIcon=LoadIconW(instance,MAKEINTRESOURCEW(1)); cls.hIconSm=cls.hIcon;
    cls.hCursor=LoadCursorW(NULL,IDC_ARROW); cls.hbrBackground=g.background; cls.lpszClassName=L"ScrcpyMultiManager";
    if(!RegisterClassExW(&cls)) return 1;
    HWND window=CreateWindowExW(0,cls.lpszClassName,L"scrcpy 多开控制台 · 搜狗输入与图片存相册",WS_OVERLAPPEDWINDOW|WS_CLIPCHILDREN,
        CW_USEDEFAULT,CW_USEDEFAULT,1120,850,NULL,NULL,instance,NULL);
    if(!window) return 1;
    RECT work; SystemParametersInfoW(SPI_GETWORKAREA,0,&work,0);
    int width=scaled(1120), height=scaled(790);
    if(width>work.right-work.left-24) width=work.right-work.left-24;
    if(height>work.bottom-work.top-24) height=work.bottom-work.top-24;
    SetWindowPos(window,NULL,work.left+(work.right-work.left-width)/2,
        work.top+(work.bottom-work.top-height)/2,width,height,SWP_NOZORDER);
    ShowWindow(window,show); UpdateWindow(window);
#ifdef MANAGER_SMOKE_TEST
    if(!g.smoke)
#endif
    refresh_devices();
    MSG msg; BOOL result;
    while((result=GetMessageW(&msg,NULL,0,0))>0) {
        if(!IsDialogMessageW(window,&msg)) { TranslateMessage(&msg); DispatchMessageW(&msg); }
    }
    for(size_t i=0;i<g.count;++i) if(g.devices[i].process) CloseHandle(g.devices[i].process);
    wm_theme_destroy();
    DeleteObject(g.font); DeleteObject(g.title_font); DeleteObject(g.background); DeleteObject(g.white);
    if(singleton) CloseHandle(singleton);
    return result==-1?1:(int)msg.wParam;
}
