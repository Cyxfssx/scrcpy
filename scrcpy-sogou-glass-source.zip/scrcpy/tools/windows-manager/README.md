# Windows multi-device manager

A native Win32 control panel for the custom scrcpy client. It uses Windows
system controls and one scrcpy process per selected phone; no browser, Python,
.NET, or Qt runtime is required on the user's computer.

The left panel lists ADB devices and supports start all, start/stop checked,
stop all, tile windows, focus a selected window, and per-session log viewing.
The right panel configures the maximum video size, maximum FPS, bitrate,
hardware decoder, audio, recording, video buffering, always-on-top and
borderless windows. Defaults: 1280, 30 FPS, 2 Mbps, auto hardware decoding,
audio off, recording off, and zero extra video buffering.

Turning off a size limit uses the original resolution. Turning off a frame-rate
limit uses unlimited FPS. These switches remove limits; they do not turn off
video. Settings apply when launching a phone. Applying to already running
checked devices closes those sessions normally, finalizes their recording,
then starts new sessions with the chosen parameters. Recording files have
unique names and use MKV. Stop does not forcibly terminate a recording.

Committed host IME text always uses `--text-via-clipboard`. The paired custom
client retains Ctrl+V image-to-gallery transfers. These are independent phone
windows; the manager does not embed, hook, or redirect their keyboard input.
No chat message or image is automatically sent.

## Package layout

```
Manager.exe
engine/             # scrcpy.exe, adb.exe, matching DLLs, custom server, icons
logs/               # created on launch, unique file per device/session
recordings/         # created if recording is requested
manager-settings.ini # last launched profile; generated locally
```

The manager can also run with the engine files beside Manager.exe for developer
use. Keep the entire package together, in a writable folder. It manages its own
launched sessions only, supports up to 32 discovered devices per run, and queues
launches about 400–500 ms apart. Unauthorized/offline devices are not started.
Existing sessions are not duplicated on repeated start commands. A user can
choose to leave phone windows open when closing the manager; those retained
windows are not adopted automatically when reopening the manager.

`Manager.exe` uses the Windows GUI subsystem. Explicit inherited log/pipe
handles plus `CREATE_NO_WINDOW` hide console children. The paired scrcpy client
also uses `CREATE_NO_WINDOW` for its ADB helpers so image transfers do not open
additional console windows. UI errors and device exits are visible through the
status/list and per-session logs.

## Build and validation

From the repository root, with an x86_64 MinGW GCC toolchain on PATH:

```bash
bash tools/windows-manager/build.sh /absolute/output/directory
```

The normal executable is `Manager.exe`. `Manager-smoke.exe` is test-only and
must not be shipped to users. It creates simulated phone processes only in a
build made with `MANAGER_SMOKE_TEST`.

Portable argument/profile/parser tests:

```bash
gcc -std=c11 -Wall -Wextra -Werror -fsanitize=address,undefined \
  tools/windows-manager/model.c tools/windows-manager/test_model.c \
  -o /tmp/manager-model-tests
/tmp/manager-model-tests
```

Windows smoke test (on Windows or under Wine with a desktop):

```text
Manager-smoke.exe --self-test
```

This checks default controls, disabling limits, audio/record switches, hidden
child process output capture, device parsing, prevention of duplicate launches,
ten independent simulated windows and graceful shutdown. It saves a screenshot
and test logs next to the test executable. It does not validate ten real Android
devices, hardware-decoder capacity, actual recordings, Sogou integration or
Samsung gallery indexing. Those require the user's Windows/phone hardware.

The existing scrcpy debug test suite remains available through Meson.

## Frosted glass appearance

The native GDI+ skin draws rounded translucent cards, blue primary buttons,
iOS-style switches, and rounded inputs. The background and frost are cached;
normal device/status updates do not rebuild the blur. Only a wallpaper change,
window resize, or DPI change rebuilds the backdrop. This is a static wallpaper
material, not a continuous desktop-blur shader or web view.

Use the upper-right **更换壁纸** button to choose PNG, JPG or BMP. The entire image
is fitted without cropping; empty side margins use its opaque corner color (or
cream for transparency). Images are loaded once into an independent bitmap,
limited to a 2048-pixel longest side for retained bitmap memory, and the original
file is released. File size is limited to 32 MiB and source size to 64 megapixels
and 16384 pixels per side. This does not change the source image file.

The selected absolute path is stored in a new UTF-16 `appearance.ini`, keeping
Chinese filenames valid on English Windows. Existing `manager-settings.ini`
profile data is independent. A root `wallpaper.png` or `wallpaper.jpg` is used
as a portable default when no saved wallpaper path is usable.

The chat's inline reference wallpaper was not available as a filesystem asset.
The package therefore ships the cream fallback and the wallpaper picker; it
does not claim to contain the original cat image. Supplying the original file
or choosing it locally is required for that exact wallpaper.

The UI smoke test additionally checks real automatic-switch clicks, disabled
fields, bitmap wallpaper decoding, releasing the source file lock, and keeping
the backdrop generation count stable while ten simulated sessions run.
