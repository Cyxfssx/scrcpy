#ifndef SCRCPY_MANAGER_MODEL_H
#define SCRCPY_MANAGER_MODEL_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <wchar.h>

#define WM_MAX_DEVICES 32
#define WM_SERIAL_SIZE 128
#define WM_MODEL_SIZE 96
#define WM_COMMAND_SIZE 8192

enum wm_device_state { WM_DEVICE_READY, WM_DEVICE_OFFLINE, WM_DEVICE_UNAUTHORIZED };
struct wm_discovered_device {
    char serial[WM_SERIAL_SIZE];
    char model[WM_MODEL_SIZE];
    enum wm_device_state state;
};
struct wm_profile {
    unsigned max_size; // 0: original size
    unsigned max_fps; // 0: unlimited
    uint32_t bitrate;
    unsigned buffer_ms;
    unsigned hwdec; // 0: auto, 1: d3d11va, 2: disabled
    bool audio;
    bool record;
    bool topmost;
    bool borderless;
};

struct wm_profile wm_default_profile(void);
bool wm_profile_valid(const struct wm_profile *profile);
size_t wm_parse_devices(const char *output, struct wm_discovered_device *devices,
                        size_t capacity, bool *truncated);
bool wm_build_command(wchar_t *out, size_t capacity, const wchar_t *executable,
                       const wchar_t *serial, const wchar_t *title,
                       const wchar_t *record_path, const struct wm_profile *profile);
#endif
