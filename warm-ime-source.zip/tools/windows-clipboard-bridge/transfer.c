#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#define _WIN32_WINNT 0x0A00
#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <wctype.h>
#include <limits.h>
#include "transfer.h"
#define WT_BLOCK 65536
#define WT_RATE (16u*1024u*1024u)

struct wt_context {
    CRITICAL_SECTION lock;
    HANDLE wake,thread;
    bool stop;
    unsigned next_id,generation,port;
    wchar_t adb[WT_PATH],helper[WT_PATH];
    struct wt_task tasks[WT_CAPACITY];
};
static bool terminal(enum wt_state s){return s==WT_DONE||s==WT_SAVED||s==WT_FAILED||s==WT_CANCELLED;}
static bool copy_text(wchar_t *out,size_t cap,const wchar_t *value){size_t n=wcslen(value);if(n>=cap)return false;memcpy(out,value,(n+1)*sizeof(*out));return true;}
bool wt_remote_valid(const wchar_t *path){
    if(!path||wcsncmp(path,L"/sdcard/",8)||wcslen(path)>1000)return false;
    const wchar_t *part=path+8;
    for(const wchar_t *p=part;;++p){if(*p&&(*p<32||*p==L'\\'))return false;
        if(!*p||*p==L'/'){size_t n=(size_t)(p-part);if(!n||(n==1&&part[0]==L'.')||(n==2&&part[0]==L'.'&&part[1]==L'.'))return false;if(!*p)break;part=p+1;}}
    return true;
}
bool wt_is_image(const wchar_t *path){
    const wchar_t *ext=wcsrchr(path,L'.');if(!ext)return false;
    const wchar_t *formats[]={L".jpg",L".jpeg",L".png",L".webp",L".gif",L".bmp",L".heic",L".heif",L".avif",L".tif",L".tiff"};
    for(size_t i=0;i<sizeof(formats)/sizeof(*formats);++i)if(!_wcsicmp(ext,formats[i]))return true;return false;
}
static bool cancelled(struct wt_context *c,unsigned id){bool result=true;EnterCriticalSection(&c->lock);if(!c->stop)for(unsigned i=0;i<WT_CAPACITY;++i)if(c->tasks[i].id==id){result=c->tasks[i].cancel;break;}LeaveCriticalSection(&c->lock);return result;}
static void update(struct wt_context *c,unsigned id,enum wt_state state,uint64_t sent,const wchar_t *detail){EnterCriticalSection(&c->lock);for(unsigned i=0;i<WT_CAPACITY;++i)if(c->tasks[i].id==id){struct wt_task *t=&c->tasks[i];t->state=state;t->sent=sent;if(detail)copy_text(t->detail,256,detail);++c->generation;break;}LeaveCriticalSection(&c->lock);}
static bool wire(struct wt_context *c,unsigned id,SOCKET s,void *data,size_t size,bool writing){
    char *p=data;ULONGLONG deadline=GetTickCount64()+15000;
    while(size){if(cancelled(c,id))return false;int n=writing?send(s,p,size>WT_BLOCK?WT_BLOCK:(int)size,0):recv(s,p,size>WT_BLOCK?WT_BLOCK:(int)size,0);
        if(n>0){p+=n;size-=(size_t)n;deadline=GetTickCount64()+15000;continue;}if(!n)return false;
        if(WSAGetLastError()!=WSAEWOULDBLOCK)return false;if(GetTickCount64()>deadline)return false;
        fd_set fds;FD_ZERO(&fds);FD_SET(s,&fds);struct timeval wait={0,100000};if(select(0,writing?NULL:&fds,writing?&fds:NULL,NULL,&wait)==SOCKET_ERROR)return false;}
    return true;
}
static bool adb_service(struct wt_context *c,unsigned id,SOCKET s,const char *name){
    size_t length=strlen(name);if(length>65535)return false;char prefix[5];snprintf(prefix,5,"%04x",(unsigned)length);
    char result[4];return wire(c,id,s,prefix,4,true)&&wire(c,id,s,(void*)name,length,true)&&wire(c,id,s,result,4,false)&&!memcmp(result,"OKAY",4);
}
static SOCKET sync_socket(struct wt_context *c,unsigned id,const wchar_t *serial){
    SOCKET s=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);if(s==INVALID_SOCKET)return s;
    u_long nonblocking=1;ioctlsocket(s,FIONBIO,&nonblocking);int enabled=1;setsockopt(s,IPPROTO_TCP,TCP_NODELAY,(const char*)&enabled,sizeof(enabled));
    struct sockaddr_in address={0};address.sin_family=AF_INET;address.sin_addr.s_addr=htonl(INADDR_LOOPBACK);address.sin_port=htons((u_short)c->port);
    if(connect(s,(const struct sockaddr*)&address,sizeof(address))==SOCKET_ERROR){if(WSAGetLastError()!=WSAEWOULDBLOCK)goto fail;
        ULONGLONG deadline=GetTickCount64()+5000;for(;;){if(cancelled(c,id)||GetTickCount64()>deadline)goto fail;
            fd_set writefds,errorfds;FD_ZERO(&writefds);FD_ZERO(&errorfds);FD_SET(s,&writefds);FD_SET(s,&errorfds);struct timeval wait={0,100000};int result=select(0,NULL,&writefds,&errorfds,&wait);
            if(result==SOCKET_ERROR||FD_ISSET(s,&errorfds))goto fail;if(result>0){int error=0;int cap=sizeof(error);if(getsockopt(s,SOL_SOCKET,SO_ERROR,(char*)&error,&cap)||error)goto fail;break;}}}
    char utf[WT_SERIAL*4];if(!WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,serial,-1,utf,sizeof(utf),NULL,NULL))goto fail;
    char service[WT_SERIAL*4+32];snprintf(service,sizeof(service),"host:transport:%s",utf);
    if(!adb_service(c,id,s,service)||!adb_service(c,id,s,"sync:"))goto fail;return s;
fail:closesocket(s);return INVALID_SOCKET;
}
static void put32(unsigned char *p,uint32_t n){p[0]=(unsigned char)n;p[1]=(unsigned char)(n>>8);p[2]=(unsigned char)(n>>16);p[3]=(unsigned char)(n>>24);}
static uint32_t get32(const unsigned char *p){return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);}
static bool packet(struct wt_context *c,unsigned id,SOCKET s,const char *kind,uint32_t value){unsigned char header[8];memcpy(header,kind,4);put32(header+4,value);return wire(c,id,s,header,8,true);}
static bool push_file(struct wt_context *c,const struct wt_task *t,const wchar_t *local,const wchar_t *remote,bool progress){
    HANDLE f=CreateFileW(local,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_FLAG_SEQUENTIAL_SCAN,NULL);if(f==INVALID_HANDLE_VALUE)return false;
    SOCKET s=sync_socket(c,t->id,t->serial);if(s==INVALID_SOCKET){CloseHandle(f);return false;}
    char name[WT_REMOTE*4+16];int n=WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,remote,-1,name,sizeof(name)-16,NULL,NULL);bool ok=false;
    if(!n)goto done;strcat(name,",33204"); // regular file, 0664
    if(!packet(c,t->id,s,"SEND",(uint32_t)strlen(name))||!wire(c,t->id,s,name,strlen(name),true))goto done;
    unsigned char bytes[WT_BLOCK];DWORD got;uint64_t sent=0;ULONGLONG started=GetTickCount64(),last=started;
    while(ReadFile(f,bytes,sizeof(bytes),&got,NULL)&&got){if(!packet(c,t->id,s,"DATA",got)||!wire(c,t->id,s,bytes,got,true))goto done;sent+=got;
        ULONGLONG now=GetTickCount64();if(progress&&now-last>=125){update(c,t->id,WT_ACTIVE,sent,L"正在传输");last=now;}
        ULONGLONG expected=sent*1000/WT_RATE;while(GetTickCount64()-started<expected){if(cancelled(c,t->id))goto done;Sleep(2);}}
    {LARGE_INTEGER size;if(!GetFileSizeEx(f,&size)||sent!=(uint64_t)size.QuadPart)goto done;}
    {FILETIME last;uint32_t modified=0;if(GetFileTime(f,NULL,NULL,&last)){uint64_t ticks=((uint64_t)last.dwHighDateTime<<32)|last.dwLowDateTime;if(ticks>116444736000000000ULL)modified=(uint32_t)((ticks-116444736000000000ULL)/10000000ULL);}if(!packet(c,t->id,s,"DONE",modified))goto done;}
    {unsigned char reply[8];if(!wire(c,t->id,s,reply,8,false))goto done;
        if(memcmp(reply,"OKAY",4)){uint32_t length=get32(reply+4);char error[256];if(length<sizeof(error)){wire(c,t->id,s,error,length,false);}goto done;}}
    if(progress)update(c,t->id,WT_ACTIVE,sent,L"正在保存");ok=true;
done:closesocket(s);CloseHandle(f);return ok;
}
// Both argument layers are quoted independently: Windows argv, then Android shell.
static bool windows_arg(wchar_t *out,size_t capacity,size_t *used,const wchar_t *value){
#define APPEND(ch) do{if(*used+1>=capacity)return false;out[(*used)++]=(ch);out[*used]=0;}while(0)
    if(*used)APPEND(L' ');APPEND(L'"');for(const wchar_t *p=value;*p;){size_t slashes=0;while(*p==L'\\'){++slashes;++p;}size_t count=(*p==L'"'||!*p)?slashes*2:slashes;for(size_t i=0;i<count;++i)APPEND(L'\\');if(*p==L'"')APPEND(L'\\');if(*p)APPEND(*p++);}APPEND(L'"');return true;
#undef APPEND
}
static bool shell_quote(wchar_t *out,size_t capacity,const wchar_t *input){size_t n=0;out[n++]=L'\'';for(;*input;++input){const wchar_t *value=*input==L'\''?L"'\\''":NULL;if(value){for(;*value;++value){if(n+2>=capacity)return false;out[n++]=*value;}}else {if(n+2>=capacity)return false;out[n++]=*input;}}out[n++]=L'\'';out[n]=0;return true;}
static bool run_shell(struct wt_context *c,unsigned id,const wchar_t *serial,const wchar_t *script,unsigned timeout,bool cleanup){
    wchar_t command[32768]=L"";size_t used=0;if(!windows_arg(command,32768,&used,c->adb)||!windows_arg(command,32768,&used,L"-s")||!windows_arg(command,32768,&used,serial)||!windows_arg(command,32768,&used,L"shell")||!windows_arg(command,32768,&used,script))return false;
    SECURITY_ATTRIBUTES sa={sizeof(sa),NULL,TRUE};HANDLE nul=CreateFileW(L"NUL",GENERIC_READ|GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE,&sa,OPEN_EXISTING,0,NULL);if(nul==INVALID_HANDLE_VALUE)return false;
    STARTUPINFOEXW si={0};si.StartupInfo.cb=sizeof(si);si.StartupInfo.dwFlags=STARTF_USESTDHANDLES;si.StartupInfo.hStdInput=si.StartupInfo.hStdOutput=si.StartupInfo.hStdError=nul;
    SIZE_T size=0;InitializeProcThreadAttributeList(NULL,1,0,&size);si.lpAttributeList=HeapAlloc(GetProcessHeap(),0,size);bool initialized=si.lpAttributeList&&InitializeProcThreadAttributeList(si.lpAttributeList,1,0,&size);bool ok=false;
    if(initialized&&UpdateProcThreadAttribute(si.lpAttributeList,0,PROC_THREAD_ATTRIBUTE_HANDLE_LIST,&nul,sizeof(nul),NULL,NULL)){
        PROCESS_INFORMATION process;if(CreateProcessW(c->adb,command,NULL,NULL,TRUE,CREATE_NO_WINDOW|EXTENDED_STARTUPINFO_PRESENT,NULL,NULL,&si.StartupInfo,&process)){
            CloseHandle(process.hThread);ULONGLONG deadline=GetTickCount64()+timeout;DWORD exit=1;
            while(WaitForSingleObject(process.hProcess,50)==WAIT_TIMEOUT){if(GetTickCount64()>deadline||(!cleanup&&cancelled(c,id))){TerminateProcess(process.hProcess,ERROR_CANCELLED);WaitForSingleObject(process.hProcess,1000);break;}}
            if(GetExitCodeProcess(process.hProcess,&exit)&&exit==0)ok=true;CloseHandle(process.hProcess);}}
    if(initialized)DeleteProcThreadAttributeList(si.lpAttributeList);if(si.lpAttributeList)HeapFree(GetProcessHeap(),0,si.lpAttributeList);CloseHandle(nul);return ok;
}
static void execute(struct wt_context *c,const struct wt_task *t){
    wchar_t temporary[WT_REMOTE],qt[WT_REMOTE*4],qd[WT_REMOTE*4],script[WT_REMOTE*8+64];
    swprintf(temporary,WT_REMOTE,L"%ls.warm-part-%u",t->remote,t->id);
    if(!shell_quote(qt,WT_REMOTE*4,temporary)||!shell_quote(qd,WT_REMOTE*4,t->remote)){update(c,t->id,WT_FAILED,0,L"目标路径过长");return;}
    const wchar_t *helper_remote=L"/data/local/tmp/warm-clipboard-scanner-v9.jar";
    wchar_t token[100];swprintf(token,100,L"bridge-%lu-%llu-%u",GetCurrentProcessId(),(unsigned long long)GetTickCount64(),t->id);
    bool helper=false,armed=false;
    if(t->gallery&&wt_is_image(t->local)){
        helper=push_file(c,t,c->helper,helper_remote,false);
        swprintf(script,WT_REMOTE*8+64,L"CLASSPATH=%ls app_process / com.genymobile.scrcpy.WarmImeBridge arm %ls",helper_remote,token);
        if(helper)armed=run_shell(c,t->id,t->serial,script,6000,false);
    }
    bool pushed=push_file(c,t,t->local,temporary,true);
    if(!pushed||cancelled(c,t->id)){
        swprintf(script,WT_REMOTE*8+64,L"rm -f %ls",qt);run_shell(c,t->id,t->serial,script,3000,true);
        update(c,t->id,cancelled(c,t->id)?WT_CANCELLED:WT_FAILED,0,cancelled(c,t->id)?L"已取消":L"传输失败，请检查 USB 连接、手机空间或文件占用");return;}
    swprintf(script,WT_REMOTE*8+64,L"[ ! -e %ls ] && mv %ls %ls",qd,qt,qd);
    if(!run_shell(c,t->id,t->serial,script,10000,false)){
        swprintf(script,WT_REMOTE*8+64,L"rm -f %ls",qt);run_shell(c,t->id,t->serial,script,3000,true);
        update(c,t->id,cancelled(c,t->id)?WT_CANCELLED:WT_FAILED,t->size,L"保存未完成；仅清理本次临时文件");return;}
    if(t->gallery&&wt_is_image(t->local)){
        if(armed){
            update(c,t->id,WT_INDEXING,t->size,L"正在交给当前聊天输入框");
            swprintf(script,WT_REMOTE*8+64,L"CLASSPATH=%ls app_process / com.genymobile.scrcpy.WarmImeBridge deliver %ls %ls",helper_remote,token,qd);
            if(run_shell(c,t->id,t->serial,script,10000,false)){update(c,t->id,WT_DONE,t->size,L"聊天应用已接受图片请求，请检查预览后手动发送");return;}
        }
        update(c,t->id,WT_INDEXING,t->size,L"文件已保存，正在同步相册");
        swprintf(script,WT_REMOTE*8+64,L"CLASSPATH=%ls app_process / com.genymobile.scrcpy.TransferScanner %ls",helper_remote,qd);
        if(!helper||!run_shell(c,t->id,t->serial,script,16000,false)){update(c,t->id,WT_SAVED,t->size,L"文件已保存；相册索引未确认，可到文件夹查看");return;}
        update(c,t->id,WT_DONE,t->size,L"图片已存入手机相册");return;}
    update(c,t->id,WT_DONE,t->size,L"已完成");
}
static DWORD WINAPI worker(void *data){struct wt_context *c=data;
    for(;;){WaitForSingleObject(c->wake,INFINITE);for(;;){struct wt_task *task=calloc(1,sizeof(*task));if(!task)return 1;bool found=false,stop;
        EnterCriticalSection(&c->lock);stop=c->stop;if(!stop){unsigned earliest=UINT_MAX,index=0;for(unsigned i=0;i<WT_CAPACITY;++i)if(c->tasks[i].state==WT_QUEUED&&c->tasks[i].id<earliest){earliest=c->tasks[i].id;index=i;found=true;}
            if(found){c->tasks[index].state=WT_ACTIVE;*task=c->tasks[index];++c->generation;}}
        LeaveCriticalSection(&c->lock);if(stop){free(task);return 0;}if(!found){free(task);break;}execute(c,task);free(task);}}
}
struct wt_context *wt_create(const wchar_t *adb,const wchar_t *helper,unsigned port){
    WSADATA sockets;if(WSAStartup(MAKEWORD(2,2),&sockets))return NULL;
    struct wt_context *c=calloc(1,sizeof(*c));if(!c){WSACleanup();return NULL;}InitializeCriticalSection(&c->lock);c->port=port?port:5037;
    if(!copy_text(c->adb,WT_PATH,adb)||!copy_text(c->helper,WT_PATH,helper))goto fail;c->wake=CreateEventW(NULL,FALSE,FALSE,NULL);if(!c->wake)goto fail;
    c->thread=CreateThread(NULL,0,worker,c,0,NULL);if(!c->thread)goto fail;return c;
fail:if(c->wake)CloseHandle(c->wake);DeleteCriticalSection(&c->lock);free(c);WSACleanup();return NULL;
}
void wt_destroy(struct wt_context *c){if(!c)return;EnterCriticalSection(&c->lock);c->stop=true;CancelSynchronousIo(c->thread);LeaveCriticalSection(&c->lock);SetEvent(c->wake);WaitForSingleObject(c->thread,INFINITE);CloseHandle(c->thread);CloseHandle(c->wake);DeleteCriticalSection(&c->lock);free(c);WSACleanup();}
bool wt_enqueue(struct wt_context *c,const wchar_t *local,const wchar_t *serial,const wchar_t *alias,const wchar_t *dir,uint64_t batch,bool gallery,wchar_t *error,size_t cap){
#define FAIL(message) do{copy_text(error,cap,L##message);return false;}while(0)
    if(!c||!local||!serial||!*serial||wcslen(serial)>=WT_SERIAL)FAIL("文件传输不可用，请重新连接手机");if(!wt_remote_valid(dir))FAIL("目标必须是 /sdcard 下的普通文件夹，不能包含 .. 或控制字符");
    WIN32_FILE_ATTRIBUTE_DATA info;if(!GetFileAttributesExW(local,GetFileExInfoStandard,&info))FAIL("无法读取文件，请检查路径和权限");
    if(info.dwFileAttributes&(FILE_ATTRIBUTE_DIRECTORY|FILE_ATTRIBUTE_REPARSE_POINT))FAIL("请拖入文件；暂不支持文件夹或链接");
    const wchar_t *leaf=wcsrchr(local,L'\\');leaf=leaf?leaf+1:local;const wchar_t *ext=wcsrchr(leaf,L'.');if(ext&&!_wcsicmp(ext,L".lnk"))FAIL("快捷方式不是文件本身，请选择原文件");
    struct wt_task *t=calloc(1,sizeof(*t));if(!t)FAIL("内存不足");t->state=WT_QUEUED;t->gallery=gallery;t->size=((uint64_t)info.nFileSizeHigh<<32)|info.nFileSizeLow;
    if(!copy_text(t->local,WT_PATH,local)||!copy_text(t->serial,WT_SERIAL,serial)||!copy_text(t->alias,64,alias)){free(t);FAIL("文件路径或设备名称过长");}
    int n=swprintf(t->remote,WT_REMOTE,L"%ls/bridge-%llu-%ls",dir,(unsigned long long)batch,leaf);if(n<0||n>=WT_REMOTE-40){free(t);FAIL("手机目标路径过长");}copy_text(t->detail,256,L"等待中");
    bool added=false;EnterCriticalSection(&c->lock);if(!c->stop)for(unsigned i=0;i<WT_CAPACITY;++i)if(!c->tasks[i].id){t->id=++c->next_id;bool collision=false;for(unsigned j=0;j<WT_CAPACITY;++j)if(c->tasks[j].id&&!wcscmp(c->tasks[j].serial,serial)&&!wcscmp(c->tasks[j].remote,t->remote))collision=true;
        if(collision)swprintf(t->remote,WT_REMOTE,L"%ls/bridge-%llu-%u-%ls",dir,(unsigned long long)batch,t->id,leaf);c->tasks[i]=*t;++c->generation;added=true;break;}LeaveCriticalSection(&c->lock);free(t);
    if(!added)FAIL("传输列表已满，请先清理已完成记录");SetEvent(c->wake);return true;
#undef FAIL
}
size_t wt_snapshot(struct wt_context *c,struct wt_task *tasks,size_t capacity){if(!c)return 0;size_t count=0;EnterCriticalSection(&c->lock);for(unsigned i=0;i<WT_CAPACITY&&count<capacity;++i)if(c->tasks[i].id)tasks[count++]=c->tasks[i];LeaveCriticalSection(&c->lock);
    // Slots may have been reused after clearing old records; preserve submission order.
    for(size_t i=1;i<count;++i){struct wt_task current=tasks[i];size_t j=i;while(j&&tasks[j-1].id>current.id){tasks[j]=tasks[j-1];--j;}tasks[j]=current;}return count;
}
void wt_cancel(struct wt_context *c,unsigned id){if(!c)return;EnterCriticalSection(&c->lock);for(unsigned i=0;i<WT_CAPACITY;++i)if(c->tasks[i].id==id&&!terminal(c->tasks[i].state)){c->tasks[i].cancel=true;
        // Keep the lock while interrupting I/O so the worker cannot switch to
        // an unrelated next task between the cancellation and this request.
        if(c->tasks[i].state==WT_ACTIVE||c->tasks[i].state==WT_INDEXING)CancelSynchronousIo(c->thread);
        if(c->tasks[i].state==WT_QUEUED){c->tasks[i].state=WT_CANCELLED;copy_text(c->tasks[i].detail,256,L"已取消");}++c->generation;break;}LeaveCriticalSection(&c->lock);}
void wt_cancel_all(struct wt_context *c){if(!c)return;EnterCriticalSection(&c->lock);for(unsigned i=0;i<WT_CAPACITY;++i)if(c->tasks[i].id&&!terminal(c->tasks[i].state)){c->tasks[i].cancel=true;
        // Keep the lock while interrupting I/O so the worker cannot switch to
        // an unrelated next task between the cancellation and this request.
        if(c->tasks[i].state==WT_ACTIVE||c->tasks[i].state==WT_INDEXING)CancelSynchronousIo(c->thread);
        if(c->tasks[i].state==WT_QUEUED){c->tasks[i].state=WT_CANCELLED;copy_text(c->tasks[i].detail,256,L"已取消");}}++c->generation;LeaveCriticalSection(&c->lock);}
void wt_clear_completed(struct wt_context *c){if(!c)return;EnterCriticalSection(&c->lock);for(unsigned i=0;i<WT_CAPACITY;++i)if(terminal(c->tasks[i].state))c->tasks[i].id=0;++c->generation;LeaveCriticalSection(&c->lock);}
bool wt_busy(struct wt_context *c){if(!c)return false;bool busy=false;EnterCriticalSection(&c->lock);for(unsigned i=0;i<WT_CAPACITY;++i)busy|=c->tasks[i].id&&!terminal(c->tasks[i].state);LeaveCriticalSection(&c->lock);return busy;}
unsigned wt_generation(struct wt_context *c){if(!c)return 0;EnterCriticalSection(&c->lock);unsigned n=c->generation;LeaveCriticalSection(&c->lock);return n;}

#ifdef MANAGER_SMOKE_TEST
void wt_test_preview(struct wt_context *c,const wchar_t *serial,const wchar_t *alias){
    const wchar_t *names[]={L"C:\\模拟\\图片01.jpg",L"C:\\模拟\\资料.pdf",L"C:\\模拟\\视频.mp4"};
    const enum wt_state states[]={WT_DONE,WT_ACTIVE,WT_QUEUED};
    EnterCriticalSection(&c->lock);
    for(unsigned i=0;i<3;++i){struct wt_task *t=&c->tasks[i];memset(t,0,sizeof(*t));t->id=++c->next_id;t->state=states[i];copy_text(t->local,WT_PATH,names[i]);copy_text(t->serial,WT_SERIAL,serial);copy_text(t->alias,64,alias);t->size=(i+1)*2400000;t->sent=i==0?t->size:i==1?t->size*62/100:0;copy_text(t->detail,256,i==0?L"已完成":i==1?L"正在传输":L"等待中");}
    ++c->generation;LeaveCriticalSection(&c->lock);
}
#endif

void wt_clear_device_completed(struct wt_context *c,const wchar_t *serial){if(!c||!serial)return;EnterCriticalSection(&c->lock);for(unsigned i=0;i<WT_CAPACITY;++i)if(c->tasks[i].id&&terminal(c->tasks[i].state)&&!wcscmp(c->tasks[i].serial,serial))c->tasks[i].id=0;++c->generation;LeaveCriticalSection(&c->lock);}
