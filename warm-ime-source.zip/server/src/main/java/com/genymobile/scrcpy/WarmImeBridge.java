package com.genymobile.scrcpy;

import android.content.ContentResolver;
import android.net.Uri;
import android.os.Bundle;
import android.os.Looper;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;

/** Optional shell-UID adapter to the separately installed Warm IME; never starts a chat or sends. */
public final class WarmImeBridge {
    private static final Uri BASE = Uri.parse("content://com.cyxfssx.warmime.images");
    private WarmImeBridge() { }
    private static String call(ContentResolver resolver, String method, String token) {
        Bundle result = resolver.call(BASE, method, token, null);
        return result == null ? "unavailable" : result.getString("status", "unavailable");
    }
    private static int run(String[] args) throws Exception {
        if (args.length < 2 || !args[1].matches("[A-Za-z0-9_-]{8,100}")) return 2;
        ContentResolver resolver = FakeContext.get().getContentResolver();
        String token = args[1];
        if (args.length == 2 && args[0].equals("arm")) return call(resolver, "arm", token).equals("ready") ? 0 : 20;
        if (args.length != 3 || !args[0].equals("deliver") || !args[2].startsWith("/sdcard/")) return 2;
        File image = new File(args[2]);
        if (!image.isFile() || image.length() <= 0 || image.length() > 32L * 1024 * 1024) return 2;
        try (FileInputStream in = new FileInputStream(image);
                OutputStream out = resolver.openOutputStream(BASE.buildUpon().appendPath("upload").appendPath(token).build(), "w")) {
            if (out == null) return 21;
            byte[] bytes = new byte[65536]; int got; long total = 0;
            while ((got = in.read(bytes)) != -1) {
                total += got; if (total > 32L * 1024 * 1024) return 2;
                out.write(bytes, 0, got);
            }
        }
        String status = call(resolver, "deliver", token);
        // A pending command might still complete: do not submit it a second time.
        for (int i = 0; i < 20 && (status.equals("pending") || status.equals("working")); ++i) {
            Thread.sleep(100); status = call(resolver, "result", token);
        }
        System.out.println("Warm IME: " + status);
        return status.equals("accepted") ? 0 : 22;
    }
    @SuppressWarnings("deprecation")
    public static void main(String... args) {
        try {
            Looper.prepareMainLooper(); Workarounds.apply();
            new Thread(() -> {
                try { System.exit(run(args)); }
                catch (Throwable e) { System.err.println("Warm IME unavailable: " + e.getClass().getSimpleName()); System.exit(20); }
            }, "warm-ime-adapter").start();
            Looper.loop();
        } catch (Throwable e) { System.err.println("Warm IME adapter unavailable"); System.exit(20); }
    }
}
