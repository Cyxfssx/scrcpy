#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
manager_build_dir="${1:-/workspace/setup/windows/manager-build}"
mkdir -p "$manager_build_dir"
manager_cc="${CC_WIN:-x86_64-w64-mingw32-gcc}"
x86_64-w64-mingw32-windres -Iapp/data -Itools/windows-manager tools/windows-manager/manager.rc "$manager_build_dir/manager-res.o"
"$manager_cc" -std=c11 -O2 -Wall -Wextra -Werror -Wno-misleading-indentation -municode -mwindows -static-libgcc \
    tools/windows-manager/manager.c tools/windows-manager/model.c tools/windows-manager/theme.c tools/windows-manager/transfer.c tools/windows-manager/drop.c "$manager_build_dir/manager-res.o" \
    -o "$manager_build_dir/Manager.exe" -lcomctl32 -lshell32 -lgdi32 -luser32 -lgdiplus -ldwmapi -luxtheme -lcomdlg32 -lpsapi -lws2_32 -lole32 -luuid -lm
"$manager_cc" -std=c11 -O1 -g -Wall -Wextra -Werror -Wno-misleading-indentation -DMANAGER_SMOKE_TEST -municode -mwindows -static-libgcc \
    tools/windows-manager/manager.c tools/windows-manager/model.c tools/windows-manager/theme.c tools/windows-manager/transfer.c tools/windows-manager/drop.c "$manager_build_dir/manager-res.o" \
    -o "$manager_build_dir/Manager-smoke.exe" -lcomctl32 -lshell32 -lgdi32 -luser32 -lgdiplus -ldwmapi -luxtheme -lcomdlg32 -lpsapi -lws2_32 -lole32 -luuid -lm

# Standalone regression executables are never included in the user package.
"$manager_cc" -std=c11 -O1 -g -Wall -Wextra -Werror -Wno-misleading-indentation -Wno-sign-compare -municode -static-libgcc \
    tools/windows-manager/transfer.c tools/windows-manager/test_transfer.c -o "$manager_build_dir/Transfer-test.exe" -lws2_32
"$manager_cc" -std=c11 -O1 -Wall -Wextra -Werror -Wno-misleading-indentation -DMANAGER_SMOKE_TEST -municode -static-libgcc \
    tools/windows-manager/drop.c tools/windows-manager/test_drop.c -o "$manager_build_dir/Drop-test.exe" -lole32 -lshell32 -luuid
