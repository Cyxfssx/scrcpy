#define COBJMACROS
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <ole2.h>
#include <shellapi.h>
#include <stdlib.h>
#ifdef MANAGER_SMOKE_TEST
#include <stdio.h>
#endif
#include "drop.h"
struct drop_target {IDropTarget iface;LONG refs;HWND window;wd_ready ready;wd_files files;wd_hover hover;void *user;bool accepted;};
static HRESULT STDMETHODCALLTYPE query(IDropTarget *self,REFIID iid,void **out){if(!out)return E_POINTER;*out=NULL;if(IsEqualIID(iid,&IID_IUnknown)||IsEqualIID(iid,&IID_IDropTarget)){*out=self;IDropTarget_AddRef(self);return S_OK;}return E_NOINTERFACE;}
static ULONG STDMETHODCALLTYPE add_ref(IDropTarget *self){return (ULONG)InterlockedIncrement(&((struct drop_target*)self)->refs);}
static ULONG STDMETHODCALLTYPE release(IDropTarget *self){struct drop_target *d=(struct drop_target*)self;LONG refs=InterlockedDecrement(&d->refs);if(!refs)free(d);return (ULONG)refs;}
static HRESULT STDMETHODCALLTYPE enter(IDropTarget *self,IDataObject *data,DWORD keys,POINTL point,DWORD *effect){(void)keys;(void)point;struct drop_target *d=(struct drop_target*)self;FORMATETC format={CF_HDROP,NULL,DVASPECT_CONTENT,-1,TYMED_HGLOBAL};d->accepted=IDataObject_QueryGetData(data,&format)==S_OK;bool active=d->accepted&&d->ready(d->user);if(effect)*effect=active?DROPEFFECT_COPY:DROPEFFECT_NONE;d->hover(d->user,active);return S_OK;}
static HRESULT STDMETHODCALLTYPE over(IDropTarget *self,DWORD keys,POINTL point,DWORD *effect){(void)keys;(void)point;struct drop_target *d=(struct drop_target*)self;bool active=d->accepted&&d->ready(d->user);if(effect)*effect=active?DROPEFFECT_COPY:DROPEFFECT_NONE;return S_OK;}
static HRESULT STDMETHODCALLTYPE leave(IDropTarget *self){struct drop_target *d=(struct drop_target*)self;d->accepted=false;d->hover(d->user,false);return S_OK;}
static HRESULT STDMETHODCALLTYPE drop(IDropTarget *self,IDataObject *data,DWORD keys,POINTL point,DWORD *effect){(void)keys;(void)point;struct drop_target *d=(struct drop_target*)self;if(effect)*effect=DROPEFFECT_NONE;
    if(d->ready(d->user)){FORMATETC format={CF_HDROP,NULL,DVASPECT_CONTENT,-1,TYMED_HGLOBAL};STGMEDIUM storage={0};if(IDataObject_GetData(data,&format,&storage)==S_OK){d->files(d->user,(HDROP)storage.hGlobal);ReleaseStgMedium(&storage);if(effect)*effect=DROPEFFECT_COPY;}}
    d->accepted=false;d->hover(d->user,false);return S_OK;
}
static IDropTargetVtbl methods={query,add_ref,release,enter,over,leave,drop};
bool wd_register(HWND window,wd_ready ready,wd_files files,wd_hover hover,void *user){struct drop_target *d=calloc(1,sizeof(*d));if(!d)return false;d->iface.lpVtbl=&methods;d->refs=1;d->window=window;d->ready=ready;d->files=files;d->hover=hover;d->user=user;HRESULT result=RegisterDragDrop(window,&d->iface);
#ifdef MANAGER_SMOKE_TEST
    if(FAILED(result))fprintf(stderr,"RegisterDragDrop failed: 0x%08lx\n",(unsigned long)result);
#endif
if(SUCCEEDED(result))SetPropW(window,L"WarmDropTarget",d);release(&d->iface);return SUCCEEDED(result);}
void wd_revoke(HWND window){RemovePropW(window,L"WarmDropTarget");RevokeDragDrop(window);}

#ifdef MANAGER_SMOKE_TEST
DWORD wd_test_dispatch(HWND window,IDataObject *data,bool cancel){struct drop_target *d=(struct drop_target*)GetPropW(window,L"WarmDropTarget");if(!d)return 0xffffffff;IDropTarget_AddRef(&d->iface);DWORD effect=DROPEFFECT_COPY;POINTL point={0,0};enter(&d->iface,data,0,point,&effect);if(cancel||effect==DROPEFFECT_NONE)leave(&d->iface);else drop(&d->iface,data,0,point,&effect);IDropTarget_Release(&d->iface);return effect;}
#endif
