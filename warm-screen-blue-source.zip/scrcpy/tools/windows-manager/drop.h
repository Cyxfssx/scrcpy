#ifndef WARM_DROP_H
#define WARM_DROP_H
#include <windows.h>
#include <shellapi.h>
#include <stdbool.h>
typedef bool (*wd_ready)(void *user);
typedef void (*wd_files)(void *user,HDROP files);
typedef void (*wd_hover)(void *user,bool active);
bool wd_register(HWND window,wd_ready ready,wd_files files,wd_hover hover,void *user);
void wd_revoke(HWND window);
#endif
