#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <uxtheme.h>
#include <dwmapi.h>
#include <gdiplus.h>
#include <stdint.h>
#include <stdlib.h>
#include <wchar.h>
#include <stdbool.h>
#include <math.h>
#include "theme.h"

#define THEME_PATH 2048
struct theme {
    HWND parent;
    ULONG_PTR token;
    GpBitmap *wallpaper;
    HDC cache;
    HBITMAP bitmap, old_bitmap;
    HBRUSH input, disabled_input;
    int width,height,view_width,view_height;
    bool transfer_view;
    unsigned dpi, generation;
    COLORREF matte;
    wchar_t ini[THEME_PATH], directory[THEME_PATH];
};
static struct theme theme;
struct control_theme { enum wm_theme_role role; bool hover; wchar_t *text; };
static int scale(int n) {
    if(theme.width&&theme.height){int sx=MulDiv(theme.width,1000,1586),sy=MulDiv(theme.height,1000,992);return MulDiv(n,sx<sy?sx:sy,1000);}
    return MulDiv(n,(int)theme.dpi,96);
}
static void rounded_path(GpPath *path, float x, float y, float w, float h, float r) {
    if(r>w/2)r=w/2;if(r>h/2)r=h/2;
    float d=2*r;
    GdipAddPathArc(path,x,y,d,d,180,90);
    GdipAddPathArc(path,x+w-d,y,d,d,270,90);
    GdipAddPathArc(path,x+w-d,y+h-d,d,d,0,90);
    GdipAddPathArc(path,x,y+h-d,d,d,90,90);
    GdipClosePathFigure(path);
}
static void rounded(GpGraphics *graphics, float x,float y,float w,float h,float r,ARGB fill,ARGB outline) {
    if(w<=0||h<=0) return;
    GpPath *path=NULL; GdipCreatePath(FillModeAlternate,&path); if(!path) return;
    rounded_path(path,x,y,w,h,r);
    if(fill) { GpSolidFill *brush=NULL; GdipCreateSolidFill(fill,&brush); if(brush) { GdipFillPath(graphics,(GpBrush*)brush,path); GdipDeleteBrush((GpBrush*)brush); } }
    if(outline) { GpPen *pen=NULL; GdipCreatePen1(outline,1.0f,UnitPixel,&pen); if(pen) { GdipDrawPath(graphics,pen,path); GdipDeletePen(pen); } }
    GdipDeletePath(path);
}
void wm_theme_round(HDC dc,int x,int y,int w,int h,int radius,uint32_t fill,uint32_t outline) {
    GpGraphics *graphics=NULL;GdipCreateFromHDC(dc,&graphics);
    if(graphics){GdipSetSmoothingMode(graphics,SmoothingModeAntiAlias);rounded(graphics,(float)x,(float)y,(float)w,(float)h,(float)scale(radius),fill,outline);GdipDeleteGraphics(graphics);}
}
void wm_theme_symbol(HDC dc,int kind,int x,int y,int size,COLORREF color) {
    int saved=SaveDC(dc);SetBkMode(dc,TRANSPARENT);
    HPEN pen=CreatePen(PS_SOLID,size>18?2:1,color);HBRUSH brush=CreateSolidBrush(color);
    SelectObject(dc,pen);SelectObject(dc,GetStockObject(NULL_BRUSH));
#define X(n) (x+MulDiv((n),size,24))
#define Y(n) (y+MulDiv((n),size,24))
#define LINE(a,b,c,d) do{MoveToEx(dc,X(a),Y(b),NULL);LineTo(dc,X(c),Y(d));}while(0)
    switch(kind) {
        case 1:Ellipse(dc,X(2),Y(2),X(22),Y(22));LINE(12,10,12,18);LINE(12,6,12,8);break;
        case 2:{POINT p[]={{X(2),Y(7)},{X(2),Y(21)},{X(22),Y(21)},{X(22),Y(8)},{X(11),Y(8)},{X(8),Y(4)},{X(2),Y(4)},{X(2),Y(7)}};Polyline(dc,p,8);break;}
        case 3:RoundRect(dc,X(4),Y(2),X(21),Y(23),3,3);LINE(8,9,17,9);LINE(8,13,17,13);LINE(8,17,14,17);break;
        case 4:case 20:RoundRect(dc,X(2),Y(4),X(22),Y(21),3,3);Ellipse(dc,X(6),Y(7),X(10),Y(11));LINE(4,18,11,12);LINE(11,12,15,16);LINE(15,16,19,12);LINE(19,12,22,16);break;
        case 5:{SelectObject(dc,brush);POINT p[]={{X(5),Y(2)},{X(22),Y(12)},{X(5),Y(22)}};Polygon(dc,p,3);break;}
        case 6:SelectObject(dc,brush);RoundRect(dc,X(4),Y(4),X(20),Y(20),3,3);break;
        case 7:SelectObject(dc,brush);for(int row=0;row<2;++row)for(int col=0;col<2;++col)RoundRect(dc,X(2+col*12),Y(2+row*12),X(10+col*12),Y(10+row*12),3,3);break;
        case 8:RoundRect(dc,X(3),Y(3),X(22),Y(22),3,3);Rectangle(dc,X(7),Y(3),X(17),Y(10));Rectangle(dc,X(7),Y(14),X(18),Y(22));break;
        case 9:Ellipse(dc,X(2),Y(10),X(14),Y(22));Ellipse(dc,X(10),Y(2),X(22),Y(14));LINE(8,17,17,8);break;
        case 10:case 21:{POINT points[26];for(int i=0;i<26;++i){double angle=(40+i*11)*3.141592653589793/180;points[i]=(POINT){X(12)+(int)(cos(angle)*size*0.4),Y(12)+(int)(sin(angle)*size*0.4)};}Polyline(dc,points,26);LINE(18,3,18,10);LINE(18,10,24,8);break;}
        case 11:RoundRect(dc,X(2),Y(2),X(22),Y(22),3,3);LINE(6,12,10,17);LINE(10,17,18,7);break;
        case 12:{SelectObject(dc,brush);POINT p[]={{X(12),Y(21)},{X(2),Y(11)},{X(2),Y(5)},{X(6),Y(2)},{X(12),Y(6)},{X(18),Y(2)},{X(22),Y(5)},{X(22),Y(11)}};Polygon(dc,p,8);break;}
        case 13:RoundRect(dc,X(6),Y(1),X(19),Y(23),4,4);LINE(10,4,15,4);LINE(11,20,14,20);break;
        case 14:{POINT p[]={{X(2),Y(9)},{X(7),Y(9)},{X(13),Y(4)},{X(13),Y(21)},{X(7),Y(16)},{X(2),Y(16)},{X(2),Y(9)}};Polyline(dc,p,7);Arc(dc,X(11),Y(4),X(23),Y(21),X(20),Y(4),X(20),Y(21));break;}
        case 15:RoundRect(dc,X(2),Y(6),X(17),Y(20),3,3);LINE(17,10,23,6);LINE(23,6,23,20);LINE(23,20,17,16);break;
        case 16:{POINT p[]={{X(2),Y(8)},{X(12),Y(2)},{X(22),Y(8)},{X(12),Y(14)},{X(2),Y(8)}};Polyline(dc,p,5);LINE(2,13,12,19);LINE(12,19,22,13);LINE(2,18,12,24);LINE(12,24,22,18);break;}
        case 17:LINE(9,2,19,12);LINE(6,6,16,16);LINE(9,2,6,6);LINE(19,12,16,16);LINE(12,10,3,21);break;
        case 18:RoundRect(dc,X(2),Y(3),X(22),Y(22),3,3);LINE(2,8,22,8);LINE(9,8,9,22);break;
        case 19:RoundRect(dc,X(1),Y(6),X(23),Y(20),3,3);for(int row=0;row<2;++row)for(int col=0;col<5;++col)Rectangle(dc,X(4+col*4),Y(9+row*4),X(5+col*4),Y(10+row*4));break;
        case 22:LINE(4,12,20,12);break;
        case 23:Rectangle(dc,X(5),Y(5),X(20),Y(20));break;
        case 24:LINE(5,5,20,20);LINE(20,5,5,20);break;
        case 26:LINE(3,12,3,21);LINE(3,21,21,21);LINE(21,21,21,12);LINE(12,16,12,2);LINE(7,7,12,2);LINE(12,2,17,7);break;
        default:Rectangle(dc,X(4),Y(5),X(21),Y(19));LINE(12,19,12,23);LINE(7,23,18,23);break;
    }
#undef LINE
#undef X
#undef Y
    RestoreDC(dc,saved);DeleteObject(brush);DeleteObject(pen);
}
static void clear_cache(void) {
    if(theme.cache) {
        SelectObject(theme.cache,theme.old_bitmap); DeleteObject(theme.bitmap); DeleteDC(theme.cache);
        theme.cache=NULL; theme.bitmap=NULL;
    }
}
static bool load_wallpaper(const wchar_t *path) {
    WIN32_FILE_ATTRIBUTE_DATA info;
    if(!GetFileAttributesExW(path,GetFileExInfoStandard,&info)
        || info.nFileSizeHigh || info.nFileSizeLow>32u*1024u*1024u) return false;
    GpBitmap *source=NULL,*image=NULL; UINT width=0,height=0;
    if(GdipCreateBitmapFromFile(path,&source)!=Ok || !source) return false;
    GdipGetImageWidth((GpImage*)source,&width); GdipGetImageHeight((GpImage*)source,&height);
    if(!width||!height||width>16384||height>16384||(uint64_t)width*height>64u*1024u*1024u) { GdipDisposeImage((GpImage*)source); return false; }
    UINT nw=width, nh=height;
    if(nw>2048||nh>2048) {
        if(nw>=nh) { nh=(UINT)((uint64_t)nh*2048/nw); nw=2048; }
        else { nw=(UINT)((uint64_t)nw*2048/nh); nh=2048; }
        if(!nw)nw=1; if(!nh)nh=1;
    }
    bool ok=false;
    if(GdipCreateBitmapFromScan0((INT)nw,(INT)nh,0,PixelFormat32bppPARGB,NULL,&image)==Ok) {
        GpGraphics *graphics=NULL;
        if(GdipGetImageGraphicsContext((GpImage*)image,&graphics)==Ok) {
            GdipSetInterpolationMode(graphics,InterpolationModeHighQualityBicubic);
            ok=GdipDrawImageRectI(graphics,(GpImage*)source,0,0,(INT)nw,(INT)nh)==Ok;
            GdipDeleteGraphics(graphics);
        }
    }
    GdipDisposeImage((GpImage*)source); // Release the user's original file lock.
    if(!ok) { if(image)GdipDisposeImage((GpImage*)image); return false; }
    if(theme.wallpaper)GdipDisposeImage((GpImage*)theme.wallpaper);
    theme.wallpaper=image;
    ARGB corner;
    theme.matte=RGB(244,247,251);
    if(GdipBitmapGetPixel(image,0,0,&corner)==Ok && (corner>>24)==255)
        theme.matte=RGB((corner>>16)&255,(corner>>8)&255,corner&255);
    clear_cache(); return true;
}
static void rebuild(void) {
    if(theme.width<=0||theme.height<=0||theme.width>10000||theme.height>10000)return;
    clear_cache();HDC screen=GetDC(theme.parent);theme.cache=CreateCompatibleDC(screen);
    theme.bitmap=CreateCompatibleBitmap(screen,theme.width,theme.height);
    if(!theme.cache||!theme.bitmap){if(theme.bitmap)DeleteObject(theme.bitmap);if(theme.cache)DeleteDC(theme.cache);theme.cache=NULL;theme.bitmap=NULL;ReleaseDC(theme.parent,screen);return;}
    theme.old_bitmap=SelectObject(theme.cache,theme.bitmap);
    RECT full={0,0,theme.width,theme.height};HBRUSH bg=CreateSolidBrush(RGB(244,247,251));FillRect(theme.cache,&full,bg);DeleteObject(bg);
    const RECT normal_cards[]={
        {20,104,350,900},{365,104,1238,290},{365,304,1238,900},
        {1254,104,1566,750},{1254,764,1566,900},{20,915,1566,991}
    };
    const RECT transfer_cards[]={
        {20,122,426,872},{440,122,850,270},{440,282,850,467},
        {440,480,850,872},{864,122,1566,609},{864,622,1566,879},
        {20,891,1566,942},{20,944,1566,987}
    };
    const RECT *cards=theme.transfer_view?transfer_cards:normal_cards;
    unsigned count=theme.transfer_view?8:6;
    GpGraphics *graphics=NULL;GdipCreateFromHDC(theme.cache,&graphics);
    if(graphics){GdipSetSmoothingMode(graphics,SmoothingModeAntiAlias);
        for(unsigned i=0;i<count;++i){RECT r=cards[i];float x=(float)MulDiv(r.left,theme.width,1586),y=(float)MulDiv(r.top,theme.height,992);
            rounded(graphics,x,y,(float)MulDiv(r.right-r.left,theme.width,1586),(float)MulDiv(r.bottom-r.top,theme.height,992),(float)scale(10),0xFFFFFFFF,0xFFDEE7F0);}
        GdipDeleteGraphics(graphics);
    }
    ReleaseDC(theme.parent,screen);++theme.generation;
}
bool wm_theme_init(HWND parent,const wchar_t *directory,const wchar_t *ini) {
    theme.parent=parent;theme.dpi=96;theme.matte=RGB(244,247,251);
    (void)ini;
    wcsncpy(theme.directory,directory,THEME_PATH-1);
    swprintf(theme.ini,THEME_PATH,L"%ls\\appearance.ini",directory);
    GdiplusStartupInput startup={1,NULL,FALSE,TRUE};
    if(GdiplusStartup(&theme.token,&startup,NULL)!=Ok) return false;
    theme.input=CreateSolidBrush(RGB(255,255,255));theme.disabled_input=CreateSolidBrush(RGB(247,247,249));
    // Solid blue/white UI does not load saved wallpapers or allocate blur buffers.
    DWORD corners=2; DwmSetWindowAttribute(parent,33,&corners,sizeof(corners));
    COLORREF caption=RGB(244,247,251);DwmSetWindowAttribute(parent,35,&caption,sizeof(caption));
    return true;
}
void wm_theme_destroy(void) {
    clear_cache();if(theme.wallpaper)GdipDisposeImage((GpImage*)theme.wallpaper);
    if(theme.input)DeleteObject(theme.input);if(theme.disabled_input)DeleteObject(theme.disabled_input);
    if(theme.token)GdiplusShutdown(theme.token);ZeroMemory(&theme,sizeof(theme));
}
void wm_theme_set_transfer(bool active){if(theme.transfer_view!=active){theme.transfer_view=active;clear_cache();}}
void wm_theme_preview_resize(int width,int height){theme.view_width=width;theme.view_height=height;}
void wm_theme_resize(int width,int height,unsigned dpi) {
    theme.view_width=width;theme.view_height=height;
    if(theme.width==width&&theme.height==height&&theme.dpi==dpi&&theme.cache)return;
    theme.width=width;theme.height=height;theme.dpi=dpi;rebuild();
}
void wm_theme_paint(HDC dc,const RECT *rect) {
    if(theme.cache){int vw=theme.view_width?theme.view_width:theme.width,vh=theme.view_height?theme.view_height:theme.height;
        if(vw==theme.width&&vh==theme.height)BitBlt(dc,rect->left,rect->top,rect->right-rect->left,rect->bottom-rect->top,theme.cache,rect->left,rect->top,SRCCOPY);
        else {SetStretchBltMode(dc,HALFTONE);int x=MulDiv(rect->left,theme.width,vw),y=MulDiv(rect->top,theme.height,vh),right=MulDiv(rect->right,theme.width,vw),bottom=MulDiv(rect->bottom,theme.height,vh);
            StretchBlt(dc,rect->left,rect->top,rect->right-rect->left,rect->bottom-rect->top,theme.cache,x,y,right-x,bottom-y,SRCCOPY);}}
    else {HBRUSH b=CreateSolidBrush(RGB(244,247,251));FillRect(dc,rect,b);DeleteObject(b);}
}
void wm_theme_child_background(HWND control,HDC dc) {
    RECT r;GetClientRect(control,&r);POINT origin={0,0};MapWindowPoints(control,theme.parent,&origin,1);
    if(theme.cache){int vw=theme.view_width?theme.view_width:theme.width,vh=theme.view_height?theme.view_height:theme.height;
        if(vw==theme.width&&vh==theme.height)BitBlt(dc,0,0,r.right,r.bottom,theme.cache,origin.x,origin.y,SRCCOPY);
        else {SetStretchBltMode(dc,HALFTONE);StretchBlt(dc,0,0,r.right,r.bottom,theme.cache,MulDiv(origin.x,theme.width,vw),MulDiv(origin.y,theme.height,vh),MulDiv(r.right,theme.width,vw),MulDiv(r.bottom,theme.height,vh),SRCCOPY);}}
    else {HBRUSH b=CreateSolidBrush(RGB(244,247,251));FillRect(dc,&r,b);DeleteObject(b);}
}
static void paint_toggle(HWND control,HDC dc) {
    wm_theme_child_background(control,dc);RECT r;GetClientRect(control,&r);
    bool selected=SendMessageW(control,BM_GETCHECK,0,0)==BST_CHECKED;
    int width=scale(40),height=scale(23),top=(r.bottom-height)/2,left=r.right-width-scale(2);
    GpGraphics *graphics=NULL;GdipCreateFromHDC(dc,&graphics);
    if(graphics) {
        GdipSetSmoothingMode(graphics,SmoothingModeAntiAlias);
        rounded(graphics,(float)left,(float)top,(float)width,(float)height,(float)height/2,selected?0xFF007AFF:0xFFD8DAE0,0);
        int thumb=height-scale(4),x=left+(selected?width-thumb-scale(2):scale(2));
        rounded(graphics,(float)x,(float)(top+scale(2)),(float)thumb,(float)thumb,(float)thumb/2,0xFFFFFFFF,0x18000000);
        GdipDeleteGraphics(graphics);
    }
    wchar_t text[256];GetWindowTextW(control,text,256);
    SelectObject(dc,(HFONT)SendMessageW(control,WM_GETFONT,0,0));SetBkMode(dc,TRANSPARENT);
    SetTextColor(dc,IsWindowEnabled(control)?RGB(43,50,65):RGB(150,150,158));
    int symbol=(int)(INT_PTR)GetPropW(control,L"warmSymbol");
    if(symbol){wm_theme_symbol(dc,symbol,0,(r.bottom-scale(21))/2,scale(21),RGB(35,50,68));r.left+=scale(31);}
    r.right=left-scale(8);DrawTextW(dc,text,-1,&r,DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS);
    if(GetFocus()==control&&!(SendMessageW(control,WM_QUERYUISTATE,0,0)&UISF_HIDEFOCUS)){InflateRect(&r,-1,-1);DrawFocusRect(dc,&r);}
}
static void paint_label(HWND control,HDC dc) {
    wm_theme_child_background(control,dc);RECT r;GetClientRect(control,&r);
    if((GetWindowLongPtrW(control,GWL_STYLE)&SS_TYPEMASK)==SS_ICON) {
        HICON icon=(HICON)SendMessageW(control,STM_GETICON,0,0);
        if(icon)DrawIconEx(dc,0,0,icon,r.right,r.bottom,0,NULL,DI_NORMAL);return;
    }
    wchar_t text[2048];GetWindowTextW(control,text,2048);
    HFONT font=(HFONT)SendMessageW(control,WM_GETFONT,0,0);SelectObject(dc,font);SetBkMode(dc,TRANSPARENT);SetTextColor(dc,GetPropW(control,L"warmMuted")?RGB(107,116,129):RGB(26,35,48));
    if(GetPropW(control,L"warmFooter")) {
        unsigned connected=0,running=0,abnormal=0;
        swscanf(text,L"● 已连接 %u 台 · 运行中 %u 台 · 异常 %u 台",&connected,&running,&abnormal);
        int size=scale(16),cy=r.bottom/2;HBRUSH green=CreateSolidBrush(RGB(0,169,79));HGDIOBJ old=SelectObject(dc,green);HPEN pen=CreatePen(PS_SOLID,1,RGB(0,169,79));HGDIOBJ op=SelectObject(dc,pen);Ellipse(dc,0,cy-size/2,size,cy+size/2);SelectObject(dc,op);SelectObject(dc,old);DeleteObject(pen);DeleteObject(green);
        wchar_t numbers[3][32];swprintf(numbers[0],32,L"%u",connected);swprintf(numbers[1],32,L"%u",running);swprintf(numbers[2],32,L"%u",abnormal);
        const wchar_t *parts[]={L"已连接 ",numbers[0],L" 台  ·  运行中 ",numbers[1],L" 台  ·  异常 ",numbers[2],L" 台"};
        int x=size+scale(20);
        for(unsigned i=0;i<7;++i){SIZE extent;GetTextExtentPoint32W(dc,parts[i],(int)wcslen(parts[i]),&extent);RECT area={x,0,x+extent.cx,r.bottom};SetTextColor(dc,i==1||i==3?RGB(0,158,72):i==5?RGB(218,60,64):RGB(28,39,55));DrawTextW(dc,parts[i],-1,&area,DT_SINGLELINE|DT_VCENTER);x+=extent.cx;}
        return;
    }
    if(GetPropW(control,L"warmTarget")){wm_theme_round(dc,0,0,r.right,r.bottom,18,0xD7E0F0FF,0x99FFFFFF);SetTextColor(dc,RGB(0,113,233));r.left+=scale(12);}
    if(GetPropW(control,L"warmPath")){wm_theme_round(dc,0,0,r.right,r.bottom,9,0xFFFFFFFF,0xFFDDE2E8);r.left+=scale(9);}
    if(GetPropW(control,L"warmMetric")) {
        wm_theme_round(dc,0,0,r.right,r.bottom,15,0xFFFFFFFF,0xBAFFFFFF);
        wchar_t *newline=wcschr(text,L'\n');
        if(newline){*newline++=0;RECT label={scale(12),scale(6),r.right-scale(8),r.bottom/2};DrawTextW(dc,text,-1,&label,DT_SINGLELINE|DT_VCENTER|DT_END_ELLIPSIS);
            RECT value={scale(12),r.bottom/2,r.right-scale(8),r.bottom-scale(5)};DrawTextW(dc,newline,-1,&value,DT_SINGLELINE|DT_VCENTER|DT_END_ELLIPSIS);}
        return;
    }
    if(GetPropW(control,L"warmStatus")) {r.left+=scale(28);wm_theme_symbol(dc,1,scale(2),(r.bottom-scale(20))/2,scale(20),RGB(0,122,255));}
    int symbol=(int)(INT_PTR)GetPropW(control,L"warmSymbol");
    if(symbol){wm_theme_symbol(dc,symbol,scale(1),(r.bottom-scale(22))/2,scale(22),RGB(35,50,68));r.left+=scale(32);}
    DrawTextW(dc,text,-1,&r,DT_SINGLELINE|DT_VCENTER|DT_END_ELLIPSIS|DT_NOPREFIX);
}
static void paint_combo(HWND control,HDC dc) {
    wm_theme_child_background(control,dc);RECT r;GetClientRect(control,&r);
    GpGraphics *graphics=NULL;GdipCreateFromHDC(dc,&graphics);
    if(graphics) {
        GdipSetSmoothingMode(graphics,SmoothingModeAntiAlias);
        rounded(graphics,0,0,(float)r.right,(float)r.bottom,(float)scale(8),0xFFFFFFFF,0xFFDEE1E7);
        GpPen *pen=NULL;GdipCreatePen1(0xFF6E7480,1.6f,UnitPixel,&pen);
        if(pen) {
            float x=(float)(r.right-scale(18)),y=(float)r.bottom/2;
            GdipDrawLine(graphics,pen,x-scale(4),y-scale(2),x,y+scale(2));
            GdipDrawLine(graphics,pen,x,y+scale(2),x+scale(4),y-scale(2));GdipDeletePen(pen);
        }
        GdipDeleteGraphics(graphics);
    }
    if((GetWindowLongPtrW(control,GWL_STYLE)&3)==CBS_DROPDOWN)return;
    wchar_t text[256]=L"";LRESULT index=SendMessageW(control,CB_GETCURSEL,0,0);
    if(index>=0)SendMessageW(control,CB_GETLBTEXT,index,(LPARAM)text);
    SelectObject(dc,(HFONT)SendMessageW(control,WM_GETFONT,0,0));SetBkMode(dc,TRANSPARENT);SetTextColor(dc,RGB(43,43,48));
    r.left+=scale(10);r.right-=scale(32);DrawTextW(dc,text,-1,&r,DT_SINGLELINE|DT_VCENTER|DT_END_ELLIPSIS);
}
static LRESULT CALLBACK themed_control(HWND control,UINT message,WPARAM w,LPARAM l,UINT_PTR id,DWORD_PTR data) {
    (void)id;struct control_theme *state=(struct control_theme*)data;
    if(message==WM_NCDESTROY){RemoveWindowSubclass(control,themed_control,1);free(state->text);free(state);return DefSubclassProc(control,message,w,l);}
    if(state->role==WM_THEME_LABEL&&(GetWindowLongPtrW(control,GWL_STYLE)&SS_TYPEMASK)!=SS_ICON) {
        if(message==WM_SETTEXT){const wchar_t *input=(const wchar_t*)l;if(!input)input=L"";size_t length=wcslen(input);wchar_t *copy=malloc((length+1)*sizeof(wchar_t));
            if(!copy)return FALSE;memcpy(copy,input,(length+1)*sizeof(wchar_t));free(state->text);state->text=copy;InvalidateRect(control,NULL,FALSE);return TRUE;}
        if(message==WM_GETTEXTLENGTH)return state->text?(LRESULT)wcslen(state->text):0;
        if(message==WM_GETTEXT){if(!w||!l)return 0;size_t length=state->text?wcslen(state->text):0;if(length>=(size_t)w)length=(size_t)w-1;
            if(length)memcpy((void*)l,state->text,length*sizeof(wchar_t));((wchar_t*)l)[length]=0;return (LRESULT)length;}
    }
    if(message==WM_MOUSEMOVE&&!state->hover){state->hover=true;TRACKMOUSEEVENT track={sizeof(track),TME_LEAVE,control,0};TrackMouseEvent(&track);InvalidateRect(control,NULL,FALSE);}
    if(message==WM_MOUSELEAVE){state->hover=false;InvalidateRect(control,NULL,FALSE);}
    if((state->role==WM_THEME_LABEL||state->role==WM_THEME_TOGGLE||state->role==WM_THEME_COMBO)&&(message==WM_PAINT||message==WM_PRINTCLIENT)) {
        PAINTSTRUCT paint;HDC dc=message==WM_PAINT?BeginPaint(control,&paint):(HDC)w;
        if(state->role==WM_THEME_LABEL){RECT r;GetClientRect(control,&r);HDC mem=CreateCompatibleDC(dc);HBITMAP bitmap=CreateCompatibleBitmap(dc,r.right>0?r.right:1,r.bottom>0?r.bottom:1);HGDIOBJ old=SelectObject(mem,bitmap);
            paint_label(control,mem);BitBlt(dc,0,0,r.right,r.bottom,mem,0,0,SRCCOPY);SelectObject(mem,old);DeleteObject(bitmap);DeleteDC(mem);}
        else if(state->role==WM_THEME_TOGGLE)paint_toggle(control,dc);else paint_combo(control,dc);
        if(message==WM_PAINT)EndPaint(control,&paint);return 0;
    }
    if(message==WM_ERASEBKGND&&(state->role!=WM_THEME_INPUT)){wm_theme_child_background(control,(HDC)w);return 1;}
    LRESULT result=DefSubclassProc(control,message,w,l);
    if(message==BM_SETCHECK||message==WM_ENABLE||message==WM_SETFOCUS||message==WM_KILLFOCUS||message==WM_LBUTTONUP||message==WM_KEYUP)
        InvalidateRect(control,NULL,FALSE);
    if((state->role==WM_THEME_INPUT||state->role==WM_THEME_COMBO)&&(message==WM_SIZE||message==WM_STYLECHANGED)) {
        RECT r;GetWindowRect(control,&r);SetWindowRgn(control,CreateRoundRectRgn(0,0,r.right-r.left+1,r.bottom-r.top+1,scale(14),scale(14)),TRUE);
    }
    return result;
}
void wm_theme_attach(HWND control,enum wm_theme_role role) {
    if(!control)return;struct control_theme *state=calloc(1,sizeof(*state));if(!state)return;
    state->role=role;
    if(role==WM_THEME_LABEL){int length=GetWindowTextLengthW(control);state->text=calloc((size_t)length+1,sizeof(wchar_t));if(state->text)GetWindowTextW(control,state->text,length+1);}
    if(!SetWindowSubclass(control,themed_control,1,(DWORD_PTR)state)){free(state->text);free(state);}
    if(role==WM_THEME_INPUT){SendMessageW(control,EM_SETMARGINS,EC_LEFTMARGIN|EC_RIGHTMARGIN,MAKELPARAM(scale(10),scale(10)));}
}
void wm_theme_draw_button(const DRAWITEMSTRUCT *d,bool primary,bool danger) {
    wm_theme_child_background(d->hwndItem,d->hDC);
    if(GetPropW(d->hwndItem,L"warmDrop")){
        RECT r=d->rcItem;bool active=GetPropW(d->hwndItem,L"warmDragActive")!=NULL;
        wm_theme_round(d->hDC,1,1,r.right-2,r.bottom-2,15,active?0xE3D9EDFF:0xC0EFF7FF,0);
        HPEN pen=CreatePen(PS_DASH,1,RGB(0,122,255));HGDIOBJ old=SelectObject(d->hDC,pen),brush=SelectObject(d->hDC,GetStockObject(NULL_BRUSH));SetBkMode(d->hDC,TRANSPARENT);
        RoundRect(d->hDC,1,1,r.right-2,r.bottom-2,scale(22),scale(22));SelectObject(d->hDC,old);SelectObject(d->hDC,brush);DeleteObject(pen);
        int icon=scale(52);wm_theme_symbol(d->hDC,26,(r.right-icon)/2,scale(27),icon,RGB(0,132,255));
        HFONT font=(HFONT)SendMessageW(d->hwndItem,WM_GETFONT,0,0);LOGFONTW lf;GetObjectW(font,sizeof(lf),&lf);lf.lfWeight=FW_BOLD;lf.lfHeight=lf.lfHeight*4/3;HFONT heading=CreateFontIndirectW(&lf);SelectObject(d->hDC,heading);
        RECT title={scale(14),scale(94),r.right-scale(14),scale(131)};SetTextColor(d->hDC,RGB(29,43,66));DrawTextW(d->hDC,active?L"松开后传到当前手机":L"把文件拖到这里",-1,&title,DT_SINGLELINE|DT_CENTER|DT_VCENTER);
        SelectObject(d->hDC,font);DeleteObject(heading);RECT hint={scale(12),scale(136),r.right-scale(12),scale(164)};SetTextColor(d->hDC,RGB(111,128,149));DrawTextW(d->hDC,L"支持图片、视频、文档及其他文件",-1,&hint,DT_SINGLELINE|DT_CENTER|DT_VCENTER);return;
    }
    RECT r=d->rcItem;bool down=(d->itemState&ODS_SELECTED)!=0,enabled=(d->itemState&ODS_DISABLED)==0;
    struct control_theme *state=NULL;DWORD_PTR data;
    if(GetWindowSubclass(d->hwndItem,themed_control,1,&data))state=(struct control_theme*)data;
    bool hover=state&&state->hover;
    ARGB fill=primary?(down?0xFF0063D9:hover?0xFF248CFF:0xFF007AFF):(down?0xE5E6E9EF:hover?0xF5FFFFFF:0xFFFFFFFF);
    bool sponsor=GetPropW(d->hwndItem,L"warmSponsor")!=NULL;
    if(sponsor)fill=0x8FFFF1E8;
    if(!enabled)fill=0xFFE8ECF1;
    GpGraphics *graphics=NULL;GdipCreateFromHDC(d->hDC,&graphics);
    if(graphics){GdipSetSmoothingMode(graphics,SmoothingModeAntiAlias);
        rounded(graphics,1,1,(float)(r.right-r.left-2),(float)(r.bottom-r.top-2),(float)scale(11),fill,sponsor?0xFFFFB1A0:primary?0:0xFFDFE2E7);
        GdipDeleteGraphics(graphics);}
    SetBkMode(d->hDC,TRANSPARENT);SetTextColor(d->hDC,!enabled?RGB(155,155,163):primary?RGB(255,255,255):sponsor?RGB(165,73,38):danger?RGB(210,65,57):RGB(40,60,90));
    HFONT font=(HFONT)SendMessageW(d->hwndItem,WM_GETFONT,0,0);SelectObject(d->hDC,font);
    wchar_t text[256];GetWindowTextW(d->hwndItem,text,256);
    int symbol=(int)(INT_PTR)GetPropW(d->hwndItem,L"warmSymbol");if(sponsor)symbol=12;
    if(symbol&&!text[0]){int icon=scale(20);wm_theme_symbol(d->hDC,symbol,(r.right-icon)/2,(r.bottom-icon)/2,icon,danger?RGB(220,60,55):RGB(35,50,68));}
    else if(symbol){SIZE size;GetTextExtentPoint32W(d->hDC,text,(int)wcslen(text),&size);int gap=scale(9),icon=scale(20),total=size.cx+gap+icon,x=(r.right-total)/2;if(x<scale(8))x=scale(8);
        wm_theme_symbol(d->hDC,symbol,x,(r.bottom-icon)/2,icon,primary?RGB(255,255,255):sponsor||danger?RGB(230,60,55):RGB(37,55,76));r.left=x+icon+gap;
        DrawTextW(d->hDC,text,-1,&r,DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS|DT_NOPREFIX);
    }else DrawTextW(d->hDC,text,-1,&r,DT_CENTER|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS|DT_NOPREFIX);
    if((d->itemState&ODS_FOCUS)&&!(d->itemState&ODS_NOFOCUSRECT)){
        InflateRect(&r,-scale(4),-scale(4));DrawFocusRect(d->hDC,&r);
    }
}
bool wm_theme_choose_wallpaper(void) {
    wchar_t path[THEME_PATH]=L"";
    OPENFILENAMEW file={0};file.lStructSize=sizeof(file);file.hwndOwner=theme.parent;
    file.lpstrFilter=L"图片（PNG / JPG / BMP）\0*.png;*.jpg;*.jpeg;*.bmp\0所有文件\0*.*\0\0";
    file.lpstrFile=path;file.nMaxFile=THEME_PATH;file.lpstrTitle=L"选择你的背景壁纸";
    file.Flags=OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_NOCHANGEDIR|OFN_EXPLORER;
    if(!GetOpenFileNameW(&file))return false;
    if(!load_wallpaper(path)){MessageBoxW(theme.parent,L"这张图片无法读取。请选择 PNG、JPG 或 BMP，文件小于 32 MiB。",L"更换壁纸",MB_OK|MB_ICONWARNING);return false;}
    // New appearance files are UTF-16, preserving Chinese paths even on an
    // English Windows installation whose ANSI code page cannot represent them.
    HANDLE settings=CreateFileW(theme.ini,GENERIC_WRITE,0,NULL,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,NULL);
    if(settings!=INVALID_HANDLE_VALUE){WCHAR bom=0xFEFF;DWORD written;WriteFile(settings,&bom,sizeof(bom),&written,NULL);CloseHandle(settings);}
    WritePrivateProfileStringW(L"theme",L"wallpaper",path,theme.ini);rebuild();
    RedrawWindow(theme.parent,NULL,NULL,RDW_INVALIDATE|RDW_ERASE|RDW_ALLCHILDREN);return true;
}
HBRUSH wm_theme_input_brush(bool disabled){return disabled?theme.disabled_input:theme.input;}
COLORREF wm_theme_text_color(void){return RGB(43,43,48);}
unsigned wm_theme_generation(void){return theme.generation;}
#ifdef MANAGER_SMOKE_TEST
bool wm_theme_test_wallpaper(const wchar_t *path){
    if(!path){if(theme.wallpaper)GdipDisposeImage((GpImage*)theme.wallpaper);theme.wallpaper=NULL;theme.matte=RGB(244,247,251);rebuild();return true;}
    bool ok=load_wallpaper(path);if(ok)rebuild();return ok;
}
#endif
