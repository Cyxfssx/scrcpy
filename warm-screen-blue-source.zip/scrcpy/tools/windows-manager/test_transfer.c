#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include "transfer.h"
static bool raw(SOCKET s,void *buffer,size_t count,bool write){char *p=buffer;while(count){int n=write?send(s,p,(int)count,0):recv(s,p,(int)count,0);if(n<=0)return false;p+=n;count-=(size_t)n;}return true;}
static bool service(SOCKET s,const char *value){char header[5],reply[4];snprintf(header,5,"%04x",(unsigned)strlen(value));return raw(s,header,4,true)&&raw(s,(void*)value,strlen(value),true)&&raw(s,reply,4,false)&&!memcmp(reply,"OKAY",4);}
static int bridge(int argc,wchar_t **argv){if(argc!=5||wcscmp(argv[3],L"shell"))return 91;WSADATA wsa;if(WSAStartup(MAKEWORD(2,2),&wsa))return 92;
    SOCKET s=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);struct sockaddr_in address={0};address.sin_family=AF_INET;address.sin_port=htons(55107);address.sin_addr.s_addr=htonl(INADDR_LOOPBACK);
    int result=93;if(connect(s,(struct sockaddr*)&address,sizeof(address)))goto done;
    char serial[512],script[32768],request[33000];WideCharToMultiByte(CP_UTF8,0,argv[2],-1,serial,sizeof(serial),NULL,NULL);WideCharToMultiByte(CP_UTF8,0,argv[4],-1,script,sizeof(script),NULL,NULL);
    snprintf(request,sizeof(request),"host:transport:%s",serial);if(!service(s,request))goto done;snprintf(request,sizeof(request),"shell:%s",script);if(!service(s,request))goto done;char exit;if(raw(s,&exit,1,false)&&exit=='0')result=0;
done:closesocket(s);WSACleanup();return result;
}
static bool make_file(const wchar_t *path,unsigned size,unsigned seed){HANDLE f=CreateFileW(path,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,0,NULL);if(f==INVALID_HANDLE_VALUE)return false;unsigned char block[4096];for(unsigned i=0;i<sizeof(block);++i)block[i]=(unsigned char)(i+seed);bool ok=true;while(size){DWORD count=size>sizeof(block)?sizeof(block):size,written;if(!WriteFile(f,block,count,&written,NULL)||written!=count){ok=false;break;}size-=count;}CloseHandle(f);return ok;}
static struct wt_task *get_task(struct wt_context *c,unsigned id,struct wt_task *all){size_t count=wt_snapshot(c,all,WT_CAPACITY);for(size_t i=0;i<count;++i)if(all[i].id==id)return &all[i];return NULL;}
int wmain(int argc,wchar_t **argv){if(argc>1&&!wcscmp(argv[1],L"-s"))return bridge(argc,argv);
    wchar_t self[2048],dir[2048],file[2048],other[2048],helper[2048],error[256];GetModuleFileNameW(NULL,self,2048);wcscpy(dir,self);*wcsrchr(dir,L'\\')=0;
    swprintf(file,2048,L"%ls\\中文 `x$(no)'name.png",dir);swprintf(helper,2048,L"%ls\\helper.bin",dir);swprintf(other,2048,L"%ls\\second",dir);CreateDirectoryW(other,NULL);
    if(!make_file(file,150000,7)||!make_file(helper,1024,21))return 1;
    struct wt_context *c=wt_create(self,helper,55107);if(!c)return 2;struct wt_task *all=calloc(WT_CAPACITY,sizeof(*all));if(!all)return 3;
    if(wt_remote_valid(L"/sdcard/../private")||wt_remote_valid(L"/data/local/tmp")||!wt_remote_valid(L"/sdcard/Download/中文 空格")||!wt_is_image(file))return 4;
    if(!wt_enqueue(c,file,L"phone-A",L"客服 01",L"/sdcard/Download/温暖投屏",42,false,error,256))return 5;
    wchar_t duplicate[2048];swprintf(duplicate,2048,L"%ls\\second\\中文 `x$(no)'name.png",dir);if(!make_file(duplicate,333,11)||!wt_enqueue(c,duplicate,L"phone-A",L"客服 01",L"/sdcard/Download/温暖投屏",42,false,error,256))return 6;
    swprintf(other,2048,L"%ls\\资料.pdf",dir);if(!make_file(other,1000000,19)||!wt_enqueue(c,other,L"phone-B",L"客服 02",L"/sdcard/Documents/温暖投屏",43,false,error,256))return 7;
    wchar_t empty[2048];swprintf(empty,2048,L"%ls\\empty.apk",dir);if(!make_file(empty,0,0)||!wt_enqueue(c,empty,L"phone-A",L"客服 01",L"/sdcard/Download/温暖投屏",44,false,error,256))return 8;
    if(!wt_enqueue(c,file,L"bad-device",L"异常手机",L"/sdcard/Download/温暖投屏",45,false,error,256))return 9;
    wchar_t slow[2048];swprintf(slow,2048,L"%ls\\large.bin",dir);if(!make_file(slow,8000000,29)||!wt_enqueue(c,slow,L"slow",L"慢速手机",L"/sdcard/Download/温暖投屏",46,false,error,256))return 10;
    if(!wt_enqueue(c,file,L"phone-B",L"客服 02",L"/sdcard/Download/温暖投屏",47,false,error,256))return 11;wt_cancel(c,7);
    if(!wt_enqueue(c,file,L"phone-A",L"客服 01",L"/sdcard/Pictures/温暖投屏",48,true,error,256)||!wt_enqueue(c,file,L"media-fail",L"索引失败",L"/sdcard/Download/温暖投屏",49,true,error,256))return 12;
    if(!wt_enqueue(c,other,L"disconnect",L"掉线手机",L"/sdcard/Download/温暖投屏",50,false,error,256))return 13;
    if(wt_enqueue(c,dir,L"phone-A",L"客服",L"/sdcard/Download/温暖投屏",51,false,error,256))return 14;
    ULONGLONG deadline=GetTickCount64()+20000;bool sent_cancel=false;
    while(wt_busy(c)&&GetTickCount64()<deadline){struct wt_task *task=get_task(c,6,all);if(task&&task->state==WT_ACTIVE&&task->sent>=65536&&!sent_cancel){wt_cancel(c,6);sent_cancel=true;}Sleep(20);}
    if(wt_busy(c)||!sent_cancel)return 15;
    const enum wt_state expected[]={WT_DONE,WT_DONE,WT_DONE,WT_DONE,WT_FAILED,WT_CANCELLED,WT_CANCELLED,WT_DONE,WT_SAVED,WT_FAILED};
    for(unsigned i=0;i<10;++i){struct wt_task *task=get_task(c,i+1,all);if(!task||task->state!=expected[i]){fwprintf(stderr,L"Task %u: state %d expected %d detail %ls\n",i+1,task?task->state:-1,expected[i],task?task->detail:L"missing");return 20+(int)i;}}
    struct wt_task *a=get_task(c,1,all);wchar_t remote_a[WT_REMOTE];wcscpy(remote_a,a->remote);struct wt_task *b=get_task(c,2,all);if(!wcscmp(remote_a,b->remote))return 31;
    wt_clear_completed(c);if(wt_snapshot(c,all,WT_CAPACITY))return 32;
    if(!wt_enqueue(c,slow,L"slow",L"关闭测试",L"/sdcard/Download/温暖投屏",52,false,error,256))return 33;
    Sleep(250);ULONGLONG started=GetTickCount64();wt_destroy(c);if(GetTickCount64()-started>4000)return 34;
    DeleteFileW(file);DeleteFileW(duplicate);DeleteFileW(other);DeleteFileW(empty);DeleteFileW(slow);DeleteFileW(helper);
    swprintf(other,2048,L"%ls\\second",dir);RemoveDirectoryW(other);free(all);puts("Transfer integration tests passed.");return 0;
}
