#define COBJMACROS
#ifndef UNICODE
#define UNICODE
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <ole2.h>
#include <shellapi.h>
#include <shlobj.h>
#include <stdio.h>
#include <stdlib.h>
#include "drop.h"
extern DWORD wd_test_dispatch(HWND window,IDataObject *data,bool cancel);
struct fake {IDataObject iface;LONG refs;HGLOBAL files;bool valid;};
static HRESULT STDMETHODCALLTYPE query(IDataObject *self,REFIID iid,void **out){*out=NULL;if(IsEqualIID(iid,&IID_IUnknown)||IsEqualIID(iid,&IID_IDataObject)){*out=self;IDataObject_AddRef(self);return S_OK;}return E_NOINTERFACE;}
static ULONG STDMETHODCALLTYPE add(IDataObject *self){return (ULONG)InterlockedIncrement(&((struct fake*)self)->refs);}
static ULONG STDMETHODCALLTYPE release(IDataObject *self){return (ULONG)InterlockedDecrement(&((struct fake*)self)->refs);}
static HRESULT STDMETHODCALLTYPE query_data(IDataObject *self,FORMATETC *format){return ((struct fake*)self)->valid&&format->cfFormat==CF_HDROP&&(format->tymed&TYMED_HGLOBAL)?S_OK:DV_E_FORMATETC;}
static HRESULT STDMETHODCALLTYPE get(IDataObject *self,FORMATETC *format,STGMEDIUM *out){if(FAILED(query_data(self,format)))return DV_E_FORMATETC;struct fake *f=(struct fake*)self;SIZE_T n=GlobalSize(f->files);out->tymed=TYMED_HGLOBAL;out->pUnkForRelease=NULL;out->hGlobal=GlobalAlloc(GHND,n);if(!out->hGlobal)return E_OUTOFMEMORY;void *src=GlobalLock(f->files),*dst=GlobalLock(out->hGlobal);memcpy(dst,src,n);GlobalUnlock(out->hGlobal);GlobalUnlock(f->files);return S_OK;}
static HRESULT STDMETHODCALLTYPE get_here(IDataObject *s,FORMATETC *f,STGMEDIUM *m){(void)s;(void)f;(void)m;return E_NOTIMPL;}
static HRESULT STDMETHODCALLTYPE canonical(IDataObject *s,FORMATETC *a,FORMATETC *b){(void)s;(void)a;(void)b;return E_NOTIMPL;}
static HRESULT STDMETHODCALLTYPE set(IDataObject *s,FORMATETC *f,STGMEDIUM *m,BOOL b){(void)s;(void)f;(void)m;(void)b;return E_NOTIMPL;}
static HRESULT STDMETHODCALLTYPE enumeration(IDataObject *s,DWORD dir,IEnumFORMATETC **out){(void)s;(void)dir;*out=NULL;return E_NOTIMPL;}
static HRESULT STDMETHODCALLTYPE advise(IDataObject *s,FORMATETC *f,DWORD flags,IAdviseSink *a,DWORD *connection){(void)s;(void)f;(void)flags;(void)a;(void)connection;return OLE_E_ADVISENOTSUPPORTED;}
static HRESULT STDMETHODCALLTYPE unadvise(IDataObject *s,DWORD connection){(void)s;(void)connection;return OLE_E_ADVISENOTSUPPORTED;}
static HRESULT STDMETHODCALLTYPE enum_advise(IDataObject *s,IEnumSTATDATA **out){(void)s;*out=NULL;return OLE_E_ADVISENOTSUPPORTED;}
static IDataObjectVtbl methods={query,add,release,get,get_here,query_data,canonical,set,enumeration,advise,unadvise,enum_advise};
static bool available=true;static unsigned drops=0,enters=0,leaves=0;static bool names_ok=false;
static bool ready(void *p){(void)p;return available;}
static void hover(void *p,bool active){(void)p;if(active)++enters;else ++leaves;}
static void files(void *p,HDROP drop){(void)p;++drops;wchar_t path[256];names_ok=DragQueryFileW(drop,0xffffffff,NULL,0)==2;DragQueryFileW(drop,0,path,256);names_ok=names_ok&&!wcscmp(path,L"C:\\测试\\图片.png");}
int wmain(void){if(FAILED(OleInitialize(NULL)))return 1;HWND window=CreateWindowW(L"STATIC",L"drop test",WS_OVERLAPPED,0,0,300,200,NULL,NULL,GetModuleHandleW(NULL),NULL);if(!window){fprintf(stderr,"CreateWindow failed %lu\n",GetLastError());return 2;}if(!wd_register(window,ready,files,hover,NULL))return 2;
    const wchar_t paths[]=L"C:\\测试\\图片.png\0C:\\文档.pdf\0";struct fake data={0};data.iface.lpVtbl=&methods;data.refs=1;data.valid=true;data.files=GlobalAlloc(GHND,sizeof(DROPFILES)+sizeof(paths));DROPFILES *header=GlobalLock(data.files);header->pFiles=sizeof(DROPFILES);header->fWide=TRUE;memcpy((char*)header+sizeof(DROPFILES),paths,sizeof(paths));GlobalUnlock(data.files);
    const wchar_t sentinel[]=L"COPY-UNCHANGED";HGLOBAL clip=GlobalAlloc(GHND,sizeof(sentinel));void *text=GlobalLock(clip);memcpy(text,sentinel,sizeof(sentinel));GlobalUnlock(clip);if(!OpenClipboard(window))return 3;EmptyClipboard();SetClipboardData(CF_UNICODETEXT,clip);CloseClipboard();
    if(wd_test_dispatch(window,&data.iface,false)!=DROPEFFECT_COPY||drops!=1||!names_ok||enters!=1||leaves!=1)return 4;
    available=false;if(wd_test_dispatch(window,&data.iface,false)!=DROPEFFECT_NONE||drops!=1)return 5;
    available=true;data.valid=false;if(wd_test_dispatch(window,&data.iface,false)!=DROPEFFECT_NONE||drops!=1)return 6;
    data.valid=true;wd_test_dispatch(window,&data.iface,true);if(drops!=1)return 7;
    if(!OpenClipboard(window))return 8;HANDLE handle=GetClipboardData(CF_UNICODETEXT);const wchar_t *actual=GlobalLock(handle);bool same=actual&&!wcscmp(actual,sentinel);if(actual)GlobalUnlock(handle);CloseClipboard();if(!same)return 9;
    wd_revoke(window);DestroyWindow(window);if(data.refs!=1)return 10;GlobalFree(data.files);OleUninitialize();puts("OLE file drag, readiness, hover/cancel and clipboard preservation tests passed.");return 0;
}
