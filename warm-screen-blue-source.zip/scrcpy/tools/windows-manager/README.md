# Current blue/white full bundle (preview.10)

The current panel uses solid blue/white cards and no wallpaper, translucency or blur.
It does not load saved wallpaper paths. Resolution, FPS, bitrate and hardware decoder
are selection-only dropdowns. Compatible saved custom values are added as selectable
items, so old configurations are not silently rounded. Apply-to-current updates only
the selected authorized phone; apply-to-all updates all authorized connected phones,
regardless of checkboxes. Running sessions restart normally (finishing recordings);
stopped sessions only save their new parameters. Offline/unauthorized phones are skipped.

Ctrl+V image handling uses the updated independent bridge and shell helper. It uploads
only /data/local/tmp/warm-image-TOKEN.tmp, passes a copy to the existing Warm IME private
provider, then removes the transport file. There is no clipboard gallery scan or public
storage route, including failures. The existing Android APK and mirroring core are unchanged.
Phone private cache remains until manual cleanup in Warm IME; an accepted commitContent
request is not proof of visible preview or successful delivery. No send action is invoked.

Explicit file drag-and-drop remains a separate save-file operation; its gallery checkbox
is off by default for new phones. It does not affect clipboard image input.

The notes below document the retained legacy features and prior implementation details;
the current behavior above supersedes previous frosted/glass and gallery-fallback descriptions.

# Windows multi-device manager

A native Win32 control panel for the custom scrcpy client. It uses Windows
system controls and one scrcpy process per selected phone; no browser, Python,
.NET, or Qt runtime is required on the user's computer.

The left panel lists ADB devices and supports start all, start/stop checked,
stop all, tile windows, focus a selected window, and per-session log viewing.
The right panel configures the maximum video size, maximum FPS, bitrate,
hardware decoder, audio, recording, video buffering, always-on-top and
borderless windows. Defaults: 1280, 30 FPS, 2 Mbps, auto hardware decoding,
audio off, recording off, and zero extra video buffering.

Turning off a size limit uses the original resolution. Turning off a frame-rate
limit uses unlimited FPS. These switches remove limits; they do not turn off
video. Settings apply when launching a phone. Applying to already running
checked devices closes those sessions normally, finalizes their recording,
then starts new sessions with the chosen parameters. Recording files have
unique names and use MKV. Stop does not forcibly terminate a recording.

Host IME text uses the existing `--text-via-clipboard` setting. The existing
preview.6 paired client/server and DLLs are preserved byte-for-byte. Its built-in
image route is disabled with `--no-clipboard-images`; the independent
modules/ClipboardBridge.exe manages image Ctrl+V for registered phone windows.
It attempts the separately installed Warm IME standard image API, with the
existing gallery fallback. No chat message or image is automatically sent.
Native file drag-and-drop uses an independent task queue and does not intercept
text clipboard input. Default window size is 1200 x 760 at 96 DPI, capped to
the desktop work area; no APK or separate patch installation is required on PC.

## Package layout

```
Manager.exe
engine/             # scrcpy.exe, adb.exe, matching DLLs, custom server, icons
logs/               # created on launch, unique file per device/session
recordings/         # created if recording is requested
manager-settings.ini # last launched profile; generated locally
```

The manager can also run with the engine files beside Manager.exe for developer
use. Keep the entire package together, in a writable folder. It manages its own
launched sessions only, supports up to 32 discovered devices per run, and queues
launches about 400–500 ms apart. Unauthorized/offline devices are not started.
Existing sessions are not duplicated on repeated start commands. A user can
choose to leave phone windows open when closing the manager; those retained
windows are not adopted automatically when reopening the manager.

`Manager.exe` uses the Windows GUI subsystem. Explicit inherited log/pipe
handles plus `CREATE_NO_WINDOW` hide console children. The paired scrcpy client
also uses `CREATE_NO_WINDOW` for its ADB helpers so image transfers do not open
additional console windows. UI errors and device exits are visible through the
status/list and per-session logs.

## Build and validation

From the repository root, with an x86_64 MinGW GCC toolchain on PATH:

```bash
bash tools/windows-manager/build.sh /absolute/output/directory
```

The normal executable is `Manager.exe`. `Manager-smoke.exe` is test-only and
must not be shipped to users. It creates simulated phone processes only in a
build made with `MANAGER_SMOKE_TEST`.

Portable argument/profile/parser tests:

```bash
gcc -std=c11 -Wall -Wextra -Werror -fsanitize=address,undefined \
  tools/windows-manager/model.c tools/windows-manager/test_model.c \
  -o /tmp/manager-model-tests
/tmp/manager-model-tests
```

Windows smoke test (on Windows or under Wine with a desktop):

```text
Manager-smoke.exe --self-test
```

This checks default controls, disabling limits, audio/record switches, hidden
child process output capture, device parsing, prevention of duplicate launches,
ten independent simulated windows and graceful shutdown. It saves a screenshot
and test logs next to the test executable. It does not validate ten real Android
devices, hardware-decoder capacity, actual recordings, Sogou integration or
Samsung gallery indexing. Those require the user's Windows/phone hardware.

The existing scrcpy debug test suite remains available through Meson.

## Frosted glass appearance

The native GDI+ skin draws rounded translucent cards, blue primary buttons,
iOS-style switches, and rounded inputs. The background and frost are cached;
normal device/status updates do not rebuild the blur. Only a wallpaper change,
window resize, or DPI change rebuilds the backdrop. This is a static wallpaper
material, not a continuous desktop-blur shader or web view.

Use the upper-right **更换壁纸** button to choose PNG, JPG or BMP. The entire image
is fitted without cropping; empty side margins use its opaque corner color (or
cream for transparency). Images are loaded once into an independent bitmap,
limited to a 2048-pixel longest side for retained bitmap memory, and the original
file is released. File size is limited to 32 MiB and source size to 64 megapixels
and 16384 pixels per side. This does not change the source image file.

The selected absolute path is stored in a new UTF-16 `appearance.ini`, keeping
Chinese filenames valid on English Windows. Existing `manager-settings.ini`
profile data is independent. A root `wallpaper.png` or `wallpaper.jpg` is used
as a portable default when no saved wallpaper path is usable.

The package now bundles an AI-generated cream lucky-cat wallpaper matching the
approved UI concept. It is not the user's original inline illustration. Use
**更换壁纸** to select any local original image. The bundled artwork is in
`assets/wallpaper.png`; distributing the source archive includes this asset.

The UI smoke test additionally checks real automatic-switch clicks, disabled
fields, bitmap wallpaper decoding, releasing the source file lock, and keeping
the backdrop generation count stable while ten simulated sessions run.

## Workbench UI and device recovery

The three-column native UI provides a searchable device list with state badges
and per-row start, focus, stop, or reconnect actions. Selection and batch
checkboxes are independent. **启动此设备** affects only the selected device;
**启动所选** applies visible editor settings to all checked ready devices;
**全部启动** retains each other device's saved profile and uses editor settings
for the selected device. **保存配置** saves the selected device and last defaults;
**应用到勾选设备** gracefully restarts checked ready devices using editor settings.

Devices can be renamed using **命名** then **保存名**. Unicode aliases, per-serial
profiles and normal window positions/sizes are stored in a UTF-16 INI. Previous
ASCII settings files are upgraded in place. Window geometry is restored only
if its monitor is present and the remember-position switch is on.

ADB enumeration runs asynchronously every three seconds without resetting the
ADB server. The per-device reconnect action can invoke `adb -s SERIAL reconnect`
for an offline device, never `kill-server`, global `reconnect`, or `usb`.
A missing USB connection must be physically restored and authorization granted.
Only previously launched devices with an unexpected exit/nonzero code or a
known disconnection are eligible for automatic recovery. Manually closing or
stopping a session cancels recovery. Retry delays back off from 5 to 60 seconds,
with at most six attempts until an explicit start/reconnect; a session that is
stable for a minute resets the failure count. Manual reconnect also works when
automatic reconnect is disabled. Individual actions do not restart neighbours.

The CPU and memory readings sample each managed scrcpy process once per second
using GetProcessTimes and GetProcessMemoryInfo. CPU is normalized across logical
processors, as Task Manager does. Memory is the working set. FPS is the actual
render counter from `--print-fps` log lines, not the configured maximum. Unavailable
or stale values show a dash. Static scenes can legitimately report 0 FPS.

The text toggle controls `--text-via-clipboard`. Disabling it returns to scrcpy's
standard SDK keyboard behaviour; it is not a promise of alternate IME support.
The image toggle enables the selected device in the independent clipboard
bridge. The engine's built-in image route stays disabled to prevent duplicate
handling. Text clipboard synchronization retains its independent setting.

Smoke tests additionally crash a simulated phone and check that only its PID
changes, check explicit stop suppression, offline gating, manual recovery with
auto disabled, real window placement capture, search-to-device mapping,
per-device profile selection, and a round trip of Chinese aliases through an
isolated settings file. The published UI screenshot uses simulated devices and
is labelled accordingly. Production builds have no simulated device entries.

## 温暖投屏 branding and approved layout (preview 6)

The Warm Screen layout uses the approved 1586×992 design coordinate system,
with proportional control placement, a rounded frameless main window, draggable
header, native resizing, and explicit minimize/maximize/close controls. Rounded
regions also work on Windows 10, while maximized windows use a square full-work
area. Cards, row tiles, inputs, actions and switches retain rounded outlines.
Native Windows text rendering can vary by font and DPI.

The generated **暖** artwork is included as a multi-resolution Windows ICO,
used in the title area, executable resource and taskbar. The executable product
name and UI title are **温暖投屏**. Distribution starts at `温暖投屏.exe`.

The bottom action band and the status/sponsorship band are separate. Dynamic
labels keep their own text buffer and intercept WM_SETTEXT/WM_GETTEXT instead
of letting a transparent native STATIC paint over prior glyphs. Each label
paint begins with the cached background in an offscreen bitmap and blits a
complete frame; all labels use one line with ellipsis. A new screenshot/pixel
regression alternates long/short status messages 100 times and requires the
final pixels to equal a pristine render, without a full-parent redraw.

The sponsorship entry copies **@lailai995** to the Windows clipboard. No payment
link or external platform is assumed, and no message is sent. The clipboard
operation is covered by the GUI test.

Resolution, FPS and bitrate are editable dropdowns. Choose **原始** or enter 0
for original resolution; choose **不限** or enter 0 for unlimited FPS. FPS/Mbps
suffixes are accepted and the existing validation bounds remain enforced.
The ready counter in the footer counts all detected ADB entries as connected,
including an offline/unauthorized entry; abnormal entries are counted separately.
Phone launch still requires state `device`.

GUI regressions also check icon availability, a real rounded window region,
status/sponsorship bounds at normal and small sizes, and native maximize,
restore and minimize actions. Independent-phone functionality is unchanged.

## Selected-device file transfer (preview 7)

The default screen follows the approved device / operations / drag-zone layout.
Selecting a phone updates the target pill and serial. Drop one or multiple regular
files on the dedicated zone, or use the native multi-file picker. An active mirror
window is not required; the ADB device must be connected and authorized. **更多设置**
opens all prior picture, audio, recording, hardware-decoder, buffering, topmost,
borderless and per-device controls; **文件传输** returns to the transfer view.

Native OLE IDropTarget handles only CF_HDROP and returns DROPEFFECT_COPY. A
WM_DROPFILES fallback is also supported. This route never examines keyboard
Ctrl+C/Ctrl+V or changes the Windows clipboard. Unsupported drops, disconnected
phones, directories, reparse points and .lnk shortcuts are rejected. Files of any
extension are accepted, including zero-length files; APKs are copied, never
installed, opened or shared. Normal launch (not elevated above Explorer) avoids
Windows blocking drag-and-drop across privilege levels.

Each task snapshots the device serial/name, destination and gallery choice at
submission. Selection changes affect new submissions and displayed records,
not queued or active tasks. Completed-record clearing affects only the selected
device. Tasks are memory-only, capped at 128, with one background transfer worker.
A process exit cancels unfinished work; it does not resume automatically later.

`transfer.c` streams the original bytes through the existing local ADB server's
transport-selection and sync-v1 services. No image decode, recompression or full
file buffering occurs. Buffers are 64 KiB, progress updates are limited to 8 Hz,
and transfer throughput is capped at 16 MiB/s to leave USB bandwidth for mirrors.
The manager polls a generation counter, repainting the queue only on changes.
The localhost port follows ANDROID_ADB_SERVER_PORT or a localhost TCP
ADB_SERVER_SOCKET. Remote/custom non-TCP ADB sockets are not silently redirected
to a different server; the transfer controls are unavailable instead.

Destinations are selectable under `/sdcard/Download`, `Pictures`, `Documents` or
`Movies`, in a 温暖投屏 folder. A timestamped batch subfolder prevents accidental
overwrite across drops; same-name files within a batch are given an ID prefix.
The final shell command refuses to overwrite an existing path. Temporary
`.warm-part-ID` files are renamed only after sync reports success. Cancellation also interrupts synchronous source-file I/O on the dedicated worker.
Cancellation and failure attempt to remove only that task's temporary path. A physically
disconnected phone may prevent cleanup until reconnection; unfinished temporary
files can be removed in the batch folder. Source files are never deleted.

**图片同时显示到相册** launches a one-shot shell-UID `TransferScanner` from the
bundled `engine/warm-transfer-scanner` dex archive. It requests Android
MediaScannerConnection indexing and waits for a URI callback, with a 12-second
timeout. It never launches an activity or sends chat content. The helper is built
with `server/build_without_gradle.sh`, then copied under the helper filename; the
normal paired mirroring server and Windows engine remain byte-identical to
preview 6. If indexing cannot be confirmed, a **文件已保存；相册索引未确认** result
preserves the successful file and makes the limitation explicit. Device gallery
apps may filter formats or update at different times. Non-image files stay in
the selected folder; they are not promised to appear in a photo gallery.

### Scaling and resource use

Fonts and controls are laid out at their actual pixel size, never as a scaled
screenshot. DeferWindowPos batches moves. During interactive resize the backdrop
is rebuilt at the same dimensions as the controls and all children are invalidated
after layout commits. No stretched old scene is combined with new control positions.
Idle windows reuse the backdrop without a continuous render loop. Final labels use
native font rasterization at the new size. The frame, buttons and panels retain rounded corners. Original resolution
and unlimited FPS remain available in the editable dropdowns. The **均衡** preset
is now 1600/30 FPS/3 Mbps; **清晰聊天** is 1920/30 FPS/4 Mbps. This prioritizes text
resolution without enabling 60 FPS or audio unnecessarily. Saved settings are
not silently replaced. Enlarging a mirror cannot recover text detail discarded
by an earlier low-resolution encode; choose 原始 or 清晰聊天 before restarting.

### Transfer regressions

`build.sh` also creates `Transfer-test.exe` and `Drop-test.exe` (test-only).
Run on Windows or Wine with a desktop:

```text
Drop-test.exe
Manager-smoke.exe --self-test
python tools/windows-manager/tests/mock_adb.py wine /absolute/Transfer-test.exe
```

The localhost mock server binds only port 55107 and never executes incoming shell
text; it parses and models the permitted operations in memory. Tests verify
original bytes (including Unicode, quotes, backticks and dollar signs in file
names), distinct target serials, zero-length files, duplicate basenames, failed
transport, disconnect, active and queued cancellation, temporary-file cleanup,
image-index success/warning, and prompt worker shutdown. OLE tests cover real
COM registration, CF_HDROP extraction, readiness rejection, hover/leave/cancel
and unchanged clipboard contents. The manager test dispatches a real HDROP,
changes selection, checks the bound target serial and clipboard, then exercises
both UI views, status-pixel regressions, a 2× window/font scale, and twelve
interactive resize steps with matching background/control geometry before mouse release, in both views.
Screenshots are labelled simulated-device previews; production has no simulated
phones, file jobs or test executables. Actual Windows/Android USB performance,
Sogou, gallery behavior and ten-phone hardware load are not cloud-tested.
