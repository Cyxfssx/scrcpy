package com.cyxfssx.warmime;
import java.io.*;
import java.nio.file.*;
public final class ImagePolicyTest {
    static void check(boolean ok) { if (!ok) throw new AssertionError(); }
    public static void main(String[] args) throws Exception {
        check(ImagePolicy.validToken("bridge-1234-test"));
        for (String bad : new String[]{"../outside", "a/b123456", "short", "abc%2F123", "quote'123", ""}) check(!ImagePolicy.validToken(bad));
        check(!ImagePolicy.validToken(null));
        check(ImagePolicy.accepts(new String[]{"image/*"}, "image/png"));
        check(ImagePolicy.accepts(new String[]{"image/jpeg"}, "image/jpeg"));
        check(!ImagePolicy.accepts(new String[]{"image/jpeg"}, "image/png"));
        Path p=Files.createTempFile("warm-policy-", ".img");
        try {
            Files.write(p,new byte[]{(byte)255,(byte)216,(byte)255,0});check(ImagePolicy.detect(p.toFile()).equals("image/jpeg"));
            Files.write(p,new byte[]{'n','o','t','i','m','a','g','e'});
            try { ImagePolicy.detect(p.toFile()); throw new AssertionError("unrecognized format accepted"); } catch(IOException expected) { }
            try(RandomAccessFile f=new RandomAccessFile(p.toFile(),"rw")){f.setLength(ImagePolicy.MAX_FILE+1);}
            try { ImagePolicy.detect(p.toFile()); throw new AssertionError("oversize accepted"); } catch(IOException expected) { }
            Files.write(p,new byte[0]);
            try { ImagePolicy.detect(p.toFile()); throw new AssertionError("empty accepted"); } catch(IOException expected) { }
        } finally { Files.deleteIfExists(p); }
        System.out.println("Image policy checks passed: token isolation, MIME matching, format and size rejection.");
    }
}
