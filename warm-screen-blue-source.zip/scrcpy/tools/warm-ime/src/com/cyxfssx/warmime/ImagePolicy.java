package com.cyxfssx.warmime;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Locale;

public final class ImagePolicy {
    public static final long MAX_FILE = 32L * 1024 * 1024;
    public static final long MAX_CACHE = 128L * 1024 * 1024;
    private ImagePolicy() { }
    public static boolean validToken(String token) { return token != null && token.matches("[A-Za-z0-9_-]{8,100}"); }
    public static String detect(File file) throws IOException {
        if (!file.isFile() || file.length() == 0 || file.length() > MAX_FILE) throw new IOException("图片为空或超过 32 MB");
        byte[] b = new byte[64]; int n; try (FileInputStream in = new FileInputStream(file)) { n = in.read(b); }
        if (n >= 24 && b[0] == (byte) 137 && b[1] == 'P' && b[2] == 'N' && b[3] == 'G') return "image/png";
        if (n >= 3 && b[0] == (byte) 255 && b[1] == (byte) 216 && b[2] == (byte) 255) return "image/jpeg";
        if (n >= 6 && b[0] == 'G' && b[1] == 'I' && b[2] == 'F' && b[3] == '8') return "image/gif";
        if (n >= 12 && b[0] == 'R' && b[1] == 'I' && b[2] == 'F' && b[8] == 'W' && b[9] == 'E' && b[10] == 'B' && b[11] == 'P') return "image/webp";
        if (n >= 14 && b[0] == 'B' && b[1] == 'M') return "image/bmp";
        if (n >= 16 && b[4] == 'f' && b[5] == 't' && b[6] == 'y' && b[7] == 'p') {
            String brand = new String(b, 8, 4, java.nio.charset.StandardCharsets.US_ASCII);
            if (brand.equals("avif") || brand.equals("avis")) return "image/avif";
            if (brand.equals("heic") || brand.equals("heix") || brand.equals("mif1") || brand.equals("msf1")) return "image/heic";
        }
        throw new IOException("暂不支持此图片格式，请先测试 JPG 或 PNG");
    }
    public static boolean accepts(String[] types, String mime) {
        if (types == null || mime == null) return false;
        String value = mime.toLowerCase(Locale.ROOT);
        for (String raw : types) {
            if (raw == null) continue; String t = raw.toLowerCase(Locale.ROOT);
            if (t.equals(value) || t.equals("*/*") || (t.equals("image/*") && value.startsWith("image/"))) return true;
        }
        return false;
    }
}
