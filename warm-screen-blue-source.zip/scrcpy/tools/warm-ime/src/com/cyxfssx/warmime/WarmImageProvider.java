package com.cyxfssx.warmime;
import android.Manifest;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.os.Process;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

public final class WarmImageProvider extends ContentProvider {
    @Override public boolean onCreate() { return true; }
    private void transport() { if (Binder.getCallingUid() != Process.myUid() && getContext().checkCallingPermission(Manifest.permission.DUMP) != PackageManager.PERMISSION_GRANTED) throw new SecurityException("Only the explicitly authorized ADB shell transport may upload images"); }
    private String token(Uri uri, String kind) throws FileNotFoundException {
        List<String> parts = uri.getPathSegments(); if (parts.size() != 2 || !kind.equals(parts.get(0)) || !ImagePolicy.validToken(parts.get(1))) throw new FileNotFoundException("Invalid image URI"); return parts.get(1);
    }
    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        try {
            if (mode.equals("r")) return ParcelFileDescriptor.open(ImageStore.file(getContext(), token(uri, "image"), false), ParcelFileDescriptor.MODE_READ_ONLY);
            transport(); if (!mode.equals("w") && !mode.equals("wt")) throw new FileNotFoundException("Read-only image grants");
            String id = token(uri, "upload"); if (ImageStore.file(getContext(), id, false).exists()) throw new FileNotFoundException("An imported image cannot be overwritten");
            long total = 0; File[] files = ImageStore.directory(getContext()).listFiles(); if (files != null) for (File f : files) total += f.length(); if (total >= ImagePolicy.MAX_CACHE) throw new FileNotFoundException("Image cache full");
            Bundle state = WarmInputMethodService.command("result", id); if (!"ready".equals(state.getString("status"))) throw new FileNotFoundException("No active armed editor for upload");
            return ParcelFileDescriptor.open(ImageStore.file(getContext(), id, true), ParcelFileDescriptor.MODE_CREATE | ParcelFileDescriptor.MODE_TRUNCATE | ParcelFileDescriptor.MODE_WRITE_ONLY);
        } catch (IOException e) { throw new FileNotFoundException(e.getMessage()); }
    }
    @Override public String getType(Uri uri) { try { return ImageStore.mime(getContext(), token(uri, "image")); } catch (IOException e) { return null; } }
    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] args, String order) {
        try { String id = token(uri, "image"); File file = ImageStore.file(getContext(), id, false); if (!file.isFile()) return null;
            String[] columns = projection == null ? new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE} : projection; MatrixCursor cursor = new MatrixCursor(columns); Object[] row = new Object[columns.length];
            for (int i = 0; i < columns.length; ++i) { if (OpenableColumns.DISPLAY_NAME.equals(columns[i])) row[i] = "温暖图片"; else if (OpenableColumns.SIZE.equals(columns[i])) row[i] = file.length(); }
            cursor.addRow(row); return cursor;
        } catch (IOException e) { return null; }
    }
    @Override public Bundle call(String method, String arg, Bundle extras) {
        transport(); Bundle out = new Bundle();
        if (!ImagePolicy.validToken(arg)) { out.putString("status", "invalid_token"); return out; }
        try {
            if (method.equals("arm") || method.equals("result")) return WarmInputMethodService.command(method, arg);
            if (method.equals("deliver")) {
                if (!ImageStore.file(getContext(), arg, false).exists()) ImageStore.finish(getContext(), arg);
                return WarmInputMethodService.command("deliver", arg);
            }
            if (method.equals("cancel")) { ImageStore.file(getContext(), arg, true).delete(); out.putString("status", "cancelled"); return out; }
            out.putString("status", "unknown_method");
        } catch (IOException | RuntimeException e) { out.putString("status", "error"); out.putString("detail", e.getMessage()); }
        return out;
    }
    @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException(); }
    @Override public int update(Uri uri, ContentValues values, String where, String[] args) { throw new UnsupportedOperationException(); }
    @Override public int delete(Uri uri, String where, String[] args) { throw new UnsupportedOperationException(); }
}
