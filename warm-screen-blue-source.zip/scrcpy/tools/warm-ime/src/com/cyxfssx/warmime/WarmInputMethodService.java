package com.cyxfssx.warmime;
import android.content.ClipDescription;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.inputmethodservice.InputMethodService;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputContentInfo;
import android.text.InputType;
import java.util.HashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public final class WarmInputMethodService extends InputMethodService {
    private static volatile WarmInputMethodService instance;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final HashMap<String, Arm> arms = new HashMap<>();
    private long session;
    private EditorInfo editor;
    private static final class Arm { long session, at; String pkg, result = "ready"; }
    @Override public void onCreate() { super.onCreate(); instance = this; }
    // A plain View with WRAP_CONTENT can measure to all available height. The IME
    // framework replaces its LayoutParams, so enforce the size in onMeasure too.
    @Override public View onCreateInputView() {
        View v = new View(this) {
            @Override protected void onMeasure(int widthSpec, int heightSpec) {
                int height = View.MeasureSpec.getMode(heightSpec) == View.MeasureSpec.UNSPECIFIED
                        ? 1 : Math.min(1, View.MeasureSpec.getSize(heightSpec));
                setMeasuredDimension(View.MeasureSpec.getSize(widthSpec), height);
            }
        };
        v.setMinimumHeight(0);
        v.setPadding(0, 0, 0, 0);
        v.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));
        v.setBackgroundColor(0x00000000);
        return v;
    }
    @Override public boolean onEvaluateFullscreenMode() { return false; }
    @Override public boolean onEvaluateInputViewShown() { return true; }
    @Override public void onStartInput(EditorInfo info, boolean restarting) {
        super.onStartInput(info, restarting); ++session; editor = info;
        SharedPreferences p = ImageStore.prefs(this);
        if(!getPackageName().equals(info.packageName))p.edit().putString("editor_package", info.packageName == null ? "" : info.packageName).putString("editor_mimes", android.text.TextUtils.join(", ", types(info))).apply();
        String token = p.getString("manual_token", ""), target = p.getString("manual_target", "com.kakao.talk");
        long until = p.getLong("manual_until", 0);
        if (!token.isEmpty() && System.currentTimeMillis() < until && target.equals(info.packageName)) {
            p.edit().remove("manual_token").apply(); Arm arm = arm(token);
            if (arm != null) handler.postDelayed(() -> insert(token), 180);
        }
    }
    @Override public void onFinishInput() { ++session; editor = null; super.onFinishInput(); }
    @Override public void onDestroy() { if (instance == this) instance = null; super.onDestroy(); }
    static boolean selected(android.content.Context c) {
        String selected = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
        ComponentName wanted = new ComponentName(c, WarmInputMethodService.class);
        return wanted.flattenToString().equals(selected) || wanted.flattenToShortString().equals(selected);
    }
    private static String[] types(EditorInfo e) {
        if (e.contentMimeTypes != null && e.contentMimeTypes.length > 0) return e.contentMimeTypes;
        if (e.extras != null) { String[] a = e.extras.getStringArray("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES"); if (a != null) return a;
            a = e.extras.getStringArray("android.support.v13.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES"); if (a != null) return a; }
        return new String[0];
    }
    private boolean usable() {
        if (!selected(this) || editor == null || getCurrentInputConnection() == null || editor.packageName == null || editor.packageName.equals(getPackageName())) return false;
        int cls = editor.inputType & InputType.TYPE_MASK_CLASS, variation = editor.inputType & InputType.TYPE_MASK_VARIATION;
        return cls == InputType.TYPE_CLASS_TEXT && variation != InputType.TYPE_TEXT_VARIATION_PASSWORD && variation != InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD && variation != InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD;
    }
    private Arm arm(String token) {
        if (!ImagePolicy.validToken(token) || !usable()) return null;
        if (arms.size() > 32) arms.clear(); Arm a = new Arm(); a.session = session; a.pkg = editor.packageName; a.at = SystemClock.elapsedRealtime(); arms.put(token, a); return a;
    }
    private void record(String status, String detail) { ImageStore.prefs(this).edit().putString("last_result", status).putString("last_detail", detail).putLong("last_time", System.currentTimeMillis()).apply(); }
    private String insert(String token) {
        Arm a = arms.get(token);
        if (a == null || !usable() || a.session != session || !a.pkg.equals(editor.packageName) || SystemClock.elapsedRealtime() - a.at > 30000) {
            if (a != null) a.result = "stale"; record("stale", "输入框已变化或请求过期，未插入图片"); return "stale";
        }
        if (!a.result.equals("ready")) return a.result; // Never insert a token twice.
        a.result = "working";
        try {
            if (!ImageStore.file(this, token, false).isFile()) throw new IllegalStateException("图片尚未保存");
            String mime = ImageStore.mime(this, token); Uri uri = ImageStore.uri(token);
            grantUriPermission(a.pkg, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            InputContentInfo image = new InputContentInfo(uri, new ClipDescription("温暖图片", new String[]{mime}), null);
            String declared = android.text.TextUtils.join(", ", types(editor));
            InputConnection connection = getCurrentInputConnection();
            boolean accepted = connection != null && connection.commitContent(image, InputConnection.INPUT_CONTENT_GRANT_READ_URI_PERMISSION, null);
            a.result = accepted ? "accepted" : "rejected";
            record(a.result, accepted ? "应用已接受图片请求，请检查当前聊天；输入法没有调用发送操作。" : "应用未接受标准图片接口；没有自动点击发送。声明类型：" + declared);
        } catch (RuntimeException | java.io.IOException e) { a.result = "error"; record("error", e.getClass().getSimpleName() + ": " + e.getMessage()); }
        return a.result;
    }
    static Bundle command(String method, String token) {
        WarmInputMethodService ime = instance; Bundle out = new Bundle();
        if (ime == null) { out.putString("status", "ime_unavailable"); return out; }
        java.util.concurrent.atomic.AtomicReference<String> status = new java.util.concurrent.atomic.AtomicReference<>("pending");
        Runnable run = () -> {
            if (method.equals("arm")) status.set(ime.arm(token) != null ? "ready" : "no_active_editor");
            else if (method.equals("deliver")) status.set(ime.insert(token));
            else { Arm a = ime.arms.get(token); status.set(a == null ? "unknown" : a.result); }
        };
        if (Looper.myLooper() == Looper.getMainLooper()) run.run();
        else { CountDownLatch done = new CountDownLatch(1); ime.handler.post(() -> { try { run.run(); } finally { done.countDown(); } });
            try { done.await(2500, TimeUnit.MILLISECONDS); } catch (InterruptedException e) { Thread.currentThread().interrupt(); status.set("interrupted"); } }
        out.putString("status",status.get());return out;
    }
}
