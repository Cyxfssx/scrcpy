package com.cyxfssx.warmime;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public final class PickImageActivity extends Activity {
    private boolean busy;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state); TextView text = new TextView(this); text.setText("正在选择测试图片……"); text.setPadding(32, 80, 32, 32); setContentView(text);
        if (state == null) { Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT); pick.addCategory(Intent.CATEGORY_OPENABLE); pick.setType("image/*"); pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivityForResult(pick, 1); }
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data); if (request != 1) return;
        if (result != RESULT_OK || data == null || data.getData() == null) { finish(); return; }
        busy = true; Uri source = data.getData(); ((TextView)((android.view.ViewGroup)findViewById(android.R.id.content)).getChildAt(0)).setText("正在准备图片，请稍候……");
        new Thread(() -> { try {
            String token = ImageStore.importUri(this, source); String target = ImageStore.prefs(this).getString("editor_package", "com.kakao.talk"); if (target.isEmpty() || target.equals(getPackageName())) target = "com.kakao.talk";
            ImageStore.prefs(this).edit().putString("manual_token", token).putString("manual_target", target).putLong("manual_until", System.currentTimeMillis() + 60000).putString("last_result", "armed_manual").putString("last_detail", "图片已准备，请返回目标聊天，点击输入框。目标：" + target).apply();
            runOnUiThread(() -> { busy = false; Toast.makeText(this, "图片已准备，请返回聊天并点击输入框", Toast.LENGTH_LONG).show(); finish(); });
        } catch (Exception e) { runOnUiThread(() -> { busy = false; Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show(); finish(); }); } }, "warm-image-import").start();
    }
    @Override public void onBackPressed() { if (!busy) super.onBackPressed(); }
}
