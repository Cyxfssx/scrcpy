package com.cyxfssx.warmime;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import java.io.File;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.UUID;

final class ImageStore {
    static final String AUTHORITY = "com.cyxfssx.warmime.images";
    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("local", Context.MODE_PRIVATE); }
    static File directory(Context c) throws IOException { File d = new File(c.getFilesDir(), "images"); if (!d.isDirectory() && !d.mkdirs()) throw new IOException("无法创建图片缓存"); return d; }
    static File file(Context c, String token, boolean part) throws IOException { if (!ImagePolicy.validToken(token)) throw new IOException("无效图片标识"); return new File(directory(c), token + (part ? ".part" : ".img")); }
    static Uri uri(String token) { return new Uri.Builder().scheme("content").authority(AUTHORITY).appendPath("image").appendPath(token).build(); }
    static synchronized String importUri(Context c, Uri source) throws IOException {
        long total = 0; File[] existing = directory(c).listFiles(); if(existing!=null)for (File f : existing) total += f.length(); if (total >= ImagePolicy.MAX_CACHE) throw new IOException("缓存已满，请先完成发送，再到设置清理缓存");
        String token = UUID.randomUUID().toString(); File part = file(c, token, true); boolean ok = false;
        try (InputStream in = c.getContentResolver().openInputStream(source); FileOutputStream out = new FileOutputStream(part)) {
            if (in == null) throw new IOException("无法打开图片"); byte[] bytes = new byte[65536]; long n = 0; int got;
            while ((got = in.read(bytes)) != -1) { n += got; if (n > ImagePolicy.MAX_FILE) throw new IOException("图片超过 32 MB"); out.write(bytes, 0, got); }
        } catch (IOException e) { part.delete(); throw e; }
        try { finish(c, token); ok = true; return token; } finally { if (!ok) part.delete(); }
    }
    static synchronized String finish(Context c, String token) throws IOException {
        File part = file(c, token, true); String mime = ImagePolicy.detect(part); long total=0; File[] all=directory(c).listFiles(); if(all!=null)for(File f:all)total+=f.length(); if(total>ImagePolicy.MAX_CACHE){part.delete();throw new IOException("图片缓存已满，请完成发送后清理缓存");} File target = file(c, token, false);
        if (target.exists() || !part.renameTo(target)) throw new IOException("无法保存图片");
        prefs(c).edit().putString("mime_" + token, mime).putString("pending", token).apply(); return mime;
    }
    static String mime(Context c, String token) { return prefs(c).getString("mime_" + token, "image/png"); }
    static synchronized void clear(Context c) throws IOException {
        File[] files = directory(c).listFiles(); if (files != null) for (File f : files) {
            String token = f.getName().replaceFirst("\\.(img|part)$", "");
            if (ImagePolicy.validToken(token)) { c.revokeUriPermission(uri(token), android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION); f.delete(); }
        }
        prefs(c).edit().remove("pending").remove("manual_token").apply();
    }
}
