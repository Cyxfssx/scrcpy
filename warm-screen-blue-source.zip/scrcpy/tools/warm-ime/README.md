# 温暖输入法 0.1.1 验证版

修复：输入视图在测量阶段限制为 1 像素，避免空白键盘区域撑满屏幕。旧版已实测可进入 KakaoTalk 图片预览，本次未更改图片接口。可用同签名 APK 直接覆盖安装，无需卸载或更新电脑端模块。

独立 Android 输入法，不带字母键盘面板。输入视图只有透明的 1 像素占位，保留 Android 自己的导航／输入法切换区域；系统外观由手机决定。电脑搜狗仍负责选词，scrcpy 原有文字通道保持原样。

## 测试

1. 在手机安装 warm-ime.apk，打开“温暖输入法”，点击启用，再切换到温暖输入法。Android 会显示输入法的系统提示。
2. 可先在 KakaoTalk 点一次聊天输入框，再回到温暖输入法选择一张 JPG/PNG。60 秒内回聊天点输入框，观察是否出现图片预览。
3. 要测试电脑 Ctrl+V，需安装配套独立桥接补丁。关闭旧面板、投屏和 ClipboardBridge.exe，将补丁解压覆盖到已经装有 preview.8 图片桥接的温暖投屏目录。原版 preview.6 需要先安装 preview.8 桥接增量包。
4. 重新启动温暖投屏，确认“图片剪贴板桥接”已启用。手机选中温暖输入法、点聊天输入框。电脑截图／复制图片，或在文件夹选图片 Ctrl+C，在该手机投屏窗口按 Ctrl+V。
5. 成功含义仅为聊天应用的 commitContent 返回接受；请自己确认预览并手动发送。若不出现，打开温暖输入法，点“复制测试信息”反馈结果。应用拒绝、未选中输入法或请求失效时，电脑桥接保留原来的相册保存回退。

不会调用发送按钮、Enter、ACTION_SEND、辅助功能或剪贴板 URI 文本粘贴。不保证所有版本的 KakaoTalk 支持标准图片接口。没有真实手机验证结果。本机选图测试没有相册回退，仅报告接口结果。首次建议测试一张 JPG/PNG。

## 边界

- 无网络、存储读取、无障碍权限；图片由系统选图器或已授权 ADB shell 送入。
- 上传 Provider 受 DUMP 权限保护，普通应用无法上传或选择目标；对聊天应用只授予单张图片只读 URI 权限。
- 请求绑定输入框会话和应用包名；切换应用／输入框或超过 30 秒会拒绝，不重定向到新的聊天。队列中尚未开始的项目在开始处理时绑定当前输入框，因此传输期间请保持聊天不变，首次逐张测试。
- 单图 32 MB，缓存约 128 MB。缓存不会自动清理，以免破坏未完成的预览；完成发送后可在设置手动清理。清理会撤销已授权的图片 URI。
- 不记录聊天文字；设置页保留输入应用包名、声明的图片类型和上次接口状态，便于排查。
- 支持 Android 7.1/API 25 以上。系统的键盘工具栏／导航条是否显示由系统决定。

## 构建

JDK 21、Android SDK platform 36、build-tools 36.0.0；无第三方依赖。

```
ANDROID_HOME=/path/to/sdk \
WARM_IME_KEYSTORE=/private/warm-ime.p12 \
WARM_IME_STORE_PASS_FILE=/private/password-file \
BUILD_DIR=/tmp/warm-ime-build bash tools/warm-ime/build.sh
```

签名别名 warm-ime。签名私钥和密码不在源码包中。使用自己的签名不能直接覆盖本次发行 APK，需先卸载。

配套桥接 helper 源码 `server/src/main/java/com/genymobile/scrcpy/WarmImeBridge.java` 使用已有 FakeContext/Workarounds；通过 `server/build_without_gradle.sh` 单独构建，仅复制输出为 engine/warm-clipboard-scanner。**不能替换正常投屏配套的 engine/scrcpy-server**。Windows 独立模块见 tools/windows-clipboard-bridge/，没有修改或重新打包 scrcpy 核心。

## 回退

切回三星／其他输入法即可回到相册模式。需移除更新时先关闭所有窗口，将备份的 modules/ClipboardBridge.exe 与 engine/warm-clipboard-scanner 还原，再启动旧版；卸载温暖输入法不影响 scrcpy。补丁不包含投屏程序、原投屏 server、ADB、DLL 或主面板。
