#!/usr/bin/env bash
set -euo pipefail
ime_root="$(cd "$(dirname "$0")" && pwd)"
ime_build="${BUILD_DIR:-/workspace/setup/windows/warm-ime-build}"
ime_sdk="${ANDROID_HOME:-/workspace/setup/windows/sdk}"
ime_tools="$ime_sdk/build-tools/36.0.0"
: "${WARM_IME_KEYSTORE:?Set WARM_IME_KEYSTORE outside the source tree}"
: "${WARM_IME_STORE_PASS_FILE:?Set password file path outside the source tree}"
mkdir -p "$ime_build"/res "$ime_build"/gen "$ime_build"/classes "$ime_build"/dex
"$ime_tools/aapt2" compile --dir "$ime_root/res" -o "$ime_build/res.zip"
"$ime_tools/aapt2" link -o "$ime_build/resources.apk" --manifest "$ime_root/AndroidManifest.xml" -I "$ime_sdk/platforms/android-36/android.jar" --java "$ime_build/gen" "$ime_build/res.zip"
find "$ime_root/src" "$ime_build/gen" -name '*.java' > "$ime_build/sources.txt"
javac -encoding UTF-8 -source 8 -target 8 -bootclasspath "$ime_sdk/platforms/android-36/android.jar" -cp "$ime_tools/core-lambda-stubs.jar" -d "$ime_build/classes" @"$ime_build/sources.txt"
jar cf "$ime_build/classes.jar" -C "$ime_build/classes" .
"$ime_tools/d8" --min-api 25 --lib "$ime_sdk/platforms/android-36/android.jar" --output "$ime_build/dex" "$ime_build/classes.jar"
cp "$ime_build/resources.apk" "$ime_build/unsigned.apk"
python3 - "$ime_build" <<'PY'
import sys,zipfile,pathlib
p=pathlib.Path(sys.argv[1])
with zipfile.ZipFile(p/'unsigned.apk','a') as z:z.write(p/'dex/classes.dex','classes.dex')
PY
"$ime_tools/zipalign" -f -p 4 "$ime_build/unsigned.apk" "$ime_build/aligned.apk"
"$ime_tools/apksigner" sign --ks "$WARM_IME_KEYSTORE" --ks-pass "file:$WARM_IME_STORE_PASS_FILE" --ks-key-alias warm-ime --out "$ime_build/warm-ime.apk" "$ime_build/aligned.apk"
"$ime_tools/apksigner" verify --verbose "$ime_build/warm-ime.apk"
