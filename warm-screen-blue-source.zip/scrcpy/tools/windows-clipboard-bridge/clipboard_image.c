#ifndef UNICODE
#define UNICODE
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shellapi.h>
#include <ole2.h>
#include <gdiplus.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <wchar.h>
#include "clipboard_image.h"
#include "transfer.h"
#define WB_MAX_IMAGE (128u*1024u*1024u)
static UINT png_format(void){return RegisterClipboardFormatW(L"PNG");}
bool wb_clipboard_has_image(void){return IsClipboardFormatAvailable(CF_HDROP)||IsClipboardFormatAvailable(png_format())||IsClipboardFormatAvailable(RegisterClipboardFormatW(L"image/png"))||IsClipboardFormatAvailable(CF_DIBV5)||IsClipboardFormatAvailable(CF_DIB)||IsClipboardFormatAvailable(CF_BITMAP);}
static bool error(wchar_t *out,size_t cap,const wchar_t *message){if(cap){wcsncpy(out,message,cap-1);out[cap-1]=0;}return false;}
static uint32_t big32(const unsigned char *p){return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3];}
static bool valid_png(const unsigned char *data,size_t size){const unsigned char signature[]={137,80,78,71,13,10,26,10};if(size<45||memcmp(data,signature,8)||memcmp(data+12,"IHDR",4))return false;unsigned w=big32(data+16),h=big32(data+20);return w&&h&&w<=16384&&h<=16384&&(uint64_t)w*h<=64u*1024u*1024u&&!memcmp(data+size-8,"IEND",4)&&big32(data+size-12)==0;}
static bool dib_bits(const unsigned char *data,size_t size,const void **bits){
    if(size<sizeof(BITMAPINFOHEADER))return false;const BITMAPINFOHEADER *h=(const BITMAPINFOHEADER*)data;
    if(h->biSize<40||h->biSize>124||h->biSize>size||h->biWidth<=0||h->biWidth>16384||!h->biHeight||h->biHeight>16384||h->biHeight< -16384||h->biPlanes!=1)return false;
    if(h->biSize==sizeof(BITMAPV5HEADER)){const BITMAPV5HEADER *v=(const BITMAPV5HEADER*)data;if((uint64_t)v->bV5ProfileData+v->bV5ProfileSize>size)return false;}
    unsigned width=(unsigned)h->biWidth,height=(unsigned)(h->biHeight<0?-h->biHeight:h->biHeight);if((uint64_t)width*height>64u*1024u*1024u)return false;
    unsigned bpp=h->biBitCount;if(bpp!=1&&bpp!=4&&bpp!=8&&bpp!=16&&bpp!=24&&bpp!=32)return false;
    if(h->biCompression!=BI_RGB&&h->biCompression!=BI_BITFIELDS&&h->biCompression!=6)return false;
    uint64_t offset=h->biSize;if(h->biSize==40&&(h->biCompression==BI_BITFIELDS||h->biCompression==6))offset+=h->biCompression==6?16:12;
    uint64_t colors=h->biClrUsed?h->biClrUsed:bpp<=8?(1u<<bpp):0;if(colors>256)return false;offset+=colors*4;
    uint64_t stride=(((uint64_t)width*bpp+31)/32)*4;if(offset+stride*height>size)return false;*bits=data+offset;return true;
}
bool wb_clipboard_capture(DWORD sequence,const wchar_t *folder,struct wb_clipboard *out,wchar_t *message,size_t cap){
    memset(out,0,sizeof(*out));out->requested=sequence;
    ULONGLONG deadline=GetTickCount64()+350;while(!OpenClipboard(NULL)){if(GetTickCount64()>deadline)return error(message,cap,L"剪贴板正忙，请再按一次 Ctrl+V");Sleep(8);}
    if(GetClipboardSequenceNumber()!=sequence){CloseClipboard();return error(message,cap,L"剪贴板已改变，本次未传输，请重新复制后粘贴");}
    if(IsClipboardFormatAvailable(CF_HDROP)){
        HDROP drop=(HDROP)GetClipboardData(CF_HDROP);UINT count=drop?DragQueryFileW(drop,0xffffffff,NULL,0):0;
        if(!count||count>WB_IMAGE_FILES){CloseClipboard();return error(message,cap,L"一次支持最多 32 张图片，请分批复制");}
        for(UINT i=0;i<count;++i){UINT length=DragQueryFileW(drop,i,NULL,0);if(!length||length>=WB_IMAGE_PATH){CloseClipboard();return error(message,cap,L"图片文件路径过长，本次未传输");}
            DragQueryFileW(drop,i,out->paths[i],WB_IMAGE_PATH);
            if(!wt_is_image(out->paths[i])){CloseClipboard();return error(message,cap,L"只桥接普通图片文件；文件夹、快捷方式或其他类型未传输");}}
        out->count=count;out->actual=GetClipboardSequenceNumber();CloseClipboard();
        for(unsigned i=0;i<count;++i){DWORD attributes=GetFileAttributesW(out->paths[i]);if(attributes==INVALID_FILE_ATTRIBUTES||(attributes&(FILE_ATTRIBUTE_DIRECTORY|FILE_ATTRIBUTE_REPARSE_POINT)))return error(message,cap,L"请复制普通图片文件，文件夹或链接不支持");}return true;
    }
    unsigned char *bytes=NULL;size_t size=0;bool png=false;HBITMAP bitmap=NULL;UINT formats[]={png_format(),RegisterClipboardFormatW(L"image/png"),CF_DIBV5,CF_DIB};
    for(unsigned i=0;i<4;++i)if(IsClipboardFormatAvailable(formats[i])){HGLOBAL data=GetClipboardData(formats[i]);SIZE_T length=data?GlobalSize(data):0;
        if(!length||length>WB_MAX_IMAGE)continue;const void *source=GlobalLock(data);if(!source)continue;bytes=malloc(length);if(bytes){memcpy(bytes,source,length);size=length;png=i<2;}GlobalUnlock(data);if(bytes)break;}
    if(!bytes&&IsClipboardFormatAvailable(CF_BITMAP)){HBITMAP source=(HBITMAP)GetClipboardData(CF_BITMAP);BITMAP info;
        if(source&&GetObjectW(source,sizeof(info),&info)&&info.bmWidth>0&&info.bmHeight>0&&info.bmWidth<=16384&&info.bmHeight<=16384&&(uint64_t)info.bmWidth*info.bmHeight<=64u*1024u*1024u)bitmap=CopyImage(source,IMAGE_BITMAP,0,0,LR_CREATEDIBSECTION);}
    out->actual=GetClipboardSequenceNumber();CloseClipboard(); // Encoding and disk/network I/O happen after releasing the clipboard.
    if(!bytes&&!bitmap)return error(message,cap,L"没有可读取的图片，或图片过大；请重新截图后粘贴");
    GUID guid;if(CoCreateGuid(&guid)!=S_OK){free(bytes);if(bitmap)DeleteObject(bitmap);return error(message,cap,L"无法创建图片缓存");}
    wchar_t unique[48];StringFromGUID2(&guid,unique,48);int n=swprintf(out->paths[0],WB_IMAGE_PATH,L"%ls\\clipboard-%ls.png",folder,unique);
    if(n<0||n>=WB_IMAGE_PATH){free(bytes);if(bitmap)DeleteObject(bitmap);return error(message,cap,L"图片缓存路径过长");}
    bool ok=false;
    if(png){if(valid_png(bytes,size)){HANDLE file=CreateFileW(out->paths[0],GENERIC_WRITE,0,NULL,CREATE_NEW,FILE_ATTRIBUTE_TEMPORARY,NULL);if(file!=INVALID_HANDLE_VALUE){DWORD written;ok=WriteFile(file,bytes,(DWORD)size,&written,NULL)&&written==size;CloseHandle(file);}}}
    else {GpBitmap *image=NULL;const void *bits=NULL;GpStatus status=bitmap?GdipCreateBitmapFromHBITMAP(bitmap,NULL,&image):dib_bits(bytes,size,&bits)?GdipCreateBitmapFromGdiDib((const BITMAPINFO*)bytes,(void*)bits,&image):InvalidParameter;
        if(status==Ok&&image){CLSID encoder={0x557cf406,0x1a04,0x11d3,{0x9a,0x73,0x00,0x00,0xf8,0x1e,0xf3,0x2e}};ok=GdipSaveImageToFile((GpImage*)image,out->paths[0],&encoder,NULL)==Ok;GdipDisposeImage((GpImage*)image);}}
    free(bytes);if(bitmap)DeleteObject(bitmap);
    if(!ok){DeleteFileW(out->paths[0]);return error(message,cap,L"图片转换失败，本次未传输；可尝试重新截图");}out->count=1;out->owned[0]=true;return true;
}
