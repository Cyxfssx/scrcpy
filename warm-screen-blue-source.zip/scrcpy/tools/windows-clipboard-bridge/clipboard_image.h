#ifndef WB_CLIPBOARD_IMAGE_H
#define WB_CLIPBOARD_IMAGE_H
#include <windows.h>
#include <stdbool.h>
#define WB_IMAGE_FILES 32
#define WB_IMAGE_PATH 2048
struct wb_clipboard {DWORD requested,actual;unsigned count;wchar_t paths[WB_IMAGE_FILES][WB_IMAGE_PATH];bool owned[WB_IMAGE_FILES];};
bool wb_clipboard_has_image(void);
bool wb_clipboard_capture(DWORD sequence,const wchar_t *folder,struct wb_clipboard *out,wchar_t *error,size_t cap);
#endif
