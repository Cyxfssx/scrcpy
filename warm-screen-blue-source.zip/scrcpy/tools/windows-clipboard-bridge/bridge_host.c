#ifndef UNICODE
#define UNICODE
#endif
#define _WIN32_WINNT 0x0A00
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include "bridge.h"
struct wb_host {HANDLE mapping,process;DWORD pid;struct wb_shared *shared;};
struct wb_host *wb_host_start(HWND owner,const wchar_t *exe,const wchar_t *adb,const wchar_t *helper){
    struct wb_host *h=calloc(1,sizeof(*h));if(!h)return NULL;
    SECURITY_ATTRIBUTES sa={sizeof(sa),NULL,TRUE};h->mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,&sa,PAGE_READWRITE,0,sizeof(struct wb_shared),NULL);
    if(!h->mapping)goto fail;h->shared=MapViewOfFile(h->mapping,FILE_MAP_ALL_ACCESS,0,0,sizeof(struct wb_shared));if(!h->shared)goto fail;
    h->shared->magic=WB_MAGIC;h->shared->owner=owner;h->shared->parent_pid=GetCurrentProcessId();
    if(wcslen(adb)>=WB_PATH||wcslen(helper)>=WB_PATH)goto fail;wcscpy(h->shared->adb,adb);wcscpy(h->shared->helper,helper);
    HANDLE parent=NULL;if(!DuplicateHandle(GetCurrentProcess(),GetCurrentProcess(),GetCurrentProcess(),&parent,SYNCHRONIZE|PROCESS_QUERY_LIMITED_INFORMATION,TRUE,0))goto fail;
    wchar_t command[WB_PATH+128];swprintf(command,WB_PATH+128,L"\"%ls\" --bridge %llu %llu",exe,(unsigned long long)(UINT_PTR)h->mapping,(unsigned long long)(UINT_PTR)parent);
    STARTUPINFOEXW si={0};si.StartupInfo.cb=sizeof(si);SIZE_T size=0;InitializeProcThreadAttributeList(NULL,1,0,&size);si.lpAttributeList=HeapAlloc(GetProcessHeap(),0,size);
    bool initialized=si.lpAttributeList&&InitializeProcThreadAttributeList(si.lpAttributeList,1,0,&size),ok=false;
    HANDLE handles[]={h->mapping,parent};PROCESS_INFORMATION pi;
    if(initialized&&UpdateProcThreadAttribute(si.lpAttributeList,0,PROC_THREAD_ATTRIBUTE_HANDLE_LIST,handles,sizeof(handles),NULL,NULL))ok=CreateProcessW(exe,command,NULL,NULL,TRUE,CREATE_NO_WINDOW|EXTENDED_STARTUPINFO_PRESENT,NULL,NULL,&si.StartupInfo,&pi)!=FALSE;
    if(initialized)DeleteProcThreadAttributeList(si.lpAttributeList);if(si.lpAttributeList)HeapFree(GetProcessHeap(),0,si.lpAttributeList);CloseHandle(parent);
    if(!ok)goto fail;CloseHandle(pi.hThread);h->process=pi.hProcess;h->pid=pi.dwProcessId;return h;
fail:if(h->shared)UnmapViewOfFile(h->shared);if(h->mapping)CloseHandle(h->mapping);free(h);return NULL;
}
void wb_host_target(struct wb_host *h,HANDLE process,DWORD pid,const wchar_t *serial,const wchar_t *alias,bool enabled){
    if(!h||!process||wcslen(serial)>=128||wcslen(alias)>=64)return;FILETIME created,exit,kernel,user;if(!GetProcessTimes(process,&created,&exit,&kernel,&user))return;
    int slot=-1;for(unsigned i=0;i<WB_MAX_TARGETS;++i)if(h->shared->targets[i].pid==pid){slot=(int)i;break;}else if(!h->shared->targets[i].pid&&slot<0)slot=(int)i;
    if(slot<0)return;InterlockedIncrement(&h->shared->sequence);struct wb_target *t=&h->shared->targets[slot];t->pid=pid;t->created=created;t->enabled=enabled;wcscpy(t->serial,serial);wcscpy(t->alias,alias);InterlockedIncrement(&h->shared->sequence);
}
void wb_host_remove(struct wb_host *h,DWORD pid){if(!h)return;InterlockedIncrement(&h->shared->sequence);for(unsigned i=0;i<WB_MAX_TARGETS;++i)if(h->shared->targets[i].pid==pid)ZeroMemory(&h->shared->targets[i],sizeof(struct wb_target));InterlockedIncrement(&h->shared->sequence);}
void wb_host_stop(struct wb_host *h){if(!h)return;InterlockedExchange(&h->shared->stop,1);if(WaitForSingleObject(h->process,5000)==WAIT_TIMEOUT){TerminateProcess(h->process,ERROR_CANCELLED);WaitForSingleObject(h->process,1000);}CloseHandle(h->process);UnmapViewOfFile(h->shared);CloseHandle(h->mapping);free(h);}
bool wb_host_message(struct wb_host *h,WPARAM sender,LPARAM data,wchar_t *text,size_t capacity){
    if(!h||!data||!capacity)return false;DWORD pid=0;GetWindowThreadProcessId((HWND)sender,&pid);if(pid!=h->pid)return false;
    const COPYDATASTRUCT *c=(const COPYDATASTRUCT*)data;if(c->dwData!=WB_STATUS_MAGIC||!c->lpData||c->cbData<2||c->cbData>1024||c->cbData%sizeof(wchar_t))return false;
    size_t n=c->cbData/sizeof(wchar_t);const wchar_t *input=c->lpData;if(input[n-1])return false;if(n>capacity)n=capacity;memcpy(text,input,(n-1)*sizeof(wchar_t));text[n-1]=0;return true;
}

int wb_host_health(struct wb_host *h){if(!h||WaitForSingleObject(h->process,0)!=WAIT_TIMEOUT)return -1;return (int)InterlockedCompareExchange(&h->shared->ready,0,0);}

DWORD wb_host_detach(struct wb_host *h){if(!h)return 0;DWORD pid=h->pid;InterlockedExchange(&h->shared->detached,1);CloseHandle(h->process);UnmapViewOfFile(h->shared);CloseHandle(h->mapping);free(h);return pid;}
