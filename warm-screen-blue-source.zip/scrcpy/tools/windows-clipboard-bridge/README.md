# Current module update (preview.10)

Used by tools/windows-manager's blue/white panel. The bridge uses only shell-private
transport files under /data/local/tmp, never /sdcard/Pictures. It arms the existing
Warm IME provider, uploads one temporary image, invokes the standard image input route,
and cleans up the transport file after delivery/rejection/cancellation. If the IME or
chat editor is unavailable or rejects the content, the operation fails explicitly;
there is NO media scanner or gallery fallback. The APK is unchanged. Standard image
acceptance is not an assertion of preview visibility or actual message delivery.

The current mock integration tests check all eight images delivered without public
files or media indexing, temporary cleanup, and rejected-arm/rejected-delivery paths.
The legacy classic-panel source is retained for reference; current releases build only
ClipboardBridge.exe from this folder and the panel from tools/windows-manager.
The earlier gallery-specific behavior documented below does not apply to preview.10.

# Classic 温暖投屏 with an isolated image clipboard bridge

This variant restores the preview-6 control-panel source and wallpaper, adds an
independent `modules/ClipboardBridge.exe`, and changes the launch arguments to
always pass the existing `--no-clipboard-images` flag. **The preview-6 scrcpy.exe,
paired Android mirroring server and all existing engine DLLs are copied without
recompilation or modification.** The old image route is disabled, not removed
from the engine binary. The new bridge is the sole image route for panel-launched
mirrors. There is no transfer-page UI and no change to video/input protocols.

The original SDK keyboard/`--text-via-clipboard` path remains responsible for
ordinary Unicode text, Sogou committed text and text Ctrl+V. The only visible
control change is the **图片剪贴板桥接** toggle, applied live to the selected phone.
The module does not read characters or listen for automatic clipboard uploads.
It handles image Ctrl+V only when a registered mirror process is foreground.

## Layout and activation

```
温暖投屏.exe
engine/                    # preview-6 binaries, byte-identical
  warm-clipboard-scanner   # additional one-shot Android media helper
modules/
  ClipboardBridge.exe      # independent Windows GUI-background process
```

Launch/restart mirrors through this panel to register them. Manually launched
scrcpy processes are not adopted. Retain the whole archive and run normally as
the current user. An absent/crashed bridge produces a panel status rather than
silently re-enabling the old image path. The source does not change installed
scrcpy elsewhere on the computer.

## Boundary and targeting

The parent shares a bounded mapping containing only its own launched process
IDs, creation times, device serials, display names and enable flags. A sequence
counter permits consistent snapshots without blocking the hook. Mapping and
parent-process handles are explicitly inherited with STARTUPINFOEX; unrelated
log/pipe handles are excluded. No public named pipe/mapping is exposed.

The module validates process creation times, retains synchronization handles,
and refuses stale/reused PIDs. It never derives targets from a window caption
or the clipboard, and never treats an arbitrary foreground application as a
phone. Each accepted Ctrl+V records its target serial and clipboard sequence
before asynchronous work; later focus changes do not retarget it.

The WH_KEYBOARD_LL callback checks only V down/up, modifiers, the foreground PID,
a cached registered-process handle and available clipboard formats. It allocates
no image buffers, opens no clipboard, performs no file/network I/O and waits for
no UI in the callback. V repeats/key-up are suppressed for an accepted image
shortcut, preventing duplicate uploads or a stray V. Ctrl+Shift+V, plain text,
disabled/unregistered windows and ordinary typing pass through. There is no
keyboard injection or message sending to the Android chat application.

## Clipboard capture

A separate low-priority worker reads the clipboard only after an accepted
shortcut. It checks the sequence while locked; changed/busy data is rejected
instead of uploading another clipboard value. The clipboard is never emptied,
replaced or rewritten by this module. Screenshot buffers are copied before the
lock is released; PNG encoding and all disk/network I/O happen after release.

- Registered PNG / image/png: original PNG bytes are retained.
- CF_DIB / CF_DIBV5 / CF_BITMAP: checked dimensions/header/stride, then lossless PNG.
- CF_HDROP: up to 32 ordinary image file paths, read without image recompression.

Mixed non-image selections, folders, reparse points and shortcuts are rejected
as a whole. Copying a URL is text, not an image. Pure text goes to the unchanged
scrcpy SDK route. Existing image-first clipboard behavior is retained for data
that simultaneously contains image pixels and alternate text.

A repeated unchanged clipboard can reuse the immutable snapshot; changing the
foreground phone still produces a separate task for the new serial. Temporary
PNGs are privately named under a per-run Temp folder and retained only while
queued work or the current-image cache references them. Healthy exit cleans the
owned temporary files. Forced exit or file locks can leave that run's Temp folder;
original picture files are never deleted, renamed, compressed or installed.

## Copy and media indexing

`transfer.c` streams 64 KiB chunks through the existing localhost ADB server,
with a 16 MiB/s cap and one background copy worker. It changes no ADB server
configuration and issues no global reconnect/kill-server. The module supports
ANDROID_ADB_SERVER_PORT; custom ADB_SERVER_SOCKET transports are intentionally
not silently redirected to another server.

Images are saved under `/sdcard/Pictures/温暖投屏` with unique bridge prefixes,
retaining original file content and original basename suffixes. Atomic rename
refuses overwrite, and failure/cancellation cleans only the matching temporary
remote path when the phone is reachable. A physical disconnect can defer cleanup.

The added `warm-clipboard-scanner` dex archive is the previously compiled
TransferScanner entry point, not a replacement mirroring server. It briefly runs
as the already-authorized ADB shell user, requests MediaScannerConnection indexing,
waits for a URI callback, then exits. It does not launch activities, choose a
recipient or send messages. Indexing warnings preserve successfully uploaded
files. Native phone gallery behavior/format support can differ.

When the panel closes but keeps phone windows, it detaches the bridge, which
continues serving only those registered processes and exits automatically when
the final enabled mirror process ends. Normal panel exit signals cancellation
and gives only its own module process a five-second shutdown bound; it never
force-kills another application or a mirror recording to stop image processing.
The independent process isolates large/slow clipboard providers from video,
keyboard processing and the panel's message thread.

## Build and checks

With a MinGW x64 C toolchain:

```bash
bash tools/windows-clipboard-bridge/build.sh /absolute/build-directory
```

Ship `Manager.exe` as 温暖投屏.exe and `ClipboardBridge.exe` under modules.
`Manager-smoke.exe` and `Bridge-test.exe` are regression executables, never shipped.
The Android helper is built from the shared TransferScanner Java entry with
`server/build_without_gradle.sh`; keep the normal paired server unchanged.

Portable profile/path/launch-argument tests support ASan/UBSan and assert that
`--no-clipboard-images` is always present, independent of the bridge toggle.
The classic manager smoke suite covers ten simulated mirrors, reconnect, stop,
profiles, rounded windows, wallpaper, status-pixel regression and buttons.

The live bridge integration test uses real Windows SendInput, clipboard formats,
separate child processes, the real low-level hook, a localhost-only modeled ADB
server and synthetic image fixtures:

```text
python tools/windows-clipboard-bridge/tests/mock_bridge.py /absolute/build-directory wine
```

Python Pillow is test-only. The mock server never executes incoming shell text.
It verifies eight uploads including original PNG/JPEG bytes, screenshot pixel
colors, orientation and opacity, multiple serials, repeat suppression, Unicode/text
pass-through, unchanged clipboard, opt-out, unregistered windows, Ctrl+Shift+V,
a clipboard change while capture waits, mixed non-image rejection, and continued
pasting after panel detachment. It also waits for the detached module to exit
when its last registered process ends. Tests run under Wine; actual Sogou,
Android gallery indexing and multi-phone USB hardware are not cloud-tested.
