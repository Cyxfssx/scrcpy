#ifndef UNICODE
#define UNICODE
#endif
#define _WIN32_WINNT 0x0A00
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shellapi.h>
#include <ole2.h>
#include <gdiplus.h>
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include "bridge.h"
#include "clipboard_image.h"
#include "transfer.h"
#define WB_QUEUE 32
#define WB_OWNED 256
struct request {struct wb_target target;DWORD sequence;};
struct live_target {struct wb_target target;HANDLE process;};
struct bridge {
    struct wb_shared *shared;HANDLE parent,mapping,worker,wake;HWND window;HHOOK hook;LONG config_version;
    CRITICAL_SECTION lock;struct request requests[WB_QUEUE];unsigned first,count;volatile LONG stop,dropped;
    struct live_target targets[WB_MAX_TARGETS];bool swallowed;
    struct wt_context *transfer;struct wb_clipboard *cache;bool cache_valid;
    wchar_t spool[WB_PATH],owned[WB_OWNED][WB_PATH];
};
static struct bridge *current;
static void notify(struct bridge *b,const wchar_t *message){
    if(InterlockedCompareExchange(&b->shared->detached,0,0)||WaitForSingleObject(b->parent,0)!=WAIT_TIMEOUT)return;DWORD owner=0;GetWindowThreadProcessId(b->shared->owner,&owner);if(owner!=b->shared->parent_pid)return;
    COPYDATASTRUCT data={WB_STATUS_MAGIC,(DWORD)((wcslen(message)+1)*sizeof(wchar_t)),(void*)message};DWORD_PTR result;
    SendMessageTimeoutW(b->shared->owner,WM_COPYDATA,(WPARAM)b->window,(LPARAM)&data,SMTO_ABORTIFHUNG,100,&result);
}
static bool same_time(FILETIME a,FILETIME b){return a.dwHighDateTime==b.dwHighDateTime&&a.dwLowDateTime==b.dwLowDateTime;}
static void refresh_targets(struct bridge *b){
    struct wb_target fresh[WB_MAX_TARGETS];LONG version=InterlockedCompareExchange(&b->shared->sequence,0,0);if(version==b->config_version||(version&1))return;
    memcpy(fresh,b->shared->targets,sizeof(fresh));MemoryBarrier();if(version!=InterlockedCompareExchange(&b->shared->sequence,0,0))return;
    for(unsigned i=0;i<WB_MAX_TARGETS;++i){struct live_target *old=&b->targets[i];struct wb_target *n=&fresh[i];n->serial[127]=0;n->alias[63]=0;
        if(old->target.pid==n->pid&&same_time(old->target.created,n->created)){old->target=*n;continue;}
        if(old->process)CloseHandle(old->process);old->process=NULL;old->target=*n;
        if(n->pid){HANDLE process=OpenProcess(SYNCHRONIZE|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,n->pid);FILETIME created,exit,kernel,user;
            if(process&&GetProcessTimes(process,&created,&exit,&kernel,&user)&&same_time(created,n->created))old->process=process;else if(process)CloseHandle(process);}}
    b->config_version=version;
}
static bool push_request(struct bridge *b,const struct wb_target *target,DWORD sequence){bool ok=false;EnterCriticalSection(&b->lock);
    if(b->count<WB_QUEUE){struct request *r=&b->requests[(b->first+b->count)%WB_QUEUE];r->target=*target;r->sequence=sequence;++b->count;ok=true;}LeaveCriticalSection(&b->lock);SetEvent(b->wake);return ok;
}
static LRESULT CALLBACK keyboard(int code,WPARAM kind,LPARAM data){
    struct bridge *b=current;if(code!=HC_ACTION||!b)return CallNextHookEx(NULL,code,kind,data);
    const KBDLLHOOKSTRUCT *key=(const KBDLLHOOKSTRUCT*)data;if(key->vkCode!='V')return CallNextHookEx(b->hook,code,kind,data);
    bool down=kind==WM_KEYDOWN||kind==WM_SYSKEYDOWN;
    if(!down){if(b->swallowed){b->swallowed=false;return 1;}return CallNextHookEx(b->hook,code,kind,data);}
    if(b->swallowed)return 1;
    if(!(GetAsyncKeyState(VK_CONTROL)&0x8000)||(GetAsyncKeyState(VK_SHIFT)&0x8000)||(GetAsyncKeyState(VK_MENU)&0x8000)||(GetAsyncKeyState(VK_LWIN)&0x8000)||(GetAsyncKeyState(VK_RWIN)&0x8000))return CallNextHookEx(b->hook,code,kind,data);
    DWORD pid=0;GetWindowThreadProcessId(GetForegroundWindow(),&pid);
    for(unsigned i=0;i<WB_MAX_TARGETS;++i){struct live_target *t=&b->targets[i];if(t->target.pid!=pid||!t->target.enabled||!t->process||WaitForSingleObject(t->process,0)!=WAIT_TIMEOUT)continue;
        DWORD sequence=GetClipboardSequenceNumber();if(!wb_clipboard_has_image()||sequence!=GetClipboardSequenceNumber())break;
        // No clipboard data read, disk access, image conversion, network I/O or UI wait in the hook.
        if(!push_request(b,&t->target,sequence)){InterlockedExchange(&b->dropped,1);SetEvent(b->wake);}b->swallowed=true;return 1;}
    return CallNextHookEx(b->hook,code,kind,data);
}
static bool pop_request(struct bridge *b,struct request *out){bool ok=false;EnterCriticalSection(&b->lock);if(b->count){*out=b->requests[b->first];b->first=(b->first+1)%WB_QUEUE;--b->count;ok=true;}LeaveCriticalSection(&b->lock);return ok;}
static bool active_state(enum wt_state s){return s==WT_QUEUED||s==WT_ACTIVE||s==WT_INDEXING;}
static bool own_file(struct bridge *b,const wchar_t *path){
    for(unsigned i=0;i<WB_OWNED;++i)if(!wcscmp(b->owned[i],path))return true;
    for(unsigned i=0;i<WB_OWNED;++i)if(!b->owned[i][0]){wcscpy(b->owned[i],path);return true;}return false;
}
static bool cached_file(struct bridge *b,const wchar_t *path){if(!b->cache_valid)return false;for(unsigned i=0;i<b->cache->count;++i)if(!wcscmp(path,b->cache->paths[i]))return true;return false;}
static void cleanup_owned(struct bridge *b,const struct wt_task *tasks,size_t count){
    for(unsigned i=0;i<WB_OWNED;++i)if(b->owned[i][0]&&!cached_file(b,b->owned[i])){bool busy=false;for(size_t j=0;j<count;++j)if(active_state(tasks[j].state)&&!wcscmp(tasks[j].local,b->owned[i])){busy=true;break;}
        if(!busy){DeleteFileW(b->owned[i]);b->owned[i][0]=0;}}
}
static DWORD WINAPI worker(void *param){
    struct bridge *b=param;SetThreadPriority(GetCurrentThread(),THREAD_PRIORITY_BELOW_NORMAL);
    GdiplusStartupInput gdip={1,NULL,FALSE,TRUE};ULONG_PTR token=0;if(GdiplusStartup(&token,&gdip,NULL)!=Ok){notify(b,L"图片桥接无法初始化图片转换组件");return 1;}
    struct wt_task *tasks=calloc(WT_CAPACITY,sizeof(*tasks));struct wb_clipboard *capture=calloc(1,sizeof(*capture));if(!tasks||!capture){free(tasks);free(capture);GdiplusShutdown(token);return 1;}
    unsigned generation=0;wchar_t message[512];
    while(!InterlockedCompareExchange(&b->stop,0,0)){
        WaitForSingleObject(b->wake,200);if(InterlockedExchange(&b->dropped,0))notify(b,L"图片桥接队列正忙，请稍后再按 Ctrl+V");
        struct request r;
        while(!InterlockedCompareExchange(&b->stop,0,0)&&pop_request(b,&r)){
            if(!b->cache_valid||(r.sequence!=b->cache->requested&&r.sequence!=b->cache->actual)){
                if(!wb_clipboard_capture(r.sequence,b->spool,capture,message,512)){notify(b,message);continue;}
                b->cache_valid=false;
                bool tracked=true;for(unsigned i=0;i<capture->count;++i)if(capture->owned[i]&&!own_file(b,capture->paths[i])){DeleteFileW(capture->paths[i]);tracked=false;}
                if(!tracked){notify(b,L"图片缓存已满，请等待当前传输完成");continue;}*b->cache=*capture;b->cache_valid=true;cleanup_owned(b,tasks,wt_snapshot(b->transfer,tasks,WT_CAPACITY));
            }
            if(InterlockedCompareExchange(&b->stop,0,0))break;
            // A captured request remains bound to its original serial even if focus changes.
            FILETIME now;GetSystemTimeAsFileTime(&now);uint64_t batch=(((uint64_t)now.dwHighDateTime<<32)|now.dwLowDateTime)/10000;
            unsigned added=0;wchar_t detail[256];
            for(unsigned i=0;i<b->cache->count;++i)if(wt_enqueue(b->transfer,b->cache->paths[i],r.target.serial,r.target.alias,L"/data/local/tmp",batch+i,true,detail,256))++added;
            if(added){swprintf(message,512,L"图片桥接：%u 张已加入 %ls 的后台队列，不会自动发送。",added,r.target.alias);notify(b,message);}else notify(b,detail);
        }
        unsigned next=wt_generation(b->transfer);if(next!=generation){generation=next;size_t count=wt_snapshot(b->transfer,tasks,WT_CAPACITY);bool completed=false;
            for(size_t i=0;i<count;++i)if(!active_state(tasks[i].state)){completed=true;
                swprintf(message,512,L"图片桥接 · %ls：%ls",tasks[i].alias,tasks[i].detail);notify(b,message);}
            cleanup_owned(b,tasks,count);if(completed)wt_clear_completed(b->transfer);}
    }
    b->cache_valid=false;wt_cancel_all(b->transfer);wt_destroy(b->transfer);b->transfer=NULL;
    for(unsigned i=0;i<WB_OWNED;++i)if(b->owned[i][0])DeleteFileW(b->owned[i]);RemoveDirectoryW(b->spool);
    free(tasks);free(capture);GdiplusShutdown(token);return 0;
}
static LRESULT CALLBACK window_proc(HWND h,UINT msg,WPARAM w,LPARAM l){
    (void)w;(void)l;struct bridge *b=current;
    if(msg==WM_CLOSE){PostQuitMessage(0);return 0;}
    if(msg==WM_TIMER&&b){
        bool detached=InterlockedCompareExchange(&b->shared->detached,0,0)!=0;
        if((b->worker&&WaitForSingleObject(b->worker,0)==WAIT_OBJECT_0)||InterlockedCompareExchange(&b->shared->stop,0,0)||(!detached&&WaitForSingleObject(b->parent,0)!=WAIT_TIMEOUT)){PostQuitMessage(0);return 0;}
        refresh_targets(b);
        if(detached){bool any=false;for(unsigned i=0;i<WB_MAX_TARGETS;++i)if(b->targets[i].target.enabled&&b->targets[i].process&&WaitForSingleObject(b->targets[i].process,0)==WAIT_TIMEOUT)any=true;if(!any)PostQuitMessage(0);}
        return 0;
    }
    return DefWindowProcW(h,msg,w,l);
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE previous,LPWSTR command,int show){
    (void)previous;(void)command;(void)show;int argc;wchar_t **argv=CommandLineToArgvW(GetCommandLineW(),&argc);
    if(!argv||argc!=4||wcscmp(argv[1],L"--bridge")){if(argv)LocalFree(argv);return 2;}
    wchar_t *end;UINT_PTR map=(UINT_PTR)wcstoull(argv[2],&end,10);if(*end){LocalFree(argv);return 2;}UINT_PTR parent=(UINT_PTR)wcstoull(argv[3],&end,10);if(*end){LocalFree(argv);return 2;}LocalFree(argv);
    struct bridge *b=calloc(1,sizeof(*b));if(!b)return 3;b->mapping=(HANDLE)map;b->parent=(HANDLE)parent;b->config_version=-1;
    b->shared=MapViewOfFile(b->mapping,FILE_MAP_ALL_ACCESS,0,0,sizeof(struct wb_shared));if(!b->shared||b->shared->magic!=WB_MAGIC||GetProcessId(b->parent)!=b->shared->parent_pid||WaitForSingleObject(b->parent,0)!=WAIT_TIMEOUT)return 3;
    b->shared->adb[WB_PATH-1]=b->shared->helper[WB_PATH-1]=0;InitializeCriticalSection(&b->lock);b->wake=CreateEventW(NULL,FALSE,FALSE,NULL);b->cache=calloc(1,sizeof(*b->cache));
    wchar_t root[WB_PATH]={0},name[48];GUID guid;if(CoCreateGuid(&guid)!=S_OK||!StringFromGUID2(&guid,name,48))return 3;DWORD temp_length=GetTempPathW(WB_PATH,root);if(!temp_length||temp_length>=WB_PATH)return 3;int n=swprintf(b->spool,WB_PATH,L"%lsWarmClipboard-%ls",root,name);if(n<0||n>=WB_PATH||!CreateDirectoryW(b->spool,NULL))return 3;
    unsigned port=5037;wchar_t port_text[32]={0};if(GetEnvironmentVariableW(L"ANDROID_ADB_SERVER_PORT",port_text,32)){unsigned long value=wcstoul(port_text,&end,10);if(*end||!value||value>65535)return 3;port=(unsigned)value;}
    // Do not silently attach to a different daemon when a custom remote socket is configured.
    wchar_t socket_env[256]={0};if(GetEnvironmentVariableW(L"ADB_SERVER_SOCKET",socket_env,256))return 3;
    b->transfer=wt_create(b->shared->adb,b->shared->helper,port);if(!b->transfer||!b->cache||!b->wake)return 3;
    current=b;WNDCLASSW cls={0};cls.lpfnWndProc=window_proc;cls.hInstance=instance;cls.lpszClassName=L"WarmClipboardBridgeWindow";RegisterClassW(&cls);
    b->window=CreateWindowExW(0,cls.lpszClassName,L"",0,0,0,0,0,HWND_MESSAGE,NULL,instance,NULL);if(!b->window)return 3;
    b->hook=SetWindowsHookExW(WH_KEYBOARD_LL,keyboard,instance,0);if(!b->hook){notify(b,L"图片桥接无法注册快捷键，请重新启动软件");return 3;}
    b->worker=CreateThread(NULL,0,worker,b,0,NULL);if(!b->worker)return 3;SetTimer(b->window,1,100,NULL);refresh_targets(b);InterlockedExchange(&b->shared->ready,1);
    MSG message;while(GetMessageW(&message,NULL,0,0)>0){TranslateMessage(&message);DispatchMessageW(&message);}
    InterlockedExchange(&b->shared->ready,-1);UnhookWindowsHookEx(b->hook);InterlockedExchange(&b->stop,1);SetEvent(b->wake);CancelSynchronousIo(b->worker);WaitForSingleObject(b->worker,INFINITE);
    if(b->transfer)wt_destroy(b->transfer);
    KillTimer(b->window,1);DestroyWindow(b->window);for(unsigned i=0;i<WB_MAX_TARGETS;++i)if(b->targets[i].process)CloseHandle(b->targets[i].process);
    CloseHandle(b->worker);CloseHandle(b->wake);DeleteCriticalSection(&b->lock);free(b->cache);UnmapViewOfFile(b->shared);CloseHandle(b->mapping);CloseHandle(b->parent);free(b);current=NULL;return 0;
}
