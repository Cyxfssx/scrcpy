#include "model.h"
#include <assert.h>
#include <string.h>
#include <wchar.h>

int main(void) {
    struct wm_profile p = wm_default_profile();
    wchar_t command[WM_COMMAND_SIZE];
    assert(wm_build_command(command, WM_COMMAND_SIZE, L"C:\\my app\\scrcpy.exe",
                            L"192.168.0.2:5555", L"聊天 手机", NULL, &p));
    assert(wcsstr(command, L"\"--text-via-clipboard\""));
    assert(wcsstr(command, L"\"--max-size=1280\""));
    assert(wcsstr(command, L"\"--max-fps=30\""));
    assert(wcsstr(command, L"\"--video-bit-rate=2000000\""));
    assert(wcsstr(command, L"\"--video-buffer=0\""));
    assert(wcsstr(command, L"\"--no-audio\""));
    assert(!wcsstr(command, L"\"--record\""));
    assert(wcsstr(command,L"--print-fps"));
    assert(wcsstr(command,L"--no-clipboard-images"));
    p.text_input=false;p.clipboard_images=false;
    assert(wm_build_command(command,WM_COMMAND_SIZE,L"scrcpy.exe",L"serial",L"title",NULL,&p));
    assert(!wcsstr(command,L"--text-via-clipboard"));
    assert(wcsstr(command,L"--no-clipboard-images"));
    p.text_input=true;p.clipboard_images=true;
    p.max_size = p.max_fps = 0; p.buffer_ms = 120;
    p.audio = p.record = p.topmost = p.borderless = true; p.hwdec = 1;
    assert(wm_build_command(command, WM_COMMAND_SIZE, L"scrcpy.exe", L"serial",
                            L"title", L"C:\\录屏文件\\test.mkv", &p));
    assert(wcsstr(command, L"\"--max-size=0\""));
    assert(!wcsstr(command, L"--max-fps"));
    assert(wcsstr(command, L"\"--video-buffer=120\""));
    assert(wcsstr(command, L"\"--record\" \"C:\\录屏文件\\test.mkv\""));
    assert(!wcsstr(command, L"--no-audio"));
    assert(wcsstr(command, L"--always-on-top"));
    assert(wcsstr(command, L"--window-borderless"));
    assert(!wm_build_command(command, 20, L"scrcpy.exe", L"serial", L"title", L"a.mkv", &p));
    assert(!command[0]);
    assert(!wm_build_command(command, WM_COMMAND_SIZE, L"scrcpy.exe", L"serial", L"title", NULL, &p));
    p.bitrate = 0; assert(!wm_profile_valid(&p));
    p.bitrate = 2000000; p.max_fps = 241; assert(!wm_profile_valid(&p));
    p.max_fps = 30; p.buffer_ms = 2001; assert(!wm_profile_valid(&p));
    p = wm_default_profile();
    assert(wm_build_command(command, WM_COMMAND_SIZE, L"C:\\a\\scrcpy.exe",
                            L"quoted\"serial\\", L"title", NULL, &p));
    assert(wcsstr(command, L"\"quoted\\\"serial\\\\\""));
    const char *devices = "* daemon started successfully\r\nList of devices attached\r\n"
        "usb-1 device product:p model:SM_A376B transport_id:1\r\n"
        "192.168.1.2:5555 device model:Pixel_9\n"
        "locked unauthorized\nmissing offline\nusb-1 device model:duplicate\n";
    struct wm_discovered_device found[32]; bool truncated;
    size_t count = wm_parse_devices(devices, found, 32, &truncated);
    assert(count == 4 && !truncated);
    assert(!strcmp(found[0].serial, "usb-1") && !strcmp(found[0].model, "SM_A376B"));
    assert(found[0].state == WM_DEVICE_READY);
    assert(found[2].state == WM_DEVICE_UNAUTHORIZED);
    assert(found[3].state == WM_DEVICE_OFFLINE);
    assert(wm_parse_devices(devices, found, 2, &truncated) == 2 && truncated);
    assert(!wm_parse_devices("List of devices attached\n", found, 32, &truncated));
    return 0;
}
