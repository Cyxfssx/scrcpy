#ifndef UNICODE
#define UNICODE
#endif
#define _WIN32_WINNT 0x0A00
#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <windows.h>
#include <shellapi.h>
#include <shlobj.h>
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include "bridge.h"
static struct wb_host *host;static HWND main_window;static unsigned completed,errors,keys,letters;static wchar_t last_status[512];
static bool raw(SOCKET s,void *buffer,size_t n,bool write){char *p=buffer;while(n){int count=write?send(s,p,(int)n,0):recv(s,p,(int)n,0);if(count<=0)return false;p+=count;n-=(size_t)count;}return true;}
static bool service(SOCKET s,const char *value){char header[5],reply[4];snprintf(header,5,"%04x",(unsigned)strlen(value));return raw(s,header,4,true)&&raw(s,(void*)value,strlen(value),true)&&raw(s,reply,4,false)&&!memcmp(reply,"OKAY",4);}
static int shell_bridge(int argc,wchar_t **argv){if(argc!=5)return 90;WSADATA wsa;WSAStartup(MAKEWORD(2,2),&wsa);SOCKET s=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);struct sockaddr_in address={0};address.sin_family=AF_INET;address.sin_port=htons(55107);address.sin_addr.s_addr=htonl(INADDR_LOOPBACK);int result=91;if(connect(s,(struct sockaddr*)&address,sizeof(address)))goto done;
 char serial[512],script[32768],request[33000];WideCharToMultiByte(CP_UTF8,0,argv[2],-1,serial,sizeof(serial),NULL,NULL);WideCharToMultiByte(CP_UTF8,0,argv[4],-1,script,sizeof(script),NULL,NULL);snprintf(request,sizeof(request),"host:transport:%s",serial);if(!service(s,request))goto done;snprintf(request,sizeof(request),"shell:%s",script);if(!service(s,request))goto done;char exit;if(raw(s,&exit,1,false)&&exit=='0')result=0;
done:closesocket(s);WSACleanup();return result;}
static LRESULT CALLBACK wndproc(HWND window,UINT msg,WPARAM w,LPARAM l){if(msg==WM_COPYDATA){if(wb_host_message(host,w,l,last_status,512)){wprintf(L"%ls\n",last_status);fflush(stdout);if(wcsstr(last_status,L"图片已存入手机相册")||wcsstr(last_status,L"聊天应用已接受图片请求"))++completed;if(wcsstr(last_status,L"失败")||wcsstr(last_status,L"未确认"))++errors;return TRUE;}}
 if(msg==WM_KEYDOWN&&w=='V')++keys;if(msg==WM_CHAR&&w==0x6e29)++letters;if(msg==WM_DESTROY){PostQuitMessage(0);return 0;}return DefWindowProcW(window,msg,w,l);}
static void pump(unsigned milliseconds){ULONGLONG until=GetTickCount64()+milliseconds;MSG msg;do{while(PeekMessageW(&msg,NULL,0,0,PM_REMOVE)){TranslateMessage(&msg);DispatchMessageW(&msg);}Sleep(5);}while(GetTickCount64()<until);}
static bool wait_completed(unsigned desired){ULONGLONG until=GetTickCount64()+10000;while(completed<desired&&GetTickCount64()<until)pump(20);if(completed!=desired)fwprintf(stderr,L"Expected %u completions got %u; %ls\n",desired,completed,last_status);return completed==desired;}
static bool set_data(UINT format,const void *bytes,size_t size){HGLOBAL data=GlobalAlloc(GHND,size);if(!data)return false;void *copy=GlobalLock(data);memcpy(copy,bytes,size);GlobalUnlock(data);if(!SetClipboardData(format,data)){GlobalFree(data);return false;}return true;}
static bool set_text(const wchar_t *text){if(!OpenClipboard(main_window))return false;EmptyClipboard();bool ok=set_data(CF_UNICODETEXT,text,(wcslen(text)+1)*2);CloseClipboard();return ok;}
static void paste(bool shift,unsigned repeats){INPUT input[10]={0};unsigned n=0;input[n].type=INPUT_KEYBOARD;input[n++].ki.wVk=VK_CONTROL;if(shift){input[n].type=INPUT_KEYBOARD;input[n++].ki.wVk=VK_SHIFT;}
 for(unsigned i=0;i<repeats;++i){input[n].type=INPUT_KEYBOARD;input[n++].ki.wVk='V';}input[n].type=INPUT_KEYBOARD;input[n].ki.wVk='V';input[n++].ki.dwFlags=KEYEVENTF_KEYUP;
 if(shift){input[n].type=INPUT_KEYBOARD;input[n].ki.wVk=VK_SHIFT;input[n++].ki.dwFlags=KEYEVENTF_KEYUP;}input[n].type=INPUT_KEYBOARD;input[n].ki.wVk=VK_CONTROL;input[n++].ki.dwFlags=KEYEVENTF_KEYUP;SendInput(n,input,sizeof(INPUT));pump(250);}
static bool foreground(void){ShowWindow(main_window,SW_RESTORE);SetForegroundWindow(main_window);SetFocus(main_window);pump(100);return GetForegroundWindow()==main_window;}
static bool png_clipboard(const wchar_t *path){HANDLE f=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,0,NULL);if(f==INVALID_HANDLE_VALUE)return false;DWORD n=GetFileSize(f,NULL),got;void *bytes=malloc(n);bool ok=ReadFile(f,bytes,n,&got,NULL)&&got==n;CloseHandle(f);if(!ok||!OpenClipboard(main_window)){free(bytes);return false;}EmptyClipboard();ok=set_data(RegisterClipboardFormatW(L"PNG"),bytes,n);const wchar_t alternative[]=L"image alternative text";ok=ok&&set_data(CF_UNICODETEXT,alternative,sizeof(alternative));CloseClipboard();free(bytes);return ok;}
static bool dib_clipboard(bool v5){unsigned char bytes[256]={0};BITMAPINFOHEADER *h=(BITMAPINFOHEADER*)bytes;h->biSize=v5?sizeof(BITMAPV5HEADER):sizeof(BITMAPINFOHEADER);h->biWidth=3;h->biHeight=-2;h->biPlanes=1;h->biBitCount=v5?32:24;h->biCompression=BI_RGB;unsigned stride=v5?12:12;for(unsigned y=0;y<2;++y)for(unsigned x=0;x<3;++x){unsigned char *p=bytes+h->biSize+y*stride+x*(v5?4:3);p[0]=y?255:0;p[1]=x==1?255:0;p[2]=!y?255:0;}
 if(!OpenClipboard(main_window))return false;EmptyClipboard();bool ok=set_data(v5?CF_DIBV5:CF_DIB,bytes,h->biSize+stride*2);CloseClipboard();return ok;}
static bool file_clipboard(const wchar_t *first,const wchar_t *second){size_t n=wcslen(first)+2+(second?wcslen(second)+1:0);HGLOBAL data=GlobalAlloc(GHND,sizeof(DROPFILES)+n*2);DROPFILES *header=GlobalLock(data);header->pFiles=sizeof(DROPFILES);header->fWide=TRUE;wchar_t *paths=(wchar_t*)((char*)header+sizeof(DROPFILES));wcscpy(paths,first);if(second)wcscpy(paths+wcslen(first)+1,second);GlobalUnlock(data);if(!OpenClipboard(main_window)){GlobalFree(data);return false;}EmptyClipboard();bool ok=SetClipboardData(CF_HDROP,data)!=NULL;CloseClipboard();return ok;}
int wmain(int argc,wchar_t **argv){if(argc>1&&!wcscmp(argv[1],L"-s"))return shell_bridge(argc,argv);
 if(argc==3&&!wcscmp(argv[1],L"--wait-pid")){DWORD pid=(DWORD)wcstoul(argv[2],NULL,10);HANDLE p=OpenProcess(SYNCHRONIZE,FALSE,pid);if(!p)return 0;DWORD result=WaitForSingleObject(p,6000);CloseHandle(p);return result==WAIT_OBJECT_0?0:88;}
 wchar_t self[2048],dir[2048],module[2048],helper[2048],png[2048],jpg[2048];GetModuleFileNameW(NULL,self,2048);wcscpy(dir,self);*wcsrchr(dir,L'\\')=0;swprintf(module,2048,L"%ls\\ClipboardBridge.exe",dir);swprintf(helper,2048,L"%ls\\fixture.png",dir);wcscpy(png,helper);swprintf(jpg,2048,L"%ls\\fixture.jpg",dir);
 SetEnvironmentVariableW(L"ANDROID_ADB_SERVER_PORT",L"55107");SetEnvironmentVariableW(L"ADB_SERVER_SOCKET",NULL);
 WNDCLASSW cls={0};cls.lpfnWndProc=wndproc;cls.hInstance=GetModuleHandleW(NULL);cls.lpszClassName=L"WarmBridgeTest";RegisterClassW(&cls);main_window=CreateWindowW(cls.lpszClassName,L"Bridge test phone",WS_OVERLAPPEDWINDOW,200,100,600,400,NULL,NULL,cls.hInstance,NULL);if(!main_window)return 1;ShowWindow(main_window,SW_SHOW);pump(100);
 host=wb_host_start(main_window,module,self,helper);if(!host)return 2;wb_host_target(host,GetCurrentProcess(),GetCurrentProcessId(),L"phone-A",L"客服 01",true);ULONGLONG ready=GetTickCount64()+5000;while(wb_host_health(host)==0&&GetTickCount64()<ready)pump(20);if(wb_host_health(host)!=1)return 3;if(!foreground())return 4;pump(200);
 // Ordinary text is passed to the foreground mirror, without clipboard changes.
 if(!set_text(L"普通文字与搜狗输入"))return 5;DWORD seq=GetClipboardSequenceNumber();paste(false,1);if(keys!=1||GetClipboardSequenceNumber()!=seq)return 6;
 INPUT unicode[2]={0};unicode[0].type=unicode[1].type=INPUT_KEYBOARD;unicode[0].ki.wScan=unicode[1].ki.wScan=0x6e29;unicode[0].ki.dwFlags=KEYEVENTF_UNICODE;unicode[1].ki.dwFlags=KEYEVENTF_UNICODE|KEYEVENTF_KEYUP;SendInput(2,unicode,sizeof(INPUT));pump(100);if(letters!=1)return 7;
 if(!png_clipboard(png))return 8;seq=GetClipboardSequenceNumber();paste(false,3);wchar_t rejection[32];if(GetEnvironmentVariableW(L"WARM_TEST_REJECT",rejection,32)){
  ULONGLONG deadline=GetTickCount64()+12000;while(!errors&&GetTickCount64()<deadline)pump(20);
  if(!errors||completed||keys!=1||GetClipboardSequenceNumber()!=seq)return 31;
  wb_host_stop(host);host=NULL;DestroyWindow(main_window);puts("Rejected image did not become a gallery transfer.");return 0;
 }
 if(!wait_completed(1)||keys!=1||GetClipboardSequenceNumber()!=seq)return 9;
 // Reusing one unchanged clipboard is cached and can target another registered serial.
 wb_host_target(host,GetCurrentProcess(),GetCurrentProcessId(),L"phone-B",L"客服 02",true);pump(200);paste(false,1);if(!wait_completed(2)||keys!=1)return 10;
 if(!dib_clipboard(false))return 11;paste(false,1);if(!wait_completed(3))return 12;
 if(!dib_clipboard(true))return 13;paste(false,1);if(!wait_completed(4))return 14;
 if(!file_clipboard(png,jpg))return 15;seq=GetClipboardSequenceNumber();paste(false,1);if(!wait_completed(6)||GetClipboardSequenceNumber()!=seq)return 16;
 // Disabled and unregistered targets do not consume any paste shortcut.
 wb_host_target(host,GetCurrentProcess(),GetCurrentProcessId(),L"phone-B",L"客服 02",false);pump(200);paste(false,1);if(keys!=2||completed!=6)return 17;
 wb_host_remove(host,GetCurrentProcessId());pump(200);paste(false,1);if(keys!=3||completed!=6)return 18;
 wb_host_target(host,GetCurrentProcess(),GetCurrentProcessId(),L"phone-A",L"客服 01",true);pump(200);paste(true,1);if(keys!=4||completed!=6)return 19;
 // A later clipboard change must not turn an older image request into another payload.
 if(!png_clipboard(png)||!OpenClipboard(main_window))return 20;
 paste(false,1);EmptyClipboard();const wchar_t changed[]=L"changed while image request was queued";if(!set_data(CF_UNICODETEXT,changed,sizeof(changed)))return 26;CloseClipboard();pump(500);
 if(completed!=6||keys!=4||!wcsstr(last_status,L"剪贴板已改变"))return 27;
 // Mixed non-image file selections are rejected as a whole, never pasted as stale text.
 wchar_t bad[2048];swprintf(bad,2048,L"%ls\\not-an-image.txt",dir);HANDLE bad_file=CreateFileW(bad,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,0,NULL);if(bad_file==INVALID_HANDLE_VALUE)return 28;CloseHandle(bad_file);
 if(!file_clipboard(png,bad))return 29;paste(false,1);pump(300);DeleteFileW(bad);
 if(completed!=6||keys!=4||!wcsstr(last_status,L"只桥接普通图片文件"))return 30;
 if(!png_clipboard(png))return 20;paste(false,1);if(!wait_completed(7)||keys!=4)return 21;
 if(errors)return 22;
 DWORD detached=wb_host_detach(host);host=NULL;if(!detached)return 23;
 paste(false,1);pump(4000);if(keys!=4)return 24;
 wchar_t pid_path[2048];swprintf(pid_path,2048,L"%ls\\detached-pid.txt",dir);FILE *pid_file=_wfopen(pid_path,L"w");if(!pid_file)return 25;fprintf(pid_file,"%lu",(unsigned long)detached);fclose(pid_file);
 DestroyWindow(main_window);puts("Live bridge hooks, Unicode/text pass-through, PNG/DIB/DIBV5, CF_HDROP, repeat suppression, target changes, opt-out and unchanged clipboard passed.");return 0;
}
