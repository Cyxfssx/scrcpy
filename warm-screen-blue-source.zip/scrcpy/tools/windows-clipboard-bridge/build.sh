#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
bridge_build="${1:-/workspace/setup/windows/manager-bridge-build}"
mkdir -p "$bridge_build"
bridge_cc="${CC_WIN:-x86_64-w64-mingw32-gcc}"
x86_64-w64-mingw32-windres -Itools/windows-clipboard-bridge tools/windows-clipboard-bridge/manager.rc "$bridge_build/manager-res.o"
bridge_sources=tools/windows-clipboard-bridge
bridge_flags=(-std=c11 -O2 -Wall -Wextra -Werror -Wno-misleading-indentation -municode -mwindows -static-libgcc)
"$bridge_cc" "${bridge_flags[@]}" "$bridge_sources/manager.c" "$bridge_sources/model.c" "$bridge_sources/theme.c" "$bridge_sources/bridge_host.c" "$bridge_build/manager-res.o" -o "$bridge_build/Manager.exe" -lcomctl32 -lshell32 -lgdi32 -luser32 -lgdiplus -ldwmapi -luxtheme -lcomdlg32 -lpsapi -lm
"$bridge_cc" "${bridge_flags[@]}" "$bridge_sources/bridge_process.c" "$bridge_sources/clipboard_image.c" "$bridge_sources/transfer.c" -o "$bridge_build/ClipboardBridge.exe" -lgdiplus -lgdi32 -luser32 -lole32 -lshell32 -lws2_32
"$bridge_cc" "${bridge_flags[@]}" -DMANAGER_SMOKE_TEST "$bridge_sources/manager.c" "$bridge_sources/model.c" "$bridge_sources/theme.c" "$bridge_sources/bridge_host.c" "$bridge_build/manager-res.o" -o "$bridge_build/Manager-smoke.exe" -lcomctl32 -lshell32 -lgdi32 -luser32 -lgdiplus -ldwmapi -luxtheme -lcomdlg32 -lpsapi -lm

"$bridge_cc" -std=c11 -O1 -Wall -Wextra -Werror -Wno-misleading-indentation -municode -static-libgcc "$bridge_sources/test_bridge.c" "$bridge_sources/bridge_host.c" -o "$bridge_build/Bridge-test.exe" -lws2_32 -luser32 -lshell32
