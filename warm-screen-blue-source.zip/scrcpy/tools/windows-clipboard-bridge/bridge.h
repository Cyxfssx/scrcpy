#ifndef WARM_CLIPBOARD_BRIDGE_H
#define WARM_CLIPBOARD_BRIDGE_H
#include <windows.h>
#include <stdbool.h>
#define WB_MAGIC 0x57424338u
#define WB_MAX_TARGETS 32
#define WB_PATH 2048
#define WB_STATUS_MAGIC 0x57425338u
struct wb_target {DWORD pid;FILETIME created;BOOL enabled;wchar_t serial[128],alias[64];};
struct wb_shared {DWORD magic,parent_pid;HWND owner;volatile LONG sequence,stop,ready,detached;wchar_t adb[WB_PATH],helper[WB_PATH];struct wb_target targets[WB_MAX_TARGETS];};
struct wb_host;
struct wb_host *wb_host_start(HWND owner,const wchar_t *exe,const wchar_t *adb,const wchar_t *helper);
void wb_host_target(struct wb_host *host,HANDLE process,DWORD pid,const wchar_t *serial,const wchar_t *alias,bool enabled);
void wb_host_remove(struct wb_host *host,DWORD pid);
void wb_host_stop(struct wb_host *host);
DWORD wb_host_detach(struct wb_host *host);
int wb_host_health(struct wb_host *host);
bool wb_host_message(struct wb_host *host,WPARAM sender,LPARAM data,wchar_t *text,size_t capacity);
#endif
