package com.genymobile.scrcpy;

import android.media.MediaScannerConnection;
import android.os.Looper;
import java.io.File;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/** One-shot shell-UID media indexing for manager transfers; no activities or chat actions. */
public final class TransferScanner {
    private TransferScanner() { }

    @SuppressWarnings("deprecation")
    public static void main(String... paths) {
        try {
            if (paths.length == 0 || paths.length > 128) {
                System.exit(2);
                return;
            }
            for (String path : paths) {
                if (!path.startsWith("/sdcard/") || !new File(path).isFile()) {
                    System.exit(2);
                    return;
                }
            }
            Looper.prepareMainLooper();
            Workarounds.apply();
            Thread runner = new Thread(() -> {
                try {
                    CountDownLatch finished = new CountDownLatch(paths.length);
                    AtomicBoolean allIndexed = new AtomicBoolean(true);
                    MediaScannerConnection.scanFile(FakeContext.get(), paths, null, (path, uri) -> {
                        if (uri == null) {
                            allIndexed.set(false);
                        }
                        finished.countDown();
                    });
                    boolean complete = finished.await(12, TimeUnit.SECONDS);
                    System.exit(complete && allIndexed.get() ? 0 : 1);
                } catch (Exception e) {
                    System.err.println("Media indexing failed: " + e);
                    System.exit(1);
                }
            }, "warm-media-index");
            runner.start();
            Looper.loop();
        } catch (Throwable e) {
            System.err.println("Media indexing unavailable: " + e);
            System.exit(1);
        }
    }
}
