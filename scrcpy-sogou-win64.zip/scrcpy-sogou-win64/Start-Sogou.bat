@echo off
setlocal
cd /d "%~dp0"
set "SDL_IME_IMPLEMENTED_UI=none"
scrcpy.exe --keyboard=sdk --text-via-clipboard --window-title "scrcpy - Sogou IME" %*
if errorlevel 1 (
  echo.
  echo Startup failed. Please send a screenshot of this window.
  pause
)
